/*
 * Copyright (C) 2026 Justin Bettcher. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once

#include <wtf/Platform.h>

#if ENABLE(ASSEMBLER) && CPU(PPC64LE)

#include "AbstractMacroAssembler.h"
#include "PPC64Assembler.h"
#include "TargetAssemblerDefinitions.h"

// MacroAssemblerPPC64 -- STAGE b2: COMPILE-ONLY.
//
// Why this file exists in this shape. PlatformEnable.h:944 forces
// ENABLE_ASSEMBLER=1 for every non-C_LOOP build, so a MacroAssembler<Arch>
// must COMPILE before the native LLInt can be built at all -- even with
// ENABLE_JIT=OFF, where nothing in here is ever executed. The milestone this
// file serves is "a jsc built with the native LLInt runs", not "the JIT
// works".
//
// So every operation below is a stub that fails loudly:
// UNREACHABLE_FOR_PLATFORM() aborts with the file and line. NOT a silent
// empty body -- an empty body would compile, link, run, and quietly emit
// nothing, which is the single worst failure mode available here. If a
// non-JIT path ever does reach one of these, the crash names it.
//
// The method surface is deliberately the same as MacroAssemblerRISCV64's
// public surface. RISCV64 is the closest structural template in the tree
// (64-bit, no SIMD, two scratch registers, most recent from-scratch port),
// and matching it method-for-method is what makes the ~40 generic call sites
// elsewhere in JSC compile without per-site #ifs.
//
// Filling these in is stage c of jsc-ppc64le-port.md. The register
// assignment, the compare/branch pairing, the 32-bit zero-extension
// invariant and the r2/TOC rule are all already settled by
// offlineasm/ppc64.rb and documented in that file's section 5; a real
// implementation must follow them, because LLInt and JIT code share the
// callee-saved half of the register file.

#define MACRO_ASSEMBLER_PPC64_TEMPLATED_NOOP_METHOD(methodName) \
    template<typename... Args> void methodName(Args&&...) = delete;
#define MACRO_ASSEMBLER_PPC64_TEMPLATED_NOOP_METHOD_WITH_RETURN(methodName, returnType) \
    template<typename... Args> returnType methodName(Args&&...) = delete;

namespace JSC {

using Assembler = TARGET_ASSEMBLER;

class MacroAssemblerPPC64 : public AbstractMacroAssembler<Assembler> {
public:
    // A VMX register number. Distinct from FPRegisterID, which is a VSR
    // number: vr(n) IS VSR(32+n), so the same value names a different
    // physical register in each space and the two must not be interchangeable.
    using VRegisterID = Assembler::VRegisterID;

    static constexpr unsigned numGPRs = 32;
    static constexpr unsigned numFPRs = 32;

    // `b` reaches +-32 MiB; anything further needs the seven-word ladder.
    static constexpr size_t nearJumpRange = 32 * MB;

    // r28-r30 are offlineasm's temporary pool; the MacroAssembler takes the
    // top two of them, as jsc-ppc64le-port.md section 5.2 specifies. The two
    // code streams never share a live temporary -- only the callee-saved
    // registers, cfr and sp are shared state.
    static constexpr RegisterID dataTempRegister = PPC64Registers::r29;
    static constexpr RegisterID memoryTempRegister = PPC64Registers::r30;

    // VOLATILE, deliberately. These were f30/f31, which are callee-saved and
    // which nothing saves: the VM entry frame preserves f14-f25 only, so JIT
    // code using them corrupted the floating-point state of the C++ that
    // called into the engine. f13 and f0 are the two volatile FPRs left over
    // once FPRInfo's allocatable set is f1-f12.
    // ==================================================================
    // THE VMX BRIDGE, and why this port copies in and out of it.
    //
    // POWER's integer vector arithmetic, compares, shifts, narrows and
    // permutes exist ONLY as VMX-form instructions, which carry 5-bit fields
    // naming vr0-vr31 -- and vr(n) is VSR(32+n). This port's FPRegisterID
    // space is VSR 0-31, so a VMX instruction cannot name a JSC vector
    // register at all. There is no VSX-form integer vector add on the POWER8
    // floor: `xvaddubm` is not an instruction.
    //
    // THE COST, MEASURED (jsc-ppc64le-vector-register-model.md section 3):
    // a binary VMX operation is FOUR instructions here where a native
    // register bank would use ONE -- bridge in, bridge in, operate, bridge
    // out. A unary one is three. Aliasing does not help: the VMX instruction
    // must read AND write registers in the vr range whatever the operands
    // alias, so the bridge-out is never avoidable.
    //
    // THE 1x IS NOT AVAILABLE, and that is a decision rather than an
    // oversight. Reaching it requires the register ALLOCATOR to place values
    // in VSR 32-63, which means they must be Regs that Air can see. Making
    // them so has two consequences that were measured rather than guessed:
    // conservativeWidth() is Width128 for any FPR, so every added register
    // would carry m_upperBits into every derived RegisterSet and make
    // ScratchRegisterAllocator's Width128 arm live -- an arm that enabling
    // BBQ makes reachable anyway -- and reservedHardwareRegisters() asserts
    // that no FPR is ever reserved, so the obvious containment is blocked.
    // The 4x was accepted deliberately against that risk.
    //
    // THE INVARIANT THIS ROUTE DEPENDS ON:
    //
    //     Nothing may ever be live in a bridge register across an
    //     instruction boundary the port can suspend at.
    //
    // Bridge in, operate, bridge out is ONE emitted sequence, and that is
    // what makes the route sound. MacroAssembler::probe cannot see these
    // registers at all -- Probe::CPUState gives this port `double fprs[]`
    // and the `v128_t vectors[]` arm is gated to X86_64 and ARM64 -- so a
    // value held in one across a probe point, an OSR exit or a call would be
    // lost silently. Any future use that spans a boundary breaks this and
    // must not be written.
    //
    // vr8-vr11 are the choice because ELFv2 makes v0-v19 volatile, so there
    // is no callee-save duty, and IPInt uses vr8-vr11 only as within-handler
    // scratch, never across a dispatch, while its value stack lives in
    // vr0-vr7.
    static constexpr VRegisterID vectorBridge0 = PPC64Registers::vr8;
    static constexpr VRegisterID vectorBridge1 = PPC64Registers::vr9;
    // A third, for the forms that need a zero operand -- vxor against itself
    // supplies one with no constant and no memory access.
    static constexpr VRegisterID vectorBridge2 = PPC64Registers::vr10;
    static constexpr FPRegisterID vectorBridge0VSR = PPC64Registers::vsrForVR(vectorBridge0);
    static constexpr FPRegisterID vectorBridge1VSR = PPC64Registers::vsrForVR(vectorBridge1);
    static constexpr FPRegisterID vectorBridge2VSR = PPC64Registers::vsrForVR(vectorBridge2);

    // THE PREMISE, CHECKED RATHER THAN COMMENTED. The bridge registers work
    // only because they lie OUTSIDE the modelled FP register file, so the
    // allocator can never hand them to anything. If the file ever grows to
    // cover them this fails, and the bridge must be removed rather than
    // quietly clobbering whatever the allocator put there.
    static_assert(static_cast<unsigned>(vectorBridge0VSR) >= Assembler::numberOfFPRegisters()
        && static_cast<unsigned>(vectorBridge1VSR) >= Assembler::numberOfFPRegisters()
        && static_cast<unsigned>(vectorBridge2VSR) >= Assembler::numberOfFPRegisters(),
        "A vector bridge register is inside the FP register file: the bridge is now unsafe. "
        "See jsc-ppc64le-vector-register-model.md.");

    static constexpr FPRegisterID fpTempRegister = PPC64Registers::f13;
    static constexpr FPRegisterID fpTempRegister2 = PPC64Registers::f0;

    static constexpr RegisterID InvalidGPRReg = PPC64Registers::InvalidGPRReg;
    // The FP counterpart, re-exported here exactly as MacroAssemblerARM64.h
    // re-exports ARM64Registers::InvalidFPRReg: it is what the unused-scratch
    // parameters default to.
    static constexpr FPRegisterID InvalidFPRReg = PPC64Registers::InvalidFPRReg;

    static constexpr RegisterID stackPointerRegister = PPC64Registers::r1;
    static constexpr RegisterID framePointerRegister = PPC64Registers::r31;

    // There is deliberately no `linkRegister`. On PowerPC the link register
    // is an SPR reached through mflr/mtlr, not a GPR, so there is no GPRReg
    // that names it. Anything that wants to move the return address through
    // the register allocator has to be written for this port rather than
    // inherited from ARM64/RISCV64 -- and it should be a compile error here,
    // not a plausible-looking wrong register.

    RegisterID scratchRegister()
    {
        return dataTempRegister;
    }

    enum TempRegisterType : int8_t {
        Data,
        Memory,
    };

    template<TempRegisterType... RegisterTypes>
    struct TempRegister {
        RegisterID data()
        {
            static_assert(((RegisterTypes == Data) || ...));
            return dataTempRegister;
        }

        RegisterID memory()
        {
            static_assert(((RegisterTypes == Memory) || ...));
            return memoryTempRegister;
        }
    };

    template<TempRegisterType RegisterType>
    struct LazyTempRegister {
        LazyTempRegister(bool allowScratchRegister)
            : m_allowScratchRegister(allowScratchRegister)
        {
            static_assert(RegisterType == Data || RegisterType == Memory);
        }

        operator RegisterID()
        {
            RELEASE_ASSERT(m_allowScratchRegister);
            if constexpr (RegisterType == Data)
                return dataTempRegister;
            if constexpr (RegisterType == Memory)
                return memoryTempRegister;
            return InvalidGPRReg;
        }

        bool m_allowScratchRegister;
    };

    template<TempRegisterType... RegisterTypes>
    auto temps() -> TempRegister<RegisterTypes...>
    {
        RELEASE_ASSERT(m_allowScratchRegister);
        return { };
    }

    template<TempRegisterType RegisterType>
    auto lazyTemp() -> LazyTempRegister<RegisterType>
    {
        return { m_allowScratchRegister };
    }

    // frin is ties-away-from-zero, not ties-to-even, so the rounding
    // primitives JSC wants are the VSX xsrdpi* family. They exist on POWER8,
    // so this is true -- but nothing below implements them yet.
    static bool supportsFloatingPointRounding() { return true; }
    // IEEE binary16 conversion is ISA 3.0 (POWER9): xscvhpdp/xscvdphp, plus
    // the lxsihzx/stxsihx halfword moves. The brief that first raised this
    // had it inverted -- what arrives with ISA 3.1 (POWER10) is BFLOAT16,
    // xvcvbf16spn/xvcvspbf16. Measured on the AC922: `as -mpower8` rejects
    // all six instructions, `as -mpower9` assembles them, they execute, and
    // xscvdphp matches a software round-to-nearest-even reference on every
    // probe value with zero round-trip mismatches over all 2^16 halves.
    //
    // Runtime rather than compile-time because one jsc binary from the
    // POWER8 pool may run on either generation, and because a wrong answer
    // here is a SIGILL rather than a slow path. On a machine without ISA 3.0
    // this stays false and upstream's existing guards route every float16
    // producer to the generic WTF::Float16 paths in C++ -- the same paths
    // x86_64 runs today. ARM64 answers this the same way, with a runtime
    // feature test.
    static bool supportsFloat16() { return Assembler::hasISA30(); }
    static bool supportsCountPopulation() { return true; } // popcntw / popcntd

    // On PowerPC the signedness of a comparison lives in the COMPARE
    // instruction (cmpw/cmpd versus cmplw/cmpld), not in the branch, so the
    // Assembler::Condition these map onto carries both halves: which compare
    // to emit and which CR bit to test.
    enum RelationalCondition {
        Equal = Assembler::ConditionEQ,
        NotEqual = Assembler::ConditionNE,
        Above = Assembler::ConditionGTU,
        AboveOrEqual = Assembler::ConditionGEU,
        Below = Assembler::ConditionLTU,
        BelowOrEqual = Assembler::ConditionLEU,
        GreaterThan = Assembler::ConditionGT,
        GreaterThanOrEqual = Assembler::ConditionGE,
        LessThan = Assembler::ConditionLT,
        LessThanOrEqual = Assembler::ConditionLE,
    };

    static constexpr RelationalCondition invert(RelationalCondition cond)
    {
        return static_cast<RelationalCondition>(Assembler::invert(static_cast<Assembler::Condition>(cond)));
    }

    enum ResultCondition {
        Carry, // <- not implemented
        Overflow,
        Signed,
        PositiveOrZero,
        Zero,
        NonZero,
    };

    enum ZeroCondition {
        IsZero,
        IsNonZero,
    };

    enum DoubleCondition {
        DoubleEqualAndOrdered,
        DoubleNotEqualAndOrdered,
        DoubleGreaterThanAndOrdered,
        DoubleGreaterThanOrEqualAndOrdered,
        DoubleLessThanAndOrdered,
        DoubleLessThanOrEqualAndOrdered,
        DoubleEqualOrUnordered,
        DoubleNotEqualOrUnordered,
        DoubleGreaterThanOrUnordered,
        DoubleGreaterThanOrEqualOrUnordered,
        DoubleLessThanOrUnordered,
        DoubleLessThanOrEqualOrUnordered,
    };

    enum BranchTruncateType { BranchIfTruncateFailed, BranchIfTruncateSuccessful };

    static ptrdiff_t maxJumpReplacementSize() { return Assembler::maxJumpReplacementSize(); }
    static ptrdiff_t patchableJumpSize() { return Assembler::patchableJumpSize(); }

    // The handful of operations that are implemented for real, because they
    // are one instruction each and because a wrong barrier is worse than an
    // absent one.
    void nop() { m_assembler.nop(); }
    void breakpoint() { m_assembler.trap(); }
    void breakpoint(uint16_t) { m_assembler.trap(); }

    // Power ISA Book II: sync is the full barrier (StoreLoad included),
    // lwsync orders everything but StoreLoad. See
    // powerpc64le-handbook memory-ordering-and-atomics.md.
    void memoryFence() { m_assembler.sync(); }
    void storeFence() { m_assembler.lwsync(); }
    void loadFence() { m_assembler.lwsync(); }

    // ==================================================================
    // Infrastructure the real implementations below are built on.
    // ==================================================================
    //
    // THE 32-BIT INVARIANT. A 32-bit value is held ZERO-EXTENDED in its
    // 64-bit register, the same as an ARM64 `w` register. So every *32 op
    // that produces a value finishes with `clrldi rD, rD, 32`. Two
    // consequences worth stating because they are easy to get wrong:
    //
    //   - Compares do NOT need the extension, because cmpw/cmplw read only
    //     the low word. That is why branch32 is cheaper here than on RISC-V,
    //     which has to mask before every comparison.
    //   - load32 is `lwz` (zero-extending) and therefore already satisfies
    //     the invariant; load32SignedExtendTo64 is `lwa` and deliberately
    //     does NOT, because its whole purpose is a sign-extended 64-bit
    //     result.
    //
    // THE r0 TRAP. In the RA field of a D-form or X-form address, register 0
    // does not mean r0 -- it means the literal constant 0. So r0 can never be
    // used as a base register, and `addi rD, r0, n` is `li rD, n`, not
    // "r0 + n". r0 is used here only as a fixed scratch inside sequences that
    // never use it as a base (the LR shuttle, mainly), never as an allocatable
    // temporary. r2 (TOC) and r13 (TLS) are never written at all.

    // Which CR0 bit a condition tests, and whether it branches when that bit
    // is set or clear. On PowerPC the SIGNEDNESS lives in the compare
    // instruction (cmpw/cmpd vs cmplw/cmpld), not in the branch, so LT and
    // LTU both come out as "the LT bit"; it is emitCompare* that differs.
    struct CRTest {
        CRBit bit;
        bool branchIfSet;
        // Integer comparisons all land in CR0. Floating-point conditions
        // that are a disjunction of two CR bits (LT|GT, GT|EQ, EQ|SO, ...)
        // have to be composed with cror into a bit of a DIFFERENT field --
        // cr7 here -- because the OR would otherwise overwrite one of the
        // bits it is reading. probes/nanbranch.c in the handbook is the
        // measurement behind that: ble and bge fire on NaN, so an ordered
        // "less or equal" really is a two-bit disjunction and the result
        // must not land back in cr0.
        CRField field = CRField::CR0;
    };

    static CRTest crTestFor(Assembler::Condition cond)
    {
        switch (cond) {
        case Assembler::ConditionEQ:  return { CRBit::EQ, true };
        case Assembler::ConditionNE:  return { CRBit::EQ, false };
        case Assembler::ConditionLT:
        case Assembler::ConditionLTU: return { CRBit::LT, true };
        case Assembler::ConditionGE:
        case Assembler::ConditionGEU: return { CRBit::LT, false };
        case Assembler::ConditionGT:
        case Assembler::ConditionGTU: return { CRBit::GT, true };
        case Assembler::ConditionLE:
        case Assembler::ConditionLEU: return { CRBit::GT, false };
        }
        RELEASE_ASSERT_NOT_REACHED();
        return { CRBit::EQ, true };
    }

    static CRTest crTestFor(RelationalCondition cond)
    {
        return crTestFor(static_cast<Assembler::Condition>(cond));
    }

    // ---- immediates ----

    // ZERO-extended, deliberately, because that is what ARM64 does and
    // because AssemblyHelpers::boxInt32() is a bare `or64` with the number
    // tag: an int32 whose upper half is not zero produces a corrupt JSValue.
    // (MacroAssemblerRISCV64 sign-extends here instead. The two cannot both
    // be what JSC depends on; ARM64 is the one that is exercised, so ARM64 is
    // the one to match.) Anything that genuinely wants a sign-extended 64-bit
    // constant asks for it with TrustedImm64, or goes through
    // loadSignExtendedImmediate32 below.
    void loadImmediate(TrustedImm32 imm, RegisterID dest)
    {
        m_assembler.loadImmediate64(dest, static_cast<int64_t>(static_cast<uint32_t>(imm.m_value)));
    }

    // The 64-bit-operand reading of a TrustedImm32: addPtr(TrustedImm32(-16),
    // stackPointerRegister) has to subtract 16, not add 4294967280. Every
    // 64-bit ALU operation taking a TrustedImm32 uses this one.
    void loadSignExtendedImmediate32(int32_t value, RegisterID dest)
    {
        m_assembler.loadImmediate64(dest, static_cast<int64_t>(value));
    }

    void loadImmediate(TrustedImm64 imm, RegisterID dest)
    {
        m_assembler.loadImmediate64(dest, imm.m_value);
    }

    void loadImmediate(TrustedImmPtr imm, RegisterID dest)
    {
        m_assembler.loadImmediate64(dest, reinterpret_cast<int64_t>(imm.m_value));
    }

    // ---- address resolution ----
    //
    // Every memory operand is reduced to a (base register, signed 16-bit
    // displacement) pair, materialising into `destination` only when it has
    // to. `requiresDSForm` is passed by the callers that will emit ld/std/lwa:
    // those are DS-form, whose displacement field drops its low two bits, so
    // a displacement that is not a multiple of 4 has to go through a register
    // even though it fits in 16 bits. Confusing D-form with DS-form is the
    // single easiest way to emit a silently wrong address here, so the flag
    // is explicit at every call site rather than inferred.

    struct AddressResolution {
        RegisterID base;
        int32_t offset;
    };

    template<typename RegisterType>
    AddressResolution resolveAddress(Address address, RegisterType destination, bool requiresDSForm = false)
    {
        if (requiresDSForm ? Assembler::isValidDSForm(address.offset) : Assembler::isValidDForm(address.offset))
            return { address.base, address.offset };

        RegisterID dest = destination;
        // addImmediate64 reads `base` and writes `dest`, and is safe when the
        // two are the same register; materialising the constant into `dest`
        // first would not be.
        addImmediate64(address.base, static_cast<int64_t>(address.offset), dest);
        return { dest, 0 };
    }

    template<typename RegisterType>
    AddressResolution resolveAddress(BaseIndex address, RegisterType destination, bool requiresDSForm = false)
    {
        RegisterID dest = destination;

        // dest = base + (index << scale)
        //
        // The scaled index needs somewhere to live, and it CANNOT be `dest`
        // when `dest` is also `base` or `index`: the shift would destroy the
        // operand the following add still has to read. getEffectiveAddress
        // passes a caller register as `dest`, and JSC calls it with dest ==
        // base all the time (it is how an array element address is formed),
        // so this is not a corner case. testmasm's testGetEffectiveAddress
        // is the regression test.
        if (address.scale != TimesOne) {
            RegisterID shifted = dest;
            if (dest == address.base || dest == address.index)
                shifted = immediateScratch(address.base, address.index);
            m_assembler.sldi(shifted, address.index, static_cast<uint32_t>(address.scale));
            m_assembler.add(dest, address.base, shifted);
        } else
            m_assembler.add(dest, address.base, address.index);

        if (!address.offset)
            return { dest, 0 };

        if (requiresDSForm ? Assembler::isValidDSForm(address.offset) : Assembler::isValidDForm(address.offset))
            return { dest, address.offset };

        // The displacement does not fit the instruction form. addImmediate64
        // knows how to fold it in, including the case where compensating for
        // addi's sign extension carries the high half out of range.
        addImmediate64(dest, static_cast<int64_t>(address.offset), dest);
        return { dest, 0 };
    }

    template<typename RegisterType>
    AddressResolution resolveAddress(ExtendedAddress address, RegisterType destination, bool requiresDSForm = false)
    {
        int64_t offset = static_cast<int64_t>(address.offset);
        if (Assembler::isValidSigned16(offset) && (!requiresDSForm || !(offset & 3)))
            return { address.base, static_cast<int32_t>(offset) };

        RegisterID dest = destination;
        m_assembler.loadImmediate64(dest, offset);
        m_assembler.add(dest, address.base, dest);
        return { dest, 0 };
    }

    // An AbsoluteAddress is a bare pointer; there is no base register, so the
    // pointer itself has to be materialised.
    template<typename RegisterType>
    AddressResolution resolveAddress(AbsoluteAddress address, RegisterType destination, bool = false)
    {
        RegisterID dest = destination;
        m_assembler.loadImmediate64(dest, reinterpret_cast<int64_t>(address.m_ptr));
        return { dest, 0 };
    }

    // ---- the 32-bit zero-extension invariant ----
    void maskLow32(RegisterID reg) { m_assembler.clrldi(reg, reg, 32); }

    // A scratch register that is neither of the two operands.
    //
    // The immediate helpers below need somewhere to materialise a constant
    // that does not fit an instruction field. Reaching for temps<Data>()
    // unconditionally is wrong: these helpers are also called from places
    // that are ALREADY working in the data temp, and
    // `addImmediate64(dataTemp, big, dataTemp)` would then load the constant
    // over its own source and compute value+value. Picking a register that
    // collides with neither operand makes that impossible.
    //
    // The cost is that such a call may clobber the OTHER temp, so a caller
    // holding something live in one temp must not assume the other survives
    // an immediate operation. If both are taken this asserts rather than
    // choosing wrongly.
    RegisterID immediateScratch(RegisterID a, RegisterID b)
    {
        RELEASE_ASSERT(m_allowScratchRegister);
        if (dataTempRegister != a && dataTempRegister != b)
            return dataTempRegister;
        RELEASE_ASSERT(memoryTempRegister != a && memoryTempRegister != b);
        return memoryTempRegister;
    }

    // Where to materialise a constant that has to reach a register before it
    // can be combined with `src` into `dest`.
    //
    // When dest is not src, dest is already free: the constant can be built
    // there and consumed immediately by the ALU op that overwrites it. Only
    // the in-place form (dest == src) needs a register of its own.
    //
    // Preferring dest is not a peephole, it is what keeps three-address
    // immediate operations working when both MacroAssembler temporaries are
    // spoken for. branchTest32(cond, Address, mask) is exactly that caller:
    // it loads the address through one temp and tests into the other, so a
    // mask that needs materialising has nothing left to materialise into.
    // immediateScratch's RELEASE_ASSERT fired inside the Baseline compiler
    // for op_enumerator_put_by_val, whose mask is 0x40010 -- two bits, too
    // far apart for andi./andis. and not a rotate-and-mask run.
    RegisterID constantScratch(RegisterID src, RegisterID dest)
    {
        if (dest != src)
            return dest;
        return immediateScratch(src, dest);
    }

    // ---- generated stub surface (see the header comment) ----
    // ---- add / sub ----
    //
    // JSC's convention, which every method below follows: the two-operand
    // form is op(src, dest) meaning dest = dest OP src, and the three-operand
    // form is op(a, b, dest) meaning dest = a OP b. PowerPC's subf is the
    // other way round from both -- subf(rt, ra, rb) computes rt = rb - ra --
    // so every subtraction here reads with its operands crossed. That is the
    // single easiest thing to get backwards in this file.

    // dest = src + value, choosing the shortest encoding that is exact.
    void addImmediate64(RegisterID src, int64_t value, RegisterID dest)
    {
        if (!value) {
            move(src, dest);
            return;
        }
        if (Assembler::isValidSigned16(value)) {
            m_assembler.addi(dest, src, static_cast<int32_t>(value));
            return;
        }
        // Any signed 32-bit displacement is an addis/addi pair and needs NO
        // scratch register at all. addi sign-extends its field, so when the
        // low half is negative the high half has to be pre-compensated --
        // that is what the subtraction before the shift does. Doing this
        // without a temp is worth the arithmetic: every TrustedImm32 offset
        // in the engine lands here, including from callers that are already
        // using both temps.
        // addi sign-extends its 16-bit field, so when the low half is
        // negative the high half has to be compensated upward by one. That
        // compensation can carry OUT of the signed 16-bit range: for any
        // value in [0x7fff8000, 0x7fffffff] the corrected high half is
        // +32768, which addis cannot encode. It would be truncated to
        // -32768 and produce an address off by 2^32 -- silently, and only
        // for a narrow band of large positive displacements. (Found by
        // testmasm's load-with-large-offset cases, which emitted
        // `addis rD,rA,-32768 ; addi rD,rD,-1` for an offset of +2147483647.)
        // isValidSigned16 on the corrected half is the guard; anything it
        // rejects goes through a register instead.
        if (Assembler::isValidSigned32(value)) {
            int32_t low = static_cast<int16_t>(value);
            int64_t high = (value - low) >> 16;
            if (Assembler::isValidSigned16(high)) {
                RegisterID current = src;
                if (high) {
                    m_assembler.addis(dest, current, static_cast<int32_t>(high));
                    current = dest;
                }
                if (low) {
                    m_assembler.addi(dest, current, low);
                    current = dest;
                }
                move(current, dest);
                return;
            }
        }
        RegisterID scratch = constantScratch(src, dest);
        m_assembler.loadImmediate64(scratch, value);
        m_assembler.add(dest, src, scratch);
    }

    void add32(RegisterID src, RegisterID dest) { add32(src, dest, dest); }

    void add32(RegisterID a, RegisterID b, RegisterID dest)
    {
        m_assembler.add(dest, a, b);
        maskLow32(dest);
    }

    void add32(TrustedImm32 imm, RegisterID dest) { add32(imm, dest, dest); }

    void add32(TrustedImm32 imm, RegisterID src, RegisterID dest)
    {
        // 32-bit addition is modulo 2^32, so adding the sign-extended
        // immediate and then masking gives the right answer whichever way the
        // immediate is read.
        addImmediate64(src, static_cast<int64_t>(imm.m_value), dest);
        maskLow32(dest);
    }

    void add32(Address address, RegisterID dest)
    {
        auto temp = temps<Data>();
        load32(address, temp.data());
        add32(temp.data(), dest);
    }

    void add32(TrustedImm32 imm, Address address)
    {
        auto temp = temps<Data>();
        load32(address, temp.data());
        add32(imm, temp.data());
        store32(temp.data(), address);
    }

    void add32(TrustedImm32 imm, AbsoluteAddress address)
    {
        auto temp = temps<Data>();
        load32(address.m_ptr, temp.data());
        add32(imm, temp.data());
        store32(temp.data(), address.m_ptr);
    }

    void add8(TrustedImm32 imm, Address address)
    {
        auto temp = temps<Data>();
        load8(address, temp.data());
        m_assembler.addi(temp.data(), temp.data(), static_cast<int8_t>(imm.m_value));
        store8(temp.data(), address);
    }

    void add64(RegisterID src, RegisterID dest) { m_assembler.add(dest, dest, src); }
    void add64(RegisterID a, RegisterID b, RegisterID dest) { m_assembler.add(dest, a, b); }

    void add64(TrustedImm32 imm, RegisterID dest) { addImmediate64(dest, static_cast<int64_t>(imm.m_value), dest); }
    void add64(TrustedImm32 imm, RegisterID src, RegisterID dest) { addImmediate64(src, static_cast<int64_t>(imm.m_value), dest); }
    void add64(TrustedImm64 imm, RegisterID dest) { addImmediate64(dest, imm.m_value, dest); }
    void add64(TrustedImm64 imm, RegisterID src, RegisterID dest) { addImmediate64(src, imm.m_value, dest); }

    void add64(Address address, RegisterID dest)
    {
        auto temp = temps<Data>();
        load64(address, temp.data());
        m_assembler.add(dest, dest, temp.data());
    }

    void add64(AbsoluteAddress address, RegisterID dest)
    {
        auto temp = temps<Data>();
        load64(address.m_ptr, temp.data());
        m_assembler.add(dest, dest, temp.data());
    }

    void add64(TrustedImm32 imm, Address address)
    {
        auto temp = temps<Data>();
        load64(address, temp.data());
        add64(imm, temp.data());
        store64(temp.data(), address);
    }

    void add64(TrustedImm32 imm, AbsoluteAddress address)
    {
        auto temp = temps<Data>();
        load64(address.m_ptr, temp.data());
        add64(imm, temp.data());
        store64(temp.data(), address.m_ptr);
    }

    void sub32(RegisterID src, RegisterID dest) { sub32(dest, src, dest); }

    // dest = a - b. subf(rt, ra, rb) is rt = rb - ra, hence the crossing.
    void sub32(RegisterID a, RegisterID b, RegisterID dest)
    {
        m_assembler.subf(dest, b, a);
        maskLow32(dest);
    }

    void sub32(TrustedImm32 imm, RegisterID dest) { sub32(dest, imm, dest); }

    void sub32(RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        // Subtracting v is adding -v; negating first keeps this on the cheap
        // addi path. INT32_MIN has no negation inside 32 bits, but the
        // arithmetic here is done in 64 bits where -(int64_t)INT32_MIN is
        // representable, and the mask afterwards discards the difference.
        addImmediate64(src, -static_cast<int64_t>(imm.m_value), dest);
        maskLow32(dest);
    }

    void sub32(Address address, RegisterID dest)
    {
        auto temp = temps<Data>();
        load32(address, temp.data());
        sub32(temp.data(), dest);
    }

    void sub32(TrustedImm32 imm, Address address)
    {
        auto temp = temps<Data>();
        load32(address, temp.data());
        sub32(imm, temp.data());
        store32(temp.data(), address);
    }

    void sub32(TrustedImm32 imm, AbsoluteAddress address)
    {
        auto temp = temps<Data>();
        load32(address.m_ptr, temp.data());
        sub32(imm, temp.data());
        store32(temp.data(), address.m_ptr);
    }

    void sub64(RegisterID src, RegisterID dest) { m_assembler.subf(dest, src, dest); }
    void sub64(RegisterID a, RegisterID b, RegisterID dest) { m_assembler.subf(dest, b, a); }

    // ---- the carry-propagating pairs, for 128-bit add and subtract ----
    //
    // wasm's i64.add128 / i64.sub128 need a two-instruction chain that carries
    // a bit from the low half to the high half. POWER keeps that bit in
    // XER[CA], which addc/adde/subfc/subfe all read or write, so THE TWO CALLS
    // MUST STAY ADJACENT: anything emitted between them that touches CA
    // destroys the result. BBQ emits them back to back and resolves the
    // register aliasing that would otherwise need an intervening move before
    // its architecture fork, which is what makes sharing ARM64's two-line
    // sequence correct here.
    //
    // The borrow convention also matches ARM64's rather than needing an
    // inversion: subfc/subfe compute rB + ~rA + CA, so CA is the COMPLEMENT of
    // a borrow, exactly as ARM64's SUBS/SBCS treat it.
    //
    // subf-family operands are reversed (subf rt, ra, rb is rb - ra), the same
    // way sub64 above passes them, so dest = a - b.
    void add64AndSetFlags(RegisterID a, RegisterID b, RegisterID dest) { m_assembler.addc(dest, a, b); }
    void addCarry64(RegisterID a, RegisterID b, RegisterID dest) { m_assembler.adde(dest, a, b); }
    void sub64AndSetFlags(RegisterID a, RegisterID b, RegisterID dest) { m_assembler.subfc(dest, b, a); }
    void subBorrow64(RegisterID a, RegisterID b, RegisterID dest) { m_assembler.subfe(dest, b, a); }

    void sub64(TrustedImm32 imm, RegisterID dest) { addImmediate64(dest, -static_cast<int64_t>(imm.m_value), dest); }
    void sub64(RegisterID src, TrustedImm32 imm, RegisterID dest) { addImmediate64(src, -static_cast<int64_t>(imm.m_value), dest); }

    void sub64(TrustedImm64 imm, RegisterID dest) { sub64(dest, imm, dest); }

    void sub64(RegisterID src, TrustedImm64 imm, RegisterID dest)
    {
        // -INT64_MIN is not representable, so that one value cannot be turned
        // into an addition and goes through a register instead.
        if (imm.m_value != std::numeric_limits<int64_t>::min()) {
            addImmediate64(src, -imm.m_value, dest);
            return;
        }
        auto temp = temps<Data>();
        m_assembler.loadImmediate64(temp.data(), imm.m_value);
        m_assembler.subf(dest, temp.data(), src);
    }
    // ---- multiply / divide ----

    void mul32(RegisterID src, RegisterID dest) { mul32(src, dest, dest); }

    void mul32(RegisterID a, RegisterID b, RegisterID dest)
    {
        // mullw takes the low words of its operands and produces the low 32
        // bits of the product, so the 32-bit invariant on the inputs is
        // irrelevant here and only the result needs re-masking.
        m_assembler.mullw(dest, a, b);
        maskLow32(dest);
    }

    void mul32(TrustedImm32 imm, RegisterID src, RegisterID dest)
    {
        if (Assembler::isValidSigned16(imm.m_value)) {
            m_assembler.mulli(dest, src, imm.m_value);
            maskLow32(dest);
            return;
        }
        auto temp = temps<Data>();
        loadImmediate(imm, temp.data());
        mul32(temp.data(), src, dest);
    }

    // dest = minuend - mulLeft * mulRight
    void multiplySub32(RegisterID mulLeft, RegisterID mulRight, RegisterID minuend, RegisterID dest)
    {
        auto temp = temps<Data>();
        m_assembler.mullw(temp.data(), mulLeft, mulRight);
        m_assembler.subf(dest, temp.data(), minuend);
        maskLow32(dest);
    }

    // ---- integer division ----
    //
    // The POWER ISA leaves the divide instructions UNDEFINED for two inputs:
    // a divisor of zero, and (for the signed forms) the most negative number
    // divided by -1. ARM64 defines both -- sdiv/udiv return 0 for a zero
    // divisor and INT_MIN for INT_MIN/-1 -- and JSC's shared code is written
    // against the ARM64 guarantees, so these four reproduce them.
    //
    // What POWER9 actually returns, measured rather than assumed, by
    // `divprobe.c` next to this port's notes `[MEASURED]`:
    //
    //     divd  INT64_MIN / -1 -> 0          ARM64: INT64_MIN
    //     divw  INT32_MIN / -1 -> 0          ARM64: INT32_MIN
    //     divd / divw / divdu / divwu  x / 0 -> 0    ARM64: 0
    //
    // So the zero-divisor case happens to agree on this machine and the
    // INT_MIN case does not. Both are still architecturally undefined, and
    // relying on a measured-but-undefined result is precisely the class of
    // mistake this port keeps finding, so both are made explicit. None of
    // this is on a path where three extra fixed-point instructions matter
    // next to a divide.
    //
    // The INT_MIN/-1 correction is exact rather than a patch-up: x / -1 is
    // -x for every x, INT_MIN included, because `neg` wraps INT_MIN to
    // itself. So when the divisor is -1 the undefined quotient is simply
    // discarded in favour of `neg dividend`. The selects are `isel`, so
    // there is no branch, and the undefined divide is harmless to execute --
    // PowerPC integer division never traps, it only leaves RT undefined (and
    // sets OV, which nothing here reads).
    //
    // dest may alias either operand: it is written only by the final isel,
    // after every read of dividend and divisor.

    void div32(RegisterID dividend, RegisterID divisor, RegisterID dest)
    {
        // 32-bit signed divide done at 64 bits on sign-extended operands.
        // -2^31 / -1 is then an ordinary 64-bit 2^31 whose low word is
        // 0x80000000, bit for bit ARM64's answer, so the INT_MIN case needs
        // no correction here -- only the zero divisor does. The operands must
        // be sign-extended because this port keeps 32-bit values
        // zero-extended (see the invariant above).
        auto temp = temps<Data, Memory>();
        m_assembler.extsw(temp.data(), dividend);
        m_assembler.extsw(temp.memory(), divisor);
        m_assembler.divd(temp.data(), temp.data(), temp.memory());
        m_assembler.li(temp.memory(), 0);
        // cmpwi reads only the low word, which is the whole of a 32-bit
        // divisor whichever way its upper half is extended.
        emitSelect(emitCompare32(Equal, divisor, TrustedImm32(0)), temp.memory(), temp.data(), dest);
        maskLow32(dest);
    }

    void div64(RegisterID dividend, RegisterID divisor, RegisterID dest)
    {
        // At 64 bits there is no wider type to escape into, so INT64_MIN / -1
        // has to be answered directly. `neg` is that answer.
        auto temp = temps<Data, Memory>();
        m_assembler.divd(temp.data(), dividend, divisor);
        m_assembler.neg(temp.memory(), dividend);
        emitSelect(emitCompare64(Equal, divisor, static_cast<int64_t>(-1)), temp.memory(), temp.data(), temp.data());
        m_assembler.li(temp.memory(), 0);
        emitSelect(emitCompare64(Equal, divisor, static_cast<int64_t>(0)), temp.memory(), temp.data(), dest);
    }

    void uDiv32(RegisterID dividend, RegisterID divisor, RegisterID dest)
    {
        // Unsigned has no INT_MIN case; only the zero divisor is undefined.
        // divwu reads the low words directly, so the zero-extension invariant
        // is all the preparation it needs.
        auto temp = temps<Data, Memory>();
        m_assembler.divwu(temp.data(), dividend, divisor);
        m_assembler.li(temp.memory(), 0);
        emitSelect(emitCompare32(Equal, divisor, TrustedImm32(0)), temp.memory(), temp.data(), dest);
        maskLow32(dest);
    }

    void uDiv64(RegisterID dividend, RegisterID divisor, RegisterID dest)
    {
        auto temp = temps<Data, Memory>();
        m_assembler.divdu(temp.data(), dividend, divisor);
        m_assembler.li(temp.memory(), 0);
        emitSelect(emitCompare64(Equal, divisor, static_cast<int64_t>(0)), temp.memory(), temp.data(), dest);
    }

    void mul64(RegisterID src, RegisterID dest) { m_assembler.mulld(dest, dest, src); }
    void mul64(RegisterID a, RegisterID b, RegisterID dest) { m_assembler.mulld(dest, a, b); }

    // The unsigned high half of a 64x64 product. ARM64 spells this umulh;
    // POWER spells it mulhdu. AssemblyHelpers::rapidHashMix64 needs it to
    // fold lo^hi, and its ARM64 arm is otherwise architecture-neutral.
    void uMulHigh64(RegisterID left, RegisterID right, RegisterID dest)
    {
        m_assembler.mulhdu(dest, left, right);
    }

    // ---- bitfields ----
    //
    // These are PowerPC's home ground: rldicl/rlwinm do a rotate and a mask
    // in one instruction, so ARM64's ubfx/ubfiz map across exactly.

    // dest = (src >> lsb) & ((1 << width) - 1), within 32 bits.
    void extractUnsignedBitfield32(RegisterID src, TrustedImm32 lsb, TrustedImm32 width, RegisterID dest)
    {
        uint32_t shift = static_cast<uint32_t>(lsb.m_value);
        uint32_t bits = static_cast<uint32_t>(width.m_value);
        RELEASE_ASSERT(shift < 32 && bits >= 1 && bits <= 32 && shift + bits <= 32);
        // Rotate right by `shift` (i.e. left by 64 - shift) and clear all but
        // the low `bits`. Done in the 64-bit form so the result is
        // zero-extended and the 32-bit invariant holds.
        m_assembler.rldicl(dest, src, (64 - shift) & 63, 64 - bits);
    }

    void extractUnsignedBitfield64(RegisterID src, TrustedImm32 lsb, TrustedImm32 width, RegisterID dest)
    {
        uint32_t shift = static_cast<uint32_t>(lsb.m_value);
        uint32_t bits = static_cast<uint32_t>(width.m_value);
        RELEASE_ASSERT(shift < 64 && bits >= 1 && bits <= 64 && shift + bits <= 64);
        m_assembler.rldicl(dest, src, (64 - shift) & 63, 64 - bits);
    }

    // dest = (src & ((1 << width) - 1)) << lsb
    void insertUnsignedBitfieldInZero32(RegisterID src, TrustedImm32 lsb, TrustedImm32 width, RegisterID dest)
    {
        uint32_t shift = static_cast<uint32_t>(lsb.m_value);
        uint32_t bits = static_cast<uint32_t>(width.m_value);
        RELEASE_ASSERT(shift < 32 && bits >= 1 && bits <= 32 && shift + bits <= 32);
        // rldic rotates left by `shift` then clears the top (64 - shift -
        // bits) bits, which is exactly "mask to width, then shift up".
        m_assembler.rldic(dest, src, shift, 64 - shift - bits);
    }

    void insertUnsignedBitfieldInZero64(RegisterID src, TrustedImm32 lsb, TrustedImm32 width, RegisterID dest)
    {
        uint32_t shift = static_cast<uint32_t>(lsb.m_value);
        uint32_t bits = static_cast<uint32_t>(width.m_value);
        RELEASE_ASSERT(shift < 64 && bits >= 1 && bits <= 64 && shift + bits <= 64);
        m_assembler.rldic(dest, src, shift, 64 - shift - bits);
    }

    // ---- bit counting ----

    void countLeadingZeros32(RegisterID src, RegisterID dest) { m_assembler.cntlzw(dest, src); }
    void countLeadingZeros64(RegisterID src, RegisterID dest) { m_assembler.cntlzd(dest, src); }

    // cnttzw/cnttzd are ISA 3.0, so POWER8 gets the identity instead:
    //
    //     ctz(x) == popcount(~x & (x - 1))
    //
    // which is also correct for x == 0 -- x - 1 is all ones and ~x is all
    // ones, so the mask is all ones and the count is the full width, exactly
    // what cnttzw/cnttzd return for zero.
    //
    // These USED to RELEASE_ASSERT(hasISA30()) rather than fall back, and that
    // was a POWER8 crash rather than a missing optimisation. The callers are
    // not obscure: i32.ctz and i64.ctz in both wasm JITs, and YarrJIT, which
    // means ordinary JavaScript regexps. A baseline-pool build would have
    // aborted on the first one.
    //
    // The temp is needed for two reasons, not one: dest may alias src, and
    // addi's RA field has to hold the source -- r0 there reads as the literal
    // zero. src comes from the register allocator, which never hands out r0.
    void countTrailingZeros32(RegisterID src, RegisterID dest)
    {
        if (Assembler::hasISA30()) {
            m_assembler.cnttzw(dest, src);
            return;
        }
        ASSERT(src != PPC64Registers::r0);
        auto temp = temps<Data>();
        m_assembler.addi(temp.data(), src, -1);
        m_assembler.andc(temp.data(), temp.data(), src);
        // popcntw counts EACH WORD separately, so the high word holds the
        // count of the temp's high word and has to be masked off.
        m_assembler.popcntw(dest, temp.data());
        maskLow32(dest);
    }

    void countTrailingZeros64(RegisterID src, RegisterID dest)
    {
        if (Assembler::hasISA30()) {
            m_assembler.cnttzd(dest, src);
            return;
        }
        ASSERT(src != PPC64Registers::r0);
        auto temp = temps<Data>();
        m_assembler.addi(temp.data(), src, -1);
        m_assembler.andc(temp.data(), temp.data(), src);
        // popcntd counts the whole doubleword, so no mask.
        m_assembler.popcntd(dest, temp.data());
    }

    // ---- byte swaps ----
    //
    // There is no register-to-register byte-reverse before POWER10's brh/brw/
    // brd, so these are done with rotate-and-mask inserts, which is what gcc
    // and clang emit for __builtin_bswap on POWER9.

    void byteSwap16(RegisterID reg)
    {
        auto temp = temps<Data>();
        // result = (reg >> 8 & 0xff) | (reg << 8 & 0xff00), zero-extended.
        m_assembler.rlwinm(temp.data(), reg, 8, 16, 23);  // byte 0 -> byte 1
        m_assembler.rlwinm(reg, reg, 24, 24, 31);         // byte 1 -> byte 0
        m_assembler.or_(reg, reg, temp.data());
        m_assembler.clrldi(reg, reg, 48);
    }

    void byteSwap32(RegisterID reg)
    {
        auto temp = temps<Data>();
        // rotate left 8 gives bytes 2,1,0,3 in the low word; inserting the
        // rotate-left-24 value into byte positions 0 and 2 completes the
        // reversal. This is the classic PowerPC four-instruction bswap.
        m_assembler.rlwinm(temp.data(), reg, 8, 0, 31);   // rotate left 8
        m_assembler.rlwimi(temp.data(), reg, 24, 0, 7);   // insert byte
        m_assembler.rlwimi(temp.data(), reg, 24, 16, 23); // insert byte
        m_assembler.mr(reg, temp.data());
        maskLow32(reg);
    }

    void byteSwap64(RegisterID reg)
    {
        // Reverse each 32-bit half, then swap the halves.
        auto temp = temps<Data, Memory>();
        m_assembler.srdi(temp.memory(), reg, 32); // high word
        byteSwap32(reg);                          // low word reversed (uses data temp)
        byteSwap32(temp.memory());                // high word reversed
        m_assembler.sldi(reg, reg, 32);
        m_assembler.or_(reg, reg, temp.memory());
    }
    // ---- shifts and rotates ----
    //
    // Two PowerPC facts drive all of these:
    //
    //  1. slw/srw/sraw consume SIX bits of the shift count and sld/srd/srad
    //     SEVEN, so a count of 32 (or 64) produces zero rather than wrapping.
    //     x86 and ARM mask the count to 5 (or 6) bits, and JSC's semantics
    //     are x86's, so a register count must be masked before use. Skipping
    //     this is a silent wrong answer only for counts >= 32, which is
    //     exactly the case a test suite is least likely to cover.
    //  2. sraw/srawi propagate the sign into the upper word, so an arithmetic
    //     32-bit right shift breaks the zero-extension invariant and has to
    //     be re-masked.

    // Put (shiftAmount & mask) somewhere usable, without disturbing dest.
    RegisterID maskedShiftCount(RegisterID shiftAmount, unsigned mask, RegisterID scratch)
    {
        m_assembler.andi_(scratch, shiftAmount, mask);
        return scratch;
    }

    // Where the masked shift count lives.
    //
    // POWER's slw/srw/sld/srd do not mask their count the way x86 and ARM64
    // do -- a count of 32 or more yields zero rather than count & 31 -- so the
    // mask is real work and it needs a register. `dest` can be that register
    // whenever it is not also `src`: the mask is written first and the shift
    // reads it, so the only operand that could be lost is src.
    //
    // That matters because Air generates with the macro scratch registers
    // forbidden (AirGenerate.cpp:183,
    // AirAllocateRegistersAndStackAndGenerateCode.cpp:540), and Air's
    // three-operand shift forms normally hand us a fresh dest. The aliased
    // case is still correct and still reaches for the data temp; it is simply
    // only reachable if the allocator has coalesced dest with src, and it
    // fails loudly rather than quietly if it happens under Air.
    RegisterID shiftCountScratch(RegisterID src, RegisterID dest)
    {
        if (dest != src)
            return dest;
        auto temp = temps<Data>();
        return temp.data();
    }

    void lshift32(RegisterID src, RegisterID shiftAmount, RegisterID dest)
    {
        RegisterID count = maskedShiftCount(shiftAmount, 31, shiftCountScratch(src, dest));
        m_assembler.slw(dest, src, count);
        maskLow32(dest);
    }

    // The Air form of this takes its scratch as a fourth operand, so that the
    // register allocator provides it and no macro scratch is needed. See the
    // ppc64 entry for Lshift32 in AirOpcode.opcodes.
    void lshift32(RegisterID src, RegisterID shiftAmount, RegisterID dest, RegisterID scratch)
    {
        m_assembler.slw(dest, src, maskedShiftCount(shiftAmount, 31, scratch));
        maskLow32(dest);
    }

    void lshift32(RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        uint32_t shift = static_cast<uint32_t>(imm.m_value) & 0x1f;
        if (!shift) {
            move(src, dest);
            return;
        }
        m_assembler.slwi(dest, src, shift);
        maskLow32(dest);
    }

    void lshift32(TrustedImm32 imm, RegisterID shiftAmount, RegisterID dest)
    {
        auto temp = temps<Memory>();
        loadImmediate(imm, temp.memory());
        lshift32(temp.memory(), shiftAmount, dest);
    }

    void lshift32(RegisterID shiftAmount, RegisterID dest) { lshift32(dest, shiftAmount, dest); }
    void lshift32(TrustedImm32 imm, RegisterID dest) { lshift32(dest, imm, dest); }

    void lshift32(Address address, RegisterID shiftAmount, RegisterID dest)
    {
        auto temp = temps<Memory>();
        load32(address, temp.memory());
        lshift32(temp.memory(), shiftAmount, dest);
    }

    void lshift64(RegisterID src, RegisterID shiftAmount, RegisterID dest)
    {
        RegisterID count = maskedShiftCount(shiftAmount, 63, shiftCountScratch(src, dest));
        m_assembler.sld(dest, src, count);
    }

    void lshift64(RegisterID src, RegisterID shiftAmount, RegisterID dest, RegisterID scratch)
    {
        m_assembler.sld(dest, src, maskedShiftCount(shiftAmount, 63, scratch));
    }

    void lshift64(RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        uint32_t shift = static_cast<uint32_t>(imm.m_value) & 0x3f;
        if (!shift) {
            move(src, dest);
            return;
        }
        m_assembler.sldi(dest, src, shift);
    }

    void lshift64(TrustedImm32 imm, RegisterID shiftAmount, RegisterID dest)
    {
        auto temp = temps<Memory>();
        loadImmediate(imm, temp.memory());
        lshift64(temp.memory(), shiftAmount, dest);
    }

    void lshift64(RegisterID shiftAmount, RegisterID dest) { lshift64(dest, shiftAmount, dest); }
    void lshift64(TrustedImm32 imm, RegisterID dest) { lshift64(dest, imm, dest); }

    void lshift64(Address address, RegisterID shiftAmount, RegisterID dest)
    {
        auto temp = temps<Memory>();
        load64(address, temp.memory());
        lshift64(temp.memory(), shiftAmount, dest);
    }

    // Arithmetic (sign-propagating) right shift.
    void rshift32(RegisterID src, RegisterID shiftAmount, RegisterID dest)
    {
        RegisterID count = maskedShiftCount(shiftAmount, 31, shiftCountScratch(src, dest));
        m_assembler.sraw(dest, src, count);
        maskLow32(dest);
    }

    void rshift32(RegisterID src, RegisterID shiftAmount, RegisterID dest, RegisterID scratch)
    {
        m_assembler.sraw(dest, src, maskedShiftCount(shiftAmount, 31, scratch));
        maskLow32(dest);
    }

    void rshift32(RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        uint32_t shift = static_cast<uint32_t>(imm.m_value) & 0x1f;
        if (!shift) {
            move(src, dest);
            return;
        }
        m_assembler.srawi(dest, src, shift);
        maskLow32(dest);
    }

    void rshift32(TrustedImm32 imm, RegisterID shiftAmount, RegisterID dest)
    {
        auto temp = temps<Memory>();
        loadImmediate(imm, temp.memory());
        rshift32(temp.memory(), shiftAmount, dest);
    }

    void rshift32(RegisterID shiftAmount, RegisterID dest) { rshift32(dest, shiftAmount, dest); }
    void rshift32(TrustedImm32 imm, RegisterID dest) { rshift32(dest, imm, dest); }

    void rshift64(RegisterID src, RegisterID shiftAmount, RegisterID dest)
    {
        RegisterID count = maskedShiftCount(shiftAmount, 63, shiftCountScratch(src, dest));
        m_assembler.srad(dest, src, count);
    }

    void rshift64(RegisterID src, RegisterID shiftAmount, RegisterID dest, RegisterID scratch)
    {
        m_assembler.srad(dest, src, maskedShiftCount(shiftAmount, 63, scratch));
    }

    void rshift64(RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        uint32_t shift = static_cast<uint32_t>(imm.m_value) & 0x3f;
        if (!shift) {
            move(src, dest);
            return;
        }
        m_assembler.sradi(dest, src, shift);
    }

    void rshift64(RegisterID shiftAmount, RegisterID dest) { rshift64(dest, shiftAmount, dest); }
    void rshift64(TrustedImm32 imm, RegisterID dest) { rshift64(dest, imm, dest); }

    // Logical (zero-filling) right shift. The 32-bit form relies on the
    // invariant: srw shifts the whole 64-bit register, so bits 32:63 must
    // already be zero for the low word to be shifted in isolation. They are,
    // by construction.
    void urshift32(RegisterID src, RegisterID shiftAmount, RegisterID dest)
    {
        RegisterID count = maskedShiftCount(shiftAmount, 31, shiftCountScratch(src, dest));
        m_assembler.srw(dest, src, count);
        maskLow32(dest);
    }

    void urshift32(RegisterID src, RegisterID shiftAmount, RegisterID dest, RegisterID scratch)
    {
        m_assembler.srw(dest, src, maskedShiftCount(shiftAmount, 31, scratch));
        maskLow32(dest);
    }

    void urshift32(RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        uint32_t shift = static_cast<uint32_t>(imm.m_value) & 0x1f;
        if (!shift) {
            move(src, dest);
            return;
        }
        m_assembler.srwi(dest, src, shift);
        maskLow32(dest);
    }

    void urshift32(TrustedImm32 imm, RegisterID shiftAmount, RegisterID dest)
    {
        auto temp = temps<Memory>();
        loadImmediate(imm, temp.memory());
        urshift32(temp.memory(), shiftAmount, dest);
    }

    void urshift32(RegisterID shiftAmount, RegisterID dest) { urshift32(dest, shiftAmount, dest); }
    void urshift32(TrustedImm32 imm, RegisterID dest) { urshift32(dest, imm, dest); }

    void urshift64(RegisterID src, RegisterID shiftAmount, RegisterID dest)
    {
        RegisterID count = maskedShiftCount(shiftAmount, 63, shiftCountScratch(src, dest));
        m_assembler.srd(dest, src, count);
    }

    void urshift64(RegisterID src, RegisterID shiftAmount, RegisterID dest, RegisterID scratch)
    {
        m_assembler.srd(dest, src, maskedShiftCount(shiftAmount, 63, scratch));
    }

    void urshift64(RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        uint32_t shift = static_cast<uint32_t>(imm.m_value) & 0x3f;
        if (!shift) {
            move(src, dest);
            return;
        }
        m_assembler.srdi(dest, src, shift);
    }

    void urshift64(RegisterID shiftAmount, RegisterID dest) { urshift64(dest, shiftAmount, dest); }
    void urshift64(TrustedImm32 imm, RegisterID dest) { urshift64(dest, imm, dest); }

    // d = n + (m >>> amount), 32-bit.
    void addUnsignedRightShift32(RegisterID n, RegisterID m, TrustedImm32 amount, RegisterID d)
    {
        auto temp = temps<Memory>();
        urshift32(m, amount, temp.memory());
        add32(n, temp.memory(), d);
    }

    // Rotates are native on PowerPC, in both widths.
    void rotateRight32(RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        uint32_t shift = static_cast<uint32_t>(imm.m_value) & 31;
        m_assembler.rotlwi(dest, src, (32 - shift) & 31);
        maskLow32(dest);
    }

    void rotateRight32(TrustedImm32 imm, RegisterID srcDst) { rotateRight32(srcDst, imm, srcDst); }

    void rotateRight32(RegisterID src, RegisterID shiftAmount, RegisterID dest)
    {
        // Rotating right by n is rotating left by 32 - n. subfic computes
        // 32 - shiftAmount in one instruction.
        rotateRight32(src, shiftAmount, dest, shiftCountScratch(src, dest));
    }

    void rotateRight32(RegisterID src, RegisterID shiftAmount, RegisterID dest, RegisterID scratch)
    {
        m_assembler.subfic(scratch, shiftAmount, 32);
        m_assembler.andi_(scratch, scratch, 31);
        m_assembler.rlwnm(dest, src, scratch, 0, 31);
        maskLow32(dest);
    }

    void rotateRight64(RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        uint32_t shift = static_cast<uint32_t>(imm.m_value) & 63;
        m_assembler.rotldi(dest, src, (64 - shift) & 63);
    }

    void rotateRight64(TrustedImm32 imm, RegisterID srcDst) { rotateRight64(srcDst, imm, srcDst); }

    void rotateRight64(RegisterID src, RegisterID shiftAmount, RegisterID dest)
    {
        rotateRight64(src, shiftAmount, dest, shiftCountScratch(src, dest));
    }

    void rotateRight64(RegisterID src, RegisterID shiftAmount, RegisterID dest, RegisterID scratch)
    {
        m_assembler.subfic(scratch, shiftAmount, 64);
        m_assembler.andi_(scratch, scratch, 63);
        m_assembler.rldcl(dest, src, scratch, 0);
    }

    // Rotate LEFT is the native direction on this target -- rlwnm and rldcl
    // rotate left -- which is why rotateRight above spends a subfic and a
    // scratch register to turn n into width - n, and why these need neither.
    // rlwnm reads the low five bits of the shift register and rldcl the low
    // six, so the count needs no masking either.
    void rotateLeft32(RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        m_assembler.rotlwi(dest, src, static_cast<uint32_t>(imm.m_value) & 31);
        maskLow32(dest);
    }

    void rotateLeft32(RegisterID src, RegisterID shiftAmount, RegisterID dest)
    {
        m_assembler.rlwnm(dest, src, shiftAmount, 0, 31);
        maskLow32(dest);
    }

    void rotateLeft64(RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        m_assembler.rotldi(dest, src, static_cast<uint32_t>(imm.m_value) & 63);
    }

    void rotateLeft64(RegisterID src, RegisterID shiftAmount, RegisterID dest)
    {
        m_assembler.rldcl(dest, src, shiftAmount, 0);
    }

    // The address-dependency trick B3 uses for consume ordering: XOR a register
    // with itself is zero, and carries a data dependency on it. ARM64 spells it
    // eor<32>(dest, src, src); PPC's xor is width-agnostic and the result is
    // zero either way, so one instruction serves both widths.
    void depend32(RegisterID src, RegisterID dest) { m_assembler.xor_(dest, src, src); }
    void depend64(RegisterID src, RegisterID dest) { m_assembler.xor_(dest, src, src); }

    // Lea64 of a base+index. x86-64 needs this form for its addressing modes;
    // this target needs it because AirLowerStackArgs' extended-offset path
    // BUILDS one -- POWER's X-form is base+index with no displacement, so a
    // stack offset too large for D-form is materialised into
    // extendedOffsetAddrRegister() (r0) and ridden as the INDEX while sp stays
    // the base. r0 may be an index and never a base, which is why that path
    // cannot hand back an Arg::addr the way the ARM64 arm does. A 736-byte
    // frame already exceeds D-form reach for the SP-relative form, so
    // testStackSlot reaches it with one 1-byte slot.
    //
    // Everything stages in dest, which is what makes this safe regardless of
    // the scratch policy. Arg::isValidScale accepts only scale 1 on this
    // target, so the scaled branch below is unreachable from Air; it is kept
    // for any direct caller.
    void leaIndex64(BaseIndex address, RegisterID dest)
    {
        if (address.scale == TimesOne)
            m_assembler.add(dest, address.base, address.index);
        else {
            // Shifting into dest first would clobber base before it is read, and
            // there is no third register to borrow. Nothing Air builds has both a
            // scale and dest == base; if that changes this needs a Scratch operand.
            RELEASE_ASSERT(dest != address.base);
            m_assembler.sldi(dest, address.index, static_cast<uint32_t>(address.scale));
            m_assembler.add(dest, address.base, dest);
        }
        if (address.offset)
            addImmediate64(dest, static_cast<int64_t>(address.offset), dest);
    }

    // ---- loads ----
    //
    // Every load comes in three flavours (Address / BaseIndex / raw pointer)
    // and they all funnel into loadImpl, which picks the D-form (base +
    // displacement) or X-form (base + index) encoding. POWER8 and later
    // handle unaligned loads and stores in hardware for all of these widths,
    // so there is no aligned/unaligned distinction to make -- which is why
    // load16Unaligned and load32WithUnalignedHalfWords are just the ordinary
    // loads.

    enum class LoadKind { U8, S8, U16, S16, U32, S32, U64 };

    // POWER's X-form indexed loads and stores are base + index, with no
    // displacement field and no scaling, which is exactly the shape Air asks
    // for on this target: Arg::isValidScale accepts only 1 here, and
    // Arg::isValidIndexForm allows a displacement only for Lea, which
    // computes an address rather than accessing memory.
    //
    // Taking the form still matters for the add it saves. It is no longer a
    // hard requirement, though: AirGenerate.cpp and
    // AirAllocateRegistersAndStackAndGenerateCode.cpp both re-enable the macro
    // scratch under isPPC64() -- r29 and r30 are isReserved, so the allocator
    // cannot have handed either to a live Tmp -- which is what lets the
    // Address forms fold an out-of-form displacement through
    // memoryTempRegister instead of refusing it.
    //
    // RA is the base and RB the index, never the other way round: r0 in the RA
    // field of any load or store encodes the literal zero rather than the
    // register, which is measured in the handbook and is the whole reason
    // extendedOffsetAddrRegister() can be r0 at all.
    //
    // isXFormBaseIndex is true for exactly the BaseIndex shapes the X-form
    // encodes directly, which is also exactly the set Air is allowed to build
    // on this target.
    static bool isXFormBaseIndex(BaseIndex address)
    {
        return address.scale == TimesOne && !address.offset;
    }

    void emitLoadDForm(LoadKind kind, RegisterID base, int32_t offset, RegisterID dest)
    {
        switch (kind) {
        case LoadKind::U8:  m_assembler.lbz(dest, base, offset); return;
        case LoadKind::S8:  m_assembler.lbz(dest, base, offset); m_assembler.extsb(dest, dest); return;
        case LoadKind::U16: m_assembler.lhz(dest, base, offset); return;
        case LoadKind::S16: m_assembler.lha(dest, base, offset); return;
        case LoadKind::U32: m_assembler.lwz(dest, base, offset); return;
        case LoadKind::S32: m_assembler.lwa(dest, base, offset); return;
        case LoadKind::U64: m_assembler.ld(dest, base, offset); return;
        }
        RELEASE_ASSERT_NOT_REACHED();
    }

    void emitLoadXForm(LoadKind kind, RegisterID base, RegisterID index, RegisterID dest)
    {
        ASSERT(base != PPC64Registers::r0);
        switch (kind) {
        case LoadKind::U8:  m_assembler.lbzx(dest, base, index); return;
        case LoadKind::S8:  m_assembler.lbzx(dest, base, index); m_assembler.extsb(dest, dest); return;
        case LoadKind::U16: m_assembler.lhzx(dest, base, index); return;
        case LoadKind::S16: m_assembler.lhax(dest, base, index); return;
        case LoadKind::U32: m_assembler.lwzx(dest, base, index); return;
        case LoadKind::S32: m_assembler.lwax(dest, base, index); return;
        case LoadKind::U64: m_assembler.ldx(dest, base, index); return;
        }
        RELEASE_ASSERT_NOT_REACHED();
    }

    static bool loadKindNeedsDSForm(LoadKind kind) { return kind == LoadKind::U64 || kind == LoadKind::S32; }

    void loadImpl(LoadKind kind, Address address, RegisterID dest)
    {
        auto temp = lazyTemp<Memory>();
        auto resolution = resolveAddress(address, temp, loadKindNeedsDSForm(kind));
        emitLoadDForm(kind, resolution.base, resolution.offset, dest);
    }

    void loadImpl(LoadKind kind, BaseIndex address, RegisterID dest)
    {
        if (isXFormBaseIndex(address)) {
            emitLoadXForm(kind, address.base, address.index, dest);
            return;
        }
        auto temp = temps<Memory>();
        auto resolution = resolveAddress(address, temp.memory(), loadKindNeedsDSForm(kind));
        emitLoadDForm(kind, resolution.base, resolution.offset, dest);
    }

    void loadImpl(LoadKind kind, const void* pointer, RegisterID dest)
    {
        auto temp = temps<Memory>();
        loadImmediate(TrustedImmPtr(pointer), temp.memory());
        emitLoadDForm(kind, temp.memory(), 0, dest);
    }

    void load8(Address address, RegisterID dest) { loadImpl(LoadKind::U8, address, dest); }
    void load8(BaseIndex address, RegisterID dest) { loadImpl(LoadKind::U8, address, dest); }
    void load8(const void* address, RegisterID dest) { loadImpl(LoadKind::U8, address, dest); }

    // "SignedExtendTo32" means the byte is sign-extended into the low word
    // and the register still satisfies the 32-bit zero-extension invariant,
    // i.e. bits 32:63 are clear. extsb sign-extends all the way to 64, so the
    // upper half has to be cleared again afterwards. Missing that would leave
    // a value that compares correctly with cmpw but boxes into a corrupt
    // JSValue.
    void load8SignedExtendTo32(Address address, RegisterID dest) { loadImpl(LoadKind::S8, address, dest); maskLow32(dest); }
    void load8SignedExtendTo32(BaseIndex address, RegisterID dest) { loadImpl(LoadKind::S8, address, dest); maskLow32(dest); }
    void load8SignedExtendTo32(const void* address, RegisterID dest) { loadImpl(LoadKind::S8, address, dest); maskLow32(dest); }

    void load8SignedExtendTo64(Address address, RegisterID dest) { loadImpl(LoadKind::S8, address, dest); }
    void load8SignedExtendTo64(BaseIndex address, RegisterID dest) { loadImpl(LoadKind::S8, address, dest); }
    void load8SignedExtendTo64(const void* address, RegisterID dest) { loadImpl(LoadKind::S8, address, dest); }

    void load16(Address address, RegisterID dest) { loadImpl(LoadKind::U16, address, dest); }
    void load16(BaseIndex address, RegisterID dest) { loadImpl(LoadKind::U16, address, dest); }
    void load16(const void* address, RegisterID dest) { loadImpl(LoadKind::U16, address, dest); }

    void load16(ExtendedAddress address, RegisterID dest)
    {
        auto temp = temps<Memory>();
        auto resolution = resolveAddress(address, temp.memory(), false);
        m_assembler.lhz(dest, resolution.base, resolution.offset);
    }

    // POWER8+ does unaligned accesses in hardware; there is nothing to do
    // differently here.
    void load16Unaligned(Address address, RegisterID dest) { load16(address, dest); }
    void load16Unaligned(BaseIndex address, RegisterID dest) { load16(address, dest); }

    void load16SignedExtendTo32(Address address, RegisterID dest) { loadImpl(LoadKind::S16, address, dest); maskLow32(dest); }
    void load16SignedExtendTo32(BaseIndex address, RegisterID dest) { loadImpl(LoadKind::S16, address, dest); maskLow32(dest); }
    void load16SignedExtendTo32(const void* address, RegisterID dest) { loadImpl(LoadKind::S16, address, dest); maskLow32(dest); }

    void load16SignedExtendTo64(Address address, RegisterID dest) { loadImpl(LoadKind::S16, address, dest); }
    void load16SignedExtendTo64(BaseIndex address, RegisterID dest) { loadImpl(LoadKind::S16, address, dest); }
    void load16SignedExtendTo64(const void* address, RegisterID dest) { loadImpl(LoadKind::S16, address, dest); }

    void load32SignedExtendTo64(Address address, RegisterID dest) { loadImpl(LoadKind::S32, address, dest); }
    void load32SignedExtendTo64(BaseIndex address, RegisterID dest) { loadImpl(LoadKind::S32, address, dest); }
    void load32SignedExtendTo64(const void* address, RegisterID dest) { loadImpl(LoadKind::S32, address, dest); }

    // lwz zero-extends, so load32 satisfies the 32-bit invariant for free.
    void load32(Address address, RegisterID dest) { loadImpl(LoadKind::U32, address, dest); }
    void load32(BaseIndex address, RegisterID dest) { loadImpl(LoadKind::U32, address, dest); }
    void load32(const void* address, RegisterID dest) { loadImpl(LoadKind::U32, address, dest); }
    void load32WithUnalignedHalfWords(BaseIndex address, RegisterID dest) { load32(address, dest); }

    void load64(Address address, RegisterID dest) { loadImpl(LoadKind::U64, address, dest); }
    void load64(BaseIndex address, RegisterID dest) { loadImpl(LoadKind::U64, address, dest); }
    void load64(const void* address, RegisterID dest) { loadImpl(LoadKind::U64, address, dest); }
    // ---- register pairs ----
    //
    // PowerPC has no load-pair instruction (lmw/stmw are 32-bit only and
    // slow), so these are two accesses. That makes the aliasing question
    // real, in a way it is not for ARM64's atomic ldp: if the first
    // destination is also the base register, loading into it first destroys
    // the address the second load needs. The order is chosen to avoid that.
    void loadPair64(RegisterID base, TrustedImm32 offset, RegisterID dest1, RegisterID dest2)
    {
        Address first(base, offset.m_value);
        Address second(base, offset.m_value + 8);
        if (dest1 == base) {
            load64(second, dest2);
            load64(first, dest1);
            return;
        }
        load64(first, dest1);
        load64(second, dest2);
    }

    void loadPair64(RegisterID base, RegisterID dest1, RegisterID dest2) { loadPair64(base, TrustedImm32(0), dest1, dest2); }
    void loadPair64(Address address, RegisterID dest1, RegisterID dest2) { loadPair64(address.base, TrustedImm32(address.offset), dest1, dest2); }

    void loadPair32(RegisterID base, TrustedImm32 offset, RegisterID dest1, RegisterID dest2)
    {
        Address first(base, offset.m_value);
        Address second(base, offset.m_value + 4);
        if (dest1 == base) {
            load32(second, dest2);
            load32(first, dest1);
            return;
        }
        load32(first, dest1);
        load32(second, dest2);
    }

    void loadPair32(RegisterID base, RegisterID dest1, RegisterID dest2) { loadPair32(base, TrustedImm32(0), dest1, dest2); }
    void loadPair32(Address address, RegisterID dest1, RegisterID dest2) { loadPair32(address.base, TrustedImm32(address.offset), dest1, dest2); }
    // ---- stores ----

    enum class StoreKind { S8, S16, S32, S64 };

    void emitStoreDForm(StoreKind kind, RegisterID src, RegisterID base, int32_t offset)
    {
        switch (kind) {
        case StoreKind::S8:  m_assembler.stb(src, base, offset); return;
        case StoreKind::S16: m_assembler.sth(src, base, offset); return;
        case StoreKind::S32: m_assembler.stw(src, base, offset); return;
        case StoreKind::S64: m_assembler.std(src, base, offset); return;
        }
        RELEASE_ASSERT_NOT_REACHED();
    }

    void emitStoreXForm(StoreKind kind, RegisterID src, RegisterID base, RegisterID index)
    {
        ASSERT(base != PPC64Registers::r0);
        switch (kind) {
        case StoreKind::S8:  m_assembler.stbx(src, base, index); return;
        case StoreKind::S16: m_assembler.sthx(src, base, index); return;
        case StoreKind::S32: m_assembler.stwx(src, base, index); return;
        case StoreKind::S64: m_assembler.stdx(src, base, index); return;
        }
        RELEASE_ASSERT_NOT_REACHED();
    }

    static bool storeKindNeedsDSForm(StoreKind kind) { return kind == StoreKind::S64; }

    void storeImpl(StoreKind kind, RegisterID src, Address address)
    {
        auto temp = lazyTemp<Memory>();
        auto resolution = resolveAddress(address, temp, storeKindNeedsDSForm(kind));
        emitStoreDForm(kind, src, resolution.base, resolution.offset);
    }

    void storeImpl(StoreKind kind, RegisterID src, BaseIndex address)
    {
        if (isXFormBaseIndex(address)) {
            emitStoreXForm(kind, src, address.base, address.index);
            return;
        }
        auto temp = temps<Memory>();
        auto resolution = resolveAddress(address, temp.memory(), storeKindNeedsDSForm(kind));
        emitStoreDForm(kind, src, resolution.base, resolution.offset);
    }

    void storeImpl(StoreKind kind, RegisterID src, const void* pointer)
    {
        auto temp = temps<Memory>();
        loadImmediate(TrustedImmPtr(pointer), temp.memory());
        emitStoreDForm(kind, src, temp.memory(), 0);
    }

    // Storing an immediate always goes through the data temp. The memory temp
    // is reserved for the address, so the two never collide -- that pairing is
    // the whole reason there are two of them.
    template<typename ImmType, typename AddressType>
    void storeImmImpl(StoreKind kind, ImmType imm, AddressType address)
    {
        auto temp = temps<Data>();
        loadImmediate(imm, temp.data());
        storeImpl(kind, temp.data(), address);
    }

    void store8(RegisterID src, Address address) { storeImpl(StoreKind::S8, src, address); }
    void store8(RegisterID src, BaseIndex address) { storeImpl(StoreKind::S8, src, address); }
    void store8(RegisterID src, const void* address) { storeImpl(StoreKind::S8, src, address); }
    void store8(TrustedImm32 imm, Address address) { storeImmImpl(StoreKind::S8, imm, address); }
    void store8(TrustedImm32 imm, BaseIndex address) { storeImmImpl(StoreKind::S8, imm, address); }
    void store8(TrustedImm32 imm, const void* address) { storeImmImpl(StoreKind::S8, imm, address); }

    void store16(RegisterID src, Address address) { storeImpl(StoreKind::S16, src, address); }
    void store16(RegisterID src, BaseIndex address) { storeImpl(StoreKind::S16, src, address); }
    void store16(RegisterID src, const void* address) { storeImpl(StoreKind::S16, src, address); }
    void store16(TrustedImm32 imm, Address address) { storeImmImpl(StoreKind::S16, imm, address); }
    void store16(TrustedImm32 imm, BaseIndex address) { storeImmImpl(StoreKind::S16, imm, address); }
    void store16(TrustedImm32 imm, const void* address) { storeImmImpl(StoreKind::S16, imm, address); }

    void store32(RegisterID src, Address address) { storeImpl(StoreKind::S32, src, address); }
    void store32(RegisterID src, BaseIndex address) { storeImpl(StoreKind::S32, src, address); }
    void store32(RegisterID src, const void* address) { storeImpl(StoreKind::S32, src, address); }
    void store32(TrustedImm32 imm, Address address) { storeImmImpl(StoreKind::S32, imm, address); }
    void store32(TrustedImm32 imm, BaseIndex address) { storeImmImpl(StoreKind::S32, imm, address); }
    void store32(TrustedImm32 imm, const void* address) { storeImmImpl(StoreKind::S32, imm, address); }

    void store64(RegisterID src, Address address) { storeImpl(StoreKind::S64, src, address); }
    void store64(RegisterID src, BaseIndex address) { storeImpl(StoreKind::S64, src, address); }
    void store64(RegisterID src, const void* address) { storeImpl(StoreKind::S64, src, address); }
    // store64 of a TrustedImm32 stores the SIGN-extended 64-bit value: this
    // is the 64-bit-operand reading, not move()'s zero-extending one.
    void store64(TrustedImm32 imm, Address address)
    {
        auto temp = temps<Data>();
        loadSignExtendedImmediate32(imm.m_value, temp.data());
        storeImpl(StoreKind::S64, temp.data(), address);
    }
    void store64(TrustedImm32 imm, BaseIndex address)
    {
        auto temp = temps<Data>();
        loadSignExtendedImmediate32(imm.m_value, temp.data());
        storeImpl(StoreKind::S64, temp.data(), address);
    }
    void store64(TrustedImm64 imm, Address address) { storeImmImpl(StoreKind::S64, imm, address); }
    void store64(TrustedImm64 imm, BaseIndex address) { storeImmImpl(StoreKind::S64, imm, address); }
    void store64(TrustedImm64 imm, const void* address) { storeImmImpl(StoreKind::S64, imm, address); }
    void store64(TrustedImmPtr imm, Address address) { storeImmImpl(StoreKind::S64, imm, address); }
    void storePair64(RegisterID src1, RegisterID src2, RegisterID base, TrustedImm32 offset)
    {
        store64(src1, Address(base, offset.m_value));
        store64(src2, Address(base, offset.m_value + 8));
    }

    void storePair64(RegisterID src1, RegisterID src2, RegisterID base) { storePair64(src1, src2, base, TrustedImm32(0)); }
    void storePair64(RegisterID src1, RegisterID src2, Address address) { storePair64(src1, src2, address.base, TrustedImm32(address.offset)); }

    void storePair32(RegisterID src1, RegisterID src2, RegisterID base, TrustedImm32 offset)
    {
        store32(src1, Address(base, offset.m_value));
        store32(src2, Address(base, offset.m_value + 4));
    }

    void storePair32(RegisterID src1, RegisterID src2, RegisterID base) { storePair32(src1, src2, base, TrustedImm32(0)); }
    void storePair32(RegisterID src1, RegisterID src2, Address address) { storePair32(src1, src2, address.base, TrustedImm32(address.offset)); }

    // ---- memory-to-memory moves ----
    //
    // These use the DATA temp for the value, leaving the memory temp free for
    // whichever of the two addresses needs materialising. Both addresses are
    // resolved separately, so an overlapping source and destination behaves
    // as a plain copy, which is all JSC asks of them. Templated over the two
    // address types exactly as ARM64's are, because BBQ's emitMoveMemory
    // copies between an Address and a BaseIndex.
    template<typename SrcType, typename DestType>
    void transfer8(SrcType src, DestType dest)
    {
        auto temp = temps<Data>();
        load8(src, temp.data());
        store8(temp.data(), dest);
    }

    template<typename SrcType, typename DestType>
    void transfer16(SrcType src, DestType dest)
    {
        auto temp = temps<Data>();
        load16(src, temp.data());
        store16(temp.data(), dest);
    }

    template<typename SrcType, typename DestType>
    void transfer32(SrcType src, DestType dest)
    {
        auto temp = temps<Data>();
        load32(src, temp.data());
        store32(temp.data(), dest);
    }

    template<typename SrcType, typename DestType>
    void transfer64(SrcType src, DestType dest)
    {
        auto temp = temps<Data>();
        load64(src, temp.data());
        store64(temp.data(), dest);
    }

    void transferPtr(auto src, auto dest) { transfer64(src, dest); }

    // A float or double is moved as raw bits: going through an FPR would
    // canonicalise a signalling NaN, and these are memory copies, not
    // arithmetic.
    void transferFloat(auto src, auto dest) { transfer32(src, dest); }
    void transferDouble(auto src, auto dest) { transfer64(src, dest); }

    // All sixteen bytes, through the FP temp. storeVector's POWER8 arm swaps
    // through fpTempRegister itself, so the value being there already is
    // harmless: the swap happens in place.
    template<typename SrcType, typename DestType>
    void transferVector(SrcType src, DestType dest)
    {
        loadVector(src, fpTempRegister);
        storeVector(fpTempRegister, dest);
    }
    // ---- extensions ----
    //
    // The "To32" variants must leave the register satisfying the 32-bit
    // zero-extension invariant, so the sign-extending ones extend to 64 and
    // then clear the upper half again. That is not redundant: extsb of a
    // negative byte sets bits 32:63, and boxInt32 would then produce a
    // corrupt JSValue.

    void zeroExtend8To32(RegisterID src, RegisterID dest) { m_assembler.clrldi(dest, src, 56); }
    void zeroExtend16To32(RegisterID src, RegisterID dest) { m_assembler.clrldi(dest, src, 48); }
    void zeroExtend32ToWord(RegisterID src, RegisterID dest) { m_assembler.clrldi(dest, src, 32); }

    void signExtend8To32(RegisterID src, RegisterID dest) { m_assembler.extsb(dest, src); maskLow32(dest); }
    void signExtend16To32(RegisterID src, RegisterID dest) { m_assembler.extsh(dest, src); maskLow32(dest); }

    void zeroExtend8To64(RegisterID src, RegisterID dest) { m_assembler.clrldi(dest, src, 56); }
    void zeroExtend16To64(RegisterID src, RegisterID dest) { m_assembler.clrldi(dest, src, 48); }

    void signExtend8To64(RegisterID src, RegisterID dest) { m_assembler.extsb(dest, src); }
    void signExtend16To64(RegisterID src, RegisterID dest) { m_assembler.extsh(dest, src); }

    void signExtend32To64(RegisterID src, RegisterID dest) { m_assembler.extsw(dest, src); }
    void signExtend32To64(TrustedImm32 imm, RegisterID dest) { loadSignExtendedImmediate32(imm.m_value, dest); }

    void signExtend32ToPtr(RegisterID src, RegisterID dest) { signExtend32To64(src, dest); }
    void signExtend32ToPtr(TrustedImm32 imm, RegisterID dest) { signExtend32To64(imm, dest); }
    // ---- logical ----
    //
    // Note on CR0: andi. and andis. are the only AND-immediate encodings, and
    // both write CR0 whether you want it or not. That is harmless here
    // because CR0 is scratch between a compare and its branch -- every
    // comparison in this file emits the compare and the branch as one unit,
    // so nothing else is ever live in CR0 across an unrelated instruction.

    // A 64-bit AND mask that rotate-and-mask can do in one instruction:
    // either the low n bits (clrldi) or all but the low n bits (clrrdi).
    // JSC's masks are frequently of this shape, and the alternative is a
    // five-word constant plus an `and`.
    bool tryAndImmediate64(RegisterID src, uint64_t mask, RegisterID dest)
    {
        if (!mask) {
            m_assembler.li(dest, 0);
            return true;
        }
        if (mask == ~uint64_t(0)) {
            move(src, dest);
            return true;
        }
        // Low run: mask == 2^n - 1.
        if (!(mask & (mask + 1))) {
            unsigned n = WTF::fastLog2(mask + 1);
            m_assembler.rldicl(dest, src, 0, 64 - n);
            return true;
        }
        // High run: ~mask == 2^n - 1, i.e. the low n bits are cleared.
        uint64_t inverted = ~mask;
        if (!(inverted & (inverted + 1))) {
            unsigned n = WTF::fastLog2(inverted + 1);
            m_assembler.rldicr(dest, src, 0, 63 - n);
            return true;
        }
        return false;
    }

    void andImmediate64(RegisterID src, uint64_t mask, RegisterID dest)
    {
        if (tryAndImmediate64(src, mask, dest))
            return;
        if (!(mask & ~uint64_t(0xffff))) {
            m_assembler.andi_(dest, src, static_cast<uint32_t>(mask));
            return;
        }
        if (!(mask & ~uint64_t(0xffff0000))) {
            m_assembler.andis_(dest, src, static_cast<uint32_t>(mask >> 16));
            return;
        }
        RegisterID scratch = constantScratch(src, dest);
        m_assembler.loadImmediate64(scratch, static_cast<int64_t>(mask));
        m_assembler.and_(dest, src, scratch);
    }

    void and32(RegisterID src, RegisterID dest) { and32(src, dest, dest); }

    void and32(RegisterID a, RegisterID b, RegisterID dest)
    {
        // The inputs are NOT guaranteed clean, so the output must be masked.
        //
        // This used to assume otherwise -- "every 32-bit producer re-masks, so
        // the invariant does hold on entry" -- and that is false under B3.
        // AirOpcode.opcodes declares And32/Or32/Xor32 as ZD:G:32, which is a
        // promise that the def's upper 32 bits are ZERO, and B3 relies on it:
        // it lowers Trunc to nothing at all (B3LowerToAir.cpp, case Trunc), so
        // a 64-bit value flows into a 32-bit operation with a dirty upper
        // word, and the greedy allocator coalesces away the Move32 that would
        // otherwise have cleaned it because the def width is already <= 32.
        //
        // The consequence was not subtle. With FTL on, `a & b` returned NaN
        // for every input: the operands arrive boxed (0xFFFE...), the bare
        // `and` kept the tag bits, and adding NumberTag to an already-tagged
        // value produces a double pattern. A dirty value used as an index
        // instead yields a wild address, which is the shape of several of the
        // SIGSEGVs.
        //
        // testb3 cannot see this: it reads results back as C int32, which
        // discards exactly the bits that are wrong.
        m_assembler.and_(dest, a, b);
        maskLow32(dest);
    }

    void and32(TrustedImm32 imm, RegisterID dest) { and32(imm, dest, dest); }

    void and32(TrustedImm32 imm, RegisterID src, RegisterID dest)
    {
        // No mask needed, and not by luck: the immediate is widened as
        // uint32_t, so bits 32-63 of the mask are zero and the AND clears
        // the destination's upper word for us whatever the source held.
        andImmediate64(src, static_cast<uint32_t>(imm.m_value), dest);
    }

    void and32(Address address, RegisterID dest)
    {
        auto temp = temps<Data>();
        load32(address, temp.data());
        and32(temp.data(), dest);
    }

    void and64(RegisterID src, RegisterID dest) { m_assembler.and_(dest, dest, src); }
    void and64(RegisterID a, RegisterID b, RegisterID dest) { m_assembler.and_(dest, a, b); }

    // A TrustedImm32 mask read as 64 bits is SIGN-extended, so and64 with
    // TrustedImm32(-8) clears the low three bits of the whole register rather
    // than also clearing the upper word.
    void and64(TrustedImm32 imm, RegisterID dest) { andImmediate64(dest, static_cast<uint64_t>(static_cast<int64_t>(imm.m_value)), dest); }
    void and64(TrustedImm32 imm, RegisterID src, RegisterID dest) { andImmediate64(src, static_cast<uint64_t>(static_cast<int64_t>(imm.m_value)), dest); }
    void and64(TrustedImm64 imm, RegisterID dest) { andImmediate64(dest, static_cast<uint64_t>(imm.m_value), dest); }
    void and64(TrustedImm64 imm, RegisterID src, RegisterID dest) { andImmediate64(src, static_cast<uint64_t>(imm.m_value), dest); }
    void and64(TrustedImmPtr imm, RegisterID dest) { andImmediate64(dest, reinterpret_cast<uint64_t>(imm.m_value), dest); }

    void orImmediate64(RegisterID src, uint64_t value, RegisterID dest)
    {
        if (!value) {
            move(src, dest);
            return;
        }
        // ori and oris are independent halves and neither touches CR0, so a
        // value confined to the low 32 bits is at most two instructions.
        if (!(value & ~uint64_t(0xffffffff))) {
            RegisterID current = src;
            if (value & 0xffff0000) {
                m_assembler.oris(dest, current, static_cast<uint32_t>(value >> 16));
                current = dest;
            }
            if (value & 0xffff) {
                m_assembler.ori(dest, current, static_cast<uint32_t>(value & 0xffff));
                current = dest;
            }
            move(current, dest);
            return;
        }
        RegisterID scratch = constantScratch(src, dest);
        m_assembler.loadImmediate64(scratch, static_cast<int64_t>(value));
        m_assembler.or_(dest, src, scratch);
    }

    // ZD:G:32 -- see the note on and32(a, b, dest). The inputs may carry a
    // dirty upper word, so every one of these masks its result.
    void or32(RegisterID src, RegisterID dest) { or32(src, dest, dest); }
    void or32(RegisterID a, RegisterID b, RegisterID dest)
    {
        m_assembler.or_(dest, a, b);
        maskLow32(dest);
    }
    void or32(TrustedImm32 imm, RegisterID dest) { or32(imm, dest, dest); }

    void or32(TrustedImm32 imm, RegisterID src, RegisterID dest)
    {
        // ori/oris leave the source's upper word untouched, so unlike
        // and32's immediate form this does not clean itself.
        orImmediate64(src, static_cast<uint32_t>(imm.m_value), dest);
        maskLow32(dest);
    }

    void or32(RegisterID src, Address address)
    {
        auto temp = temps<Data>();
        load32(address, temp.data());
        m_assembler.or_(temp.data(), temp.data(), src);
        store32(temp.data(), address);
    }

    void or32(RegisterID src, AbsoluteAddress address)
    {
        auto temp = temps<Data>();
        load32(address.m_ptr, temp.data());
        m_assembler.or_(temp.data(), temp.data(), src);
        store32(temp.data(), address.m_ptr);
    }

    void or32(TrustedImm32 imm, Address address)
    {
        auto temp = temps<Data>();
        load32(address, temp.data());
        or32(imm, temp.data());
        store32(temp.data(), address);
    }

    void or32(TrustedImm32 imm, AbsoluteAddress address)
    {
        auto temp = temps<Data>();
        load32(address.m_ptr, temp.data());
        or32(imm, temp.data());
        store32(temp.data(), address.m_ptr);
    }

    void or8(RegisterID src, AbsoluteAddress address)
    {
        auto temp = temps<Data>();
        load8(address.m_ptr, temp.data());
        m_assembler.or_(temp.data(), temp.data(), src);
        store8(temp.data(), address.m_ptr);
    }

    void or8(TrustedImm32 imm, AbsoluteAddress address)
    {
        auto temp = temps<Data>();
        load8(address.m_ptr, temp.data());
        m_assembler.ori(temp.data(), temp.data(), static_cast<uint32_t>(imm.m_value) & 0xff);
        store8(temp.data(), address.m_ptr);
    }

    void or16(RegisterID src, AbsoluteAddress address)
    {
        auto temp = temps<Data>();
        load16(address.m_ptr, temp.data());
        m_assembler.or_(temp.data(), temp.data(), src);
        store16(temp.data(), address.m_ptr);
    }

    void or16(TrustedImm32 imm, AbsoluteAddress address)
    {
        auto temp = temps<Data>();
        load16(address.m_ptr, temp.data());
        m_assembler.ori(temp.data(), temp.data(), static_cast<uint32_t>(imm.m_value) & 0xffff);
        store16(temp.data(), address.m_ptr);
    }

    void or64(RegisterID src, RegisterID dest) { m_assembler.or_(dest, dest, src); }
    void or64(RegisterID a, RegisterID b, RegisterID dest) { m_assembler.or_(dest, a, b); }
    void or64(TrustedImm32 imm, RegisterID dest) { orImmediate64(dest, static_cast<uint64_t>(static_cast<int64_t>(imm.m_value)), dest); }
    void or64(TrustedImm32 imm, RegisterID src, RegisterID dest) { orImmediate64(src, static_cast<uint64_t>(static_cast<int64_t>(imm.m_value)), dest); }
    void or64(TrustedImm64 imm, RegisterID dest) { orImmediate64(dest, static_cast<uint64_t>(imm.m_value), dest); }
    void or64(TrustedImm64 imm, RegisterID src, RegisterID dest) { orImmediate64(src, static_cast<uint64_t>(imm.m_value), dest); }

    void xorImmediate64(RegisterID src, uint64_t value, RegisterID dest)
    {
        if (!value) {
            move(src, dest);
            return;
        }
        if (!(value & ~uint64_t(0xffffffff))) {
            RegisterID current = src;
            if (value & 0xffff0000) {
                m_assembler.xoris(dest, current, static_cast<uint32_t>(value >> 16));
                current = dest;
            }
            if (value & 0xffff) {
                m_assembler.xori(dest, current, static_cast<uint32_t>(value & 0xffff));
                current = dest;
            }
            move(current, dest);
            return;
        }
        RegisterID scratch = constantScratch(src, dest);
        m_assembler.loadImmediate64(scratch, static_cast<int64_t>(value));
        m_assembler.xor_(dest, src, scratch);
    }

    void xor32(RegisterID src, RegisterID dest) { xor32(src, dest, dest); }
    void xor32(RegisterID a, RegisterID b, RegisterID dest)
    {
        m_assembler.xor_(dest, a, b);
        maskLow32(dest);
    }
    void xor32(TrustedImm32 imm, RegisterID dest) { xor32(imm, dest, dest); }

    void xor32(TrustedImm32 imm, RegisterID src, RegisterID dest)
    {
        // xor32(TrustedImm32(-1), r) is how JSC spells a 32-bit NOT. The
        // immediate does stay inside the low word, but xori/xoris pass the
        // SOURCE's upper word straight through, so the result still has to
        // be masked when that source is dirty.
        xorImmediate64(src, static_cast<uint32_t>(imm.m_value), dest);
        maskLow32(dest);
    }

    void xor32(Address address, RegisterID dest)
    {
        auto temp = temps<Data>();
        load32(address, temp.data());
        m_assembler.xor_(dest, dest, temp.data());
    }

    void xor64(RegisterID src, RegisterID dest) { m_assembler.xor_(dest, dest, src); }
    void xor64(RegisterID a, RegisterID b, RegisterID dest) { m_assembler.xor_(dest, a, b); }
    void xor64(TrustedImm32 imm, RegisterID dest) { xorImmediate64(dest, static_cast<uint64_t>(static_cast<int64_t>(imm.m_value)), dest); }
    void xor64(TrustedImm32 imm, RegisterID src, RegisterID dest) { xorImmediate64(src, static_cast<uint64_t>(static_cast<int64_t>(imm.m_value)), dest); }
    void xor64(TrustedImm64 imm, RegisterID dest) { xorImmediate64(dest, static_cast<uint64_t>(imm.m_value), dest); }
    void xor64(TrustedImm64 imm, RegisterID src, RegisterID dest) { xorImmediate64(src, static_cast<uint64_t>(imm.m_value), dest); }

    void xor64(Address address, RegisterID dest)
    {
        auto temp = temps<Data>();
        load64(address, temp.data());
        m_assembler.xor_(dest, dest, temp.data());
    }

    void xor64(RegisterID src, Address address)
    {
        auto temp = temps<Data>();
        load64(address, temp.data());
        m_assembler.xor_(temp.data(), temp.data(), src);
        store64(temp.data(), address);
    }

    void not32(RegisterID dest) { not32(dest, dest); }

    void not32(RegisterID src, RegisterID dest)
    {
        // nor(x, x) is NOT x. The complement sets the upper half, so the
        // 32-bit invariant has to be restored.
        m_assembler.nor(dest, src, src);
        maskLow32(dest);
    }

    // POWER has each of these as a single instruction, which is why they are
    // worth declaring rather than leaving B3 to synthesise them from a Not and
    // an And. Semantics taken from the ARM64 methods they are replacing, not
    // from the names: bic is `src & ~mask`, orn is `src | ~mask`, and eon is
    // `src ^ ~mask`, which is exactly what eqv computes since
    // ~(a ^ b) == a ^ ~b.
    //
    // Only andc preserves this port's zero-extension invariant for free. When
    // both operands are zero-extended, ~mask has its upper half set, so
    // `src & ~mask` keeps src's zeros; orc and eqv set the upper half and have
    // to be masked back down.
    void clearBitsWithMask32(RegisterID src, RegisterID mask, RegisterID dest) { m_assembler.andc(dest, src, mask); }
    void clearBitsWithMask64(RegisterID src, RegisterID mask, RegisterID dest) { m_assembler.andc(dest, src, mask); }
    void orNot32(RegisterID src, RegisterID mask, RegisterID dest) { m_assembler.orc(dest, src, mask); maskLow32(dest); }
    void orNot64(RegisterID src, RegisterID mask, RegisterID dest) { m_assembler.orc(dest, src, mask); }
    void xorNot32(RegisterID src, RegisterID mask, RegisterID dest) { m_assembler.eqv(dest, src, mask); maskLow32(dest); }
    void xorNot64(RegisterID src, RegisterID mask, RegisterID dest) { m_assembler.eqv(dest, src, mask); }

    // mulhw and mulhwu read the low word of each operand and ignore the upper
    // half, so the zero-extension invariant is all the preparation they need.
    // The ISA leaves the upper half of the RESULT undefined, which is why both
    // are masked; ARM64 sign-extends its 32-bit high-multiply instead, and
    // this port's convention is the zero-extended one.
    void mulHigh32(RegisterID left, RegisterID right, RegisterID dest) { m_assembler.mulhw(dest, left, right); maskLow32(dest); }
    void uMulHigh32(RegisterID left, RegisterID right, RegisterID dest) { m_assembler.mulhwu(dest, left, right); maskLow32(dest); }
    void mulHigh64(RegisterID left, RegisterID right, RegisterID dest) { m_assembler.mulhd(dest, left, right); }

    void not64(RegisterID dest) { not64(dest, dest); }
    void not64(RegisterID src, RegisterID dest) { m_assembler.nor(dest, src, src); }

    void neg32(RegisterID dest) { neg32(dest, dest); }

    void neg32(RegisterID src, RegisterID dest)
    {
        m_assembler.neg(dest, src);
        maskLow32(dest);
    }

    void neg64(RegisterID dest) { m_assembler.neg(dest, dest); }
    void neg64(RegisterID src, RegisterID dest) { m_assembler.neg(dest, src); }
    void move(RegisterID src, RegisterID dest)
    {
        if (src != dest)
            m_assembler.mr(dest, src);
    }

    void move(TrustedImm32 imm, RegisterID dest) { loadImmediate(imm, dest); }
    void move(TrustedImm64 imm, RegisterID dest) { loadImmediate(imm, dest); }
    void move(TrustedImmPtr imm, RegisterID dest) { loadImmediate(imm, dest); }

    void swap(RegisterID a, RegisterID b)
    {
        // The three-xor swap needs no temporary, but it zeroes the register
        // when both operands are the same one, so that case is taken out
        // first rather than left to chance.
        if (a == b)
            return;
        m_assembler.xor_(a, a, b);
        m_assembler.xor_(b, a, b);
        m_assembler.xor_(a, a, b);
    }

    void swapDouble(FPRegisterID a, FPRegisterID b)
    {
        if (a == b)
            return;
        m_assembler.fmr(fpTempRegister, a);
        m_assembler.fmr(a, b);
        m_assembler.fmr(b, fpTempRegister);
    }

    void moveDouble(FPRegisterID src, FPRegisterID dest)
    {
        if (src != dest)
            m_assembler.fmr(dest, src);
    }

    void moveFloat(FPRegisterID src, FPRegisterID dest) { moveDouble(src, dest); }

    // xxlxor is the canonical zero: fsub of a register from itself would
    // produce -0.0 for a negative-zero input and NaN for a NaN one.
    void moveZeroToDouble(FPRegisterID dest) { m_assembler.xxlxor(dest, dest, dest); }
    void moveZeroToFloat(FPRegisterID dest) { m_assembler.xxlxor(dest, dest, dest); }

    void moveDoubleTo64(FPRegisterID src, RegisterID dest) { m_assembler.mfvsrd(dest, src); }
    void move64ToDouble(RegisterID src, FPRegisterID dest) { m_assembler.mtvsrd(dest, src); }

    void move64ToDouble(TrustedImm64 imm, FPRegisterID dest)
    {
        // Zero is worth its own case for two reasons. It is by far the most
        // common floating-point constant, and it is the ONLY one Air will ever
        // ask for here: Arg::isValidFPImm64Form answers true for zero and
        // false for everything else on this target, so the FPImm64 form is
        // reachable for no other value. xxlxor clears the whole register and
        // needs no GPR to stage through -- which is what makes the form usable
        // at all, since Air generates with the macro scratch forbidden.
        if (!imm.m_value) {
            m_assembler.xxlxor(dest, dest, dest);
            return;
        }
        auto temp = temps<Data>();
        loadImmediate(imm, temp.data());
        m_assembler.mtvsrd(dest, temp.data());
    }

    // A float in an FPR is its raw 32-bit pattern in the low word of
    // doubleword 0 (the model at the head of the floating-point section
    // below), so these are bit moves, not conversions. mtvsrwz puts the word
    // exactly there; mfvsrwz reads it back zero-extended, which is the
    // port's 32-bit invariant for free.
    void move32ToFloat(RegisterID src, FPRegisterID dest) { m_assembler.mtvsrwz(dest, src); }

    void move32ToFloat(TrustedImm32 imm, FPRegisterID dest)
    {
        // As move64ToDouble: zero is the only value Arg::isValidFPImm32Form
        // admits here, and xxlxor needs no GPR. Clearing all 128 bits leaves
        // the low word of doubleword 0 zero, which is +0.0f under this port's
        // raw-bits f32 model.
        if (!imm.m_value) {
            m_assembler.xxlxor(dest, dest, dest);
            return;
        }
        auto temp = temps<Data>();
        loadImmediate(imm, temp.data());
        m_assembler.mtvsrwz(dest, temp.data());
    }

    void moveFloatTo32(FPRegisterID src, RegisterID dest) { m_assembler.mfvsrwz(dest, src); }
    // Integer add/sub on values that happen to live in FPRs: JSValue boxing
    // adds and subtracts DoubleEncodeOffset against a raw double pattern.
    // POWER has no integer adder in the FP unit, so the operands go through
    // GPRs on the same mfvsrd/mtvsrd pair moveDoubleTo64/move64ToDouble use.
    void add64(FPRegisterID a, FPRegisterID b, FPRegisterID dest)
    {
        auto temp = temps<Data, Memory>();
        m_assembler.mfvsrd(temp.data(), a);
        m_assembler.mfvsrd(temp.memory(), b);
        m_assembler.add(temp.data(), temp.data(), temp.memory());
        m_assembler.mtvsrd(dest, temp.data());
    }

    // dest = a - b, matching sub64(RegisterID a, RegisterID b, RegisterID dest).
    void sub64(FPRegisterID a, FPRegisterID b, FPRegisterID dest)
    {
        auto temp = temps<Data, Memory>();
        m_assembler.mfvsrd(temp.data(), a);
        m_assembler.mfvsrd(temp.memory(), b);
        m_assembler.subf(temp.data(), temp.memory(), temp.data());
        m_assembler.mtvsrd(dest, temp.data());
    }
    // ==================================================================
    // 128-bit vector move, load and store.
    //
    // A v128 lives in a VSR, and FPRegisterID n IS VSR n here, so the whole
    // 16 bytes move -- not the scalar doubleword. Getting that wrong once is
    // why commit 2e1a46a3a1 exists.
    //
    // lxvx/stxvx are ISA 3.0 AND byte-order preserving, which is what makes
    // memory order equal wasm lane order on this little-endian target
    // (jsc-ppc64le-wasm-simd.md section 2). The POWER8 floor has only
    // lxvd2x/stxvd2x, which additionally SWAP the two doublewords, so the
    // fallback pairs them with xxswapd. The gate is at run time, not compile
    // time, so one binary serves POWER8 and POWER9 -- and note that `as`
    // will NOT catch a mistake here: it accepts the lxvx mnemonic on POWER8
    // and silently assembles lxvd2x instead (section 6). This port emits raw
    // encodings, verified byte-for-byte by tools/ppc64-encoding-oracle.
    void moveVector(FPRegisterID src, FPRegisterID dest)
    {
        if (src == dest)
            return;
        m_assembler.xxlor(dest, src, src);
    }

    void moveZeroToVector(FPRegisterID dest)
    {
        m_assembler.xxlxor(dest, dest, dest);
    }

    // A 128-bit constant, through the GPR temp. Memory doubleword 1 is ISA
    // doubleword 0, which is where mtvsrd lands a GPR, so the high half goes
    // straight into dest and the low half arrives through the FP temp and
    // xxpermdi. Equal halves are the i64x2 splat: one materialisation.
    void move128ToVector(v128_t value, FPRegisterID dest)
    {
        if (bitEquals(value, vectorAllZeros())) {
            moveZeroToVector(dest);
            return;
        }
        auto temp = temps<Data>();
        uint64_t low = value.u64x2[0];
        uint64_t high = value.u64x2[1];
        if (low == high) {
            move(TrustedImm64(static_cast<int64_t>(low)), temp.data());
            m_assembler.mtvsrd(fpTempRegister, temp.data());
            m_assembler.xxpermdi(dest, fpTempRegister, fpTempRegister, 0);
            return;
        }
        move(TrustedImm64(static_cast<int64_t>(high)), temp.data());
        m_assembler.mtvsrd(dest, temp.data());
        move(TrustedImm64(static_cast<int64_t>(low)), temp.data());
        m_assembler.mtvsrd(fpTempRegister, temp.data());
        m_assembler.xxpermdi(dest, dest, fpTempRegister, 0);
    }

    void loadVector(Address address, FPRegisterID dest)
    {
        auto temp = lazyTemp<Memory>();
        auto resolution = resolveAddress(address, temp, false);
        emitLoadVector(dest, foldOffsetIntoAddressRegister(resolution, temp));
    }

    void loadVector(BaseIndex address, FPRegisterID dest)
    {
        auto temp = temps<Memory>();
        auto resolution = resolveAddress(address, temp.memory(), false);
        emitLoadVector(dest, foldOffsetIntoAddressRegister(resolution, temp.memory()));
    }

    void loadVector(TrustedImmPtr address, FPRegisterID dest)
    {
        auto temp = temps<Memory>();
        loadImmediate(address, temp.memory());
        emitLoadVector(dest, temp.memory());
    }

    void storeVector(FPRegisterID src, Address address)
    {
        auto temp = lazyTemp<Memory>();
        auto resolution = resolveAddress(address, temp, false);
        emitStoreVector(src, foldOffsetIntoAddressRegister(resolution, temp));
    }

    void storeVector(FPRegisterID src, BaseIndex address)
    {
        auto temp = temps<Memory>();
        auto resolution = resolveAddress(address, temp.memory(), false);
        emitStoreVector(src, foldOffsetIntoAddressRegister(resolution, temp.memory()));
    }

    void storeVector(FPRegisterID src, TrustedImmPtr address)
    {
        auto temp = temps<Memory>();
        loadImmediate(address, temp.memory());
        emitStoreVector(src, temp.memory());
    }

    // ---- v128.loadN_splat, loadN_lane, storeN_lane, loadN_zero ----
    //
    // All through a GPR. The scalar loads and stores, vectorSplat,
    // vectorReplaceLane and vectorExtractLane are each already lane-correct,
    // so these are correct by composition; POWER8 has no lane insert from
    // memory to compose with anyway. A loaded value goes in the MEMORY temp
    // because vectorReplaceLane uses the data temp as its own scratch, and a
    // load's address is dead once the load has issued.
    void vectorLoad8Splat(Address address, FPRegisterID dest) { emitVectorLoadSplat(SIMDLane::i8x16, address, dest); }
    void vectorLoad16Splat(Address address, FPRegisterID dest) { emitVectorLoadSplat(SIMDLane::i16x8, address, dest); }
    void vectorLoad32Splat(Address address, FPRegisterID dest) { emitVectorLoadSplat(SIMDLane::i32x4, address, dest); }
    void vectorLoad64Splat(Address address, FPRegisterID dest) { emitVectorLoadSplat(SIMDLane::i64x2, address, dest); }

    void vectorLoad8Lane(Address address, TrustedImm32 lane, FPRegisterID dest) { emitVectorLoadLane(SIMDLane::i8x16, address, lane, dest); }
    void vectorLoad16Lane(Address address, TrustedImm32 lane, FPRegisterID dest) { emitVectorLoadLane(SIMDLane::i16x8, address, lane, dest); }
    void vectorLoad32Lane(Address address, TrustedImm32 lane, FPRegisterID dest) { emitVectorLoadLane(SIMDLane::i32x4, address, lane, dest); }
    void vectorLoad64Lane(Address address, TrustedImm32 lane, FPRegisterID dest) { emitVectorLoadLane(SIMDLane::i64x2, address, lane, dest); }

    void vectorStore8Lane(FPRegisterID src, Address address, TrustedImm32 lane) { emitVectorStoreLane(SIMDLane::i8x16, src, address, lane); }
    void vectorStore16Lane(FPRegisterID src, Address address, TrustedImm32 lane) { emitVectorStoreLane(SIMDLane::i16x8, src, address, lane); }
    void vectorStore32Lane(FPRegisterID src, Address address, TrustedImm32 lane) { emitVectorStoreLane(SIMDLane::i32x4, src, address, lane); }
    void vectorStore64Lane(FPRegisterID src, Address address, TrustedImm32 lane) { emitVectorStoreLane(SIMDLane::i64x2, src, address, lane); }

    // v128.load32_zero / load64_zero: the scalar in lane 0, zero elsewhere.
    // NOT loadFloat/loadDouble, which the shared BBQ code reaches for: lfd and
    // lxsiwzx put the scalar in ISA doubleword 0 -- the memory-HIGH half --
    // and leave the other doubleword undefined. load32 zero-extends, so one
    // path serves both widths.
    void vectorLoad32Zero(Address address, FPRegisterID dest) { emitVectorLoadZero(SIMDLane::i32x4, address, dest); }
    void vectorLoad64Zero(Address address, FPRegisterID dest) { emitVectorLoadZero(SIMDLane::i64x2, address, dest); }

    void emitVectorScalarLoad(SIMDLane lane, Address address, RegisterID dest)
    {
        switch (lane) {
        case SIMDLane::i8x16: load8(address, dest); return;
        case SIMDLane::i16x8: load16(address, dest); return;
        case SIMDLane::i32x4: load32(address, dest); return;
        case SIMDLane::i64x2: load64(address, dest); return;
        default: RELEASE_ASSERT_NOT_REACHED();
        }
    }

    void emitVectorLoadSplat(SIMDLane lane, Address address, FPRegisterID dest)
    {
        auto temp = temps<Memory>();
        emitVectorScalarLoad(lane, address, temp.memory());
        vectorSplat(lane, temp.memory(), dest);
    }

    void emitVectorLoadLane(SIMDLane lane, Address address, TrustedImm32 laneIndex, FPRegisterID dest)
    {
        auto temp = temps<Memory>();
        emitVectorScalarLoad(lane, address, temp.memory());
        vectorReplaceLane(lane, laneIndex, temp.memory(), dest);
    }

    void emitVectorStoreLane(SIMDLane lane, FPRegisterID src, Address address, TrustedImm32 laneIndex)
    {
        auto temp = temps<Data>();
        vectorExtractLane(lane, SIMDSignMode::Unsigned, laneIndex, src, temp.data());
        switch (lane) {
        case SIMDLane::i8x16: store8(temp.data(), address); return;
        case SIMDLane::i16x8: store16(temp.data(), address); return;
        case SIMDLane::i32x4: store32(temp.data(), address); return;
        case SIMDLane::i64x2: store64(temp.data(), address); return;
        default: RELEASE_ASSERT_NOT_REACHED();
        }
    }

    void emitVectorLoadZero(SIMDLane lane, Address address, FPRegisterID dest)
    {
        auto temp = temps<Memory>();
        emitVectorScalarLoad(lane, address, temp.memory());
        m_assembler.mtvsrd(fpTempRegister, temp.memory());
        m_assembler.xxlxor(fpTempRegister2, fpTempRegister2, fpTempRegister2);
        // Doubleword 0 (memory-high) from the zero, doubleword 1 (memory-low) from the value.
        m_assembler.xxpermdi(dest, fpTempRegister2, fpTempRegister, 0);
    }
    // ==================================================================
    // Lane extract and replace.
    //
    // Memory order IS wasm lane order here, and mfvsrd/mtvsrd touch ISA
    // doubleword 0, which is MEMORY BYTES 8-15 -- the HIGH memory doubleword.
    // So wasm lane 1 of an i64x2 is ISA doubleword 0 and wasm lane 0 is ISA
    // doubleword 1, and the xxpermdi selectors below follow from that and
    // nothing else. Every path is VSX or GPR: no VMX form is used, so this
    // group does not depend on how the VMX/VSX register-model question
    // (jsc-ppc64le-vector-register-model.md) is settled.
    //
    // xxpermdi XT,XA,XB,DM takes XT doubleword 0 from XA (DM bit 1 picks
    // which) and XT doubleword 1 from XB (DM bit 0).
    void vectorExtractLane(SIMDLane lane, SIMDSignMode signMode, TrustedImm32 laneIndex, FPRegisterID src, RegisterID dest)
    {
        unsigned index = static_cast<unsigned>(laneIndex.m_value);
        unsigned laneBits = 8u << (static_cast<unsigned>(lane) - static_cast<unsigned>(SIMDLane::i8x16));
        unsigned lanesPerDoubleword = 64 / laneBits;
        unsigned memoryDoubleword = index / lanesPerDoubleword;
        unsigned within = index % lanesPerDoubleword;

        emitVectorDoublewordToGPR(src, memoryDoubleword, dest);
        if (laneBits < 64) {
            // Rotate the wanted field down to bit 0 and mask to its width.
            unsigned shift = (64 - laneBits * within) % 64;
            m_assembler.rldicl(dest, dest, shift, 64 - laneBits);
            if (signMode == SIMDSignMode::Signed) {
                if (laneBits == 8)
                    m_assembler.extsb(dest, dest);
                else if (laneBits == 16)
                    m_assembler.extsh(dest, dest);
                else
                    m_assembler.extsw(dest, dest);
            }
        }
    }

    void vectorExtractLane(SIMDLane lane, TrustedImm32 laneIndex, FPRegisterID src, FPRegisterID dest)
    {
        unsigned index = static_cast<unsigned>(laneIndex.m_value);
        switch (lane) {
        case SIMDLane::f32x4:
            // A single is kept as its raw pattern in ISA word 1, and splatting
            // the wanted word puts it there whichever lane it came from.
            m_assembler.xxspltw(dest, src, 3 - index);
            return;
        case SIMDLane::f64x2:
            m_assembler.xxpermdi(dest, src, src, index ? 0 : 3);
            return;
        default:
            RELEASE_ASSERT_NOT_REACHED();
        }
    }

    void vectorReplaceLane(SIMDLane lane, TrustedImm32 laneIndex, RegisterID src, FPRegisterID dest)
    {
        unsigned index = static_cast<unsigned>(laneIndex.m_value);
        unsigned laneBits = 8u << (static_cast<unsigned>(lane) - static_cast<unsigned>(SIMDLane::i8x16));
        unsigned lanesPerDoubleword = 64 / laneBits;
        unsigned memoryDoubleword = index / lanesPerDoubleword;
        unsigned within = index % lanesPerDoubleword;

        auto temp = temps<Data>();
        RegisterID scratch = temp.data();
        if (laneBits == 64)
            m_assembler.mtvsrd(fpTempRegister, src);
        else {
            emitVectorDoublewordToGPR(dest, memoryDoubleword, scratch);
            // Rotate the target field to bit 0, insert, rotate back. rldimi's
            // mask always runs to bit 63, so the field has to be at the bottom.
            unsigned down = (64 - laneBits * within) % 64;
            unsigned up = (laneBits * within) % 64;
            if (down)
                m_assembler.rldicl(scratch, scratch, down, 0);
            m_assembler.rldimi(scratch, src, 0, 64 - laneBits);
            if (up)
                m_assembler.rldicl(scratch, scratch, up, 0);
            m_assembler.mtvsrd(fpTempRegister, scratch);
        }
        emitVectorMergeDoubleword(dest, fpTempRegister, memoryDoubleword);
    }

    void vectorReplaceLane(SIMDLane lane, TrustedImm32 laneIndex, FPRegisterID src, FPRegisterID dest)
    {
        unsigned index = static_cast<unsigned>(laneIndex.m_value);
        switch (lane) {
        case SIMDLane::f64x2:
            // No GPR round trip: the doubleword is already where it belongs.
            if (index)
                m_assembler.xxpermdi(dest, src, dest, 1);
            else
                m_assembler.xxpermdi(dest, dest, src, 0);
            return;
        case SIMDLane::f32x4: {
            // mfvsrwz reads ISA word 1, which is where this port keeps a
            // single, so the integer path then places it by lane index.
            //
            // Into the MEMORY temp, not the data temp: the integer path uses
            // the data temp as its own scratch, so handing it the scalar in
            // that register destroyed the value before the insert and left
            // the lane unchanged. The first BBQ run of
            // JSTests/wasm/stress/simd-instructions-construct.js found it;
            // testPPC64VectorReplaceLaneFloat32 now covers this arm, which
            // the original lane-float test did not exercise.
            auto temp = temps<Memory>();
            m_assembler.mfvsrwz(temp.memory(), src);
            vectorReplaceLane(SIMDLane::i32x4, laneIndex, temp.memory(), dest);
            return;
        }
        default:
            RELEASE_ASSERT_NOT_REACHED();
        }
    }

    // Per-type names, generated rather than hand-written.
    DEFINE_SIGNED_SIMD_FUNCS(vectorExtractLane);
    DEFINE_SIMD_FUNCS(vectorReplaceLane);
    // DUPLICATE one lane across every lane. Memory lane k is ISA element
    // (lanes - 1) - k, the same inversion vectorExtractLane encodes, which is
    // why the 32- and 64-bit arms are literally its two lines: on this target
    // "move lane k into the scalar position" and "splat lane k" are the same
    // instruction. xxspltw fills all four words from the one it selects, and
    // the xxpermdi that puts the wanted doubleword in ISA dw0 puts a copy in
    // dw1 as well.
    //
    // The 8- and 16-bit splats are VMX, which can only address the vr half of
    // the VSR file, so they go through the bridge. Everything here is VSX
    // 2.06 or VMX, so POWER8 needs no fallback.
    void vectorDupElement(SIMDLane lane, TrustedImm32 laneIndex, FPRegisterID src, FPRegisterID dest)
    {
        unsigned index = static_cast<unsigned>(laneIndex.m_value);
        switch (lane) {
        case SIMDLane::i8x16:
            RELEASE_ASSERT(index < 16);
            m_assembler.xxlor(vectorBridge0VSR, src, src);
            m_assembler.vspltb(vectorBridge0, vectorBridge0, 15 - index);
            m_assembler.xxlor(dest, vectorBridge0VSR, vectorBridge0VSR);
            return;
        case SIMDLane::i16x8:
            RELEASE_ASSERT(index < 8);
            m_assembler.xxlor(vectorBridge0VSR, src, src);
            m_assembler.vsplth(vectorBridge0, vectorBridge0, 7 - index);
            m_assembler.xxlor(dest, vectorBridge0VSR, vectorBridge0VSR);
            return;
        case SIMDLane::i32x4:
        case SIMDLane::f32x4:
            RELEASE_ASSERT(index < 4);
            m_assembler.xxspltw(dest, src, 3 - index);
            return;
        case SIMDLane::i64x2:
        case SIMDLane::f64x2:
            RELEASE_ASSERT(index < 2);
            m_assembler.xxpermdi(dest, src, src, index ? 0 : 3);
            return;
        default:
            RELEASE_ASSERT_NOT_REACHED();
        }
    }
    DEFINE_SIMD_FUNCS(vectorDupElement);

    // EXTRACT a sixteen-byte window from the pair (n, m). The contract B3 is
    // written against is ARM64's EXT:
    //
    //     result.mem[i] = (i + k < 16) ? n.mem[i + k] : m.mem[i + k - 16]
    //
    // vsldoi does exactly this in one VMX instruction, with the operands the
    // other way round. Its ISA definition shifts the concatenation
    // (VRA || VRB) left by SHB bytes in BIG-endian byte order; translated
    // through the little-endian memory image, where memory byte j is ISA byte
    // 15 - j, that is
    //
    //     dest.mem[j] = (j >= SHB) ? VRA.mem[j - SHB] : VRB.mem[j - SHB + 16]
    //
    // and SHB = 16 - k turns the second line into the first with VRA = m and
    // VRB = n. So the pair is passed SWAPPED relative to ARM64 -- the same
    // class of trap as the xxsel operand sense and the vpk* (upper, lower)
    // order, and the reason the derivation is written out rather than
    // asserted.
    //
    // k == 0 would need SHB == 16, which the four-bit field cannot hold. It
    // is the identity on n.
    void vectorExtractPair(SIMDInfo simdInfo, TrustedImm32 firstLane, FPRegisterID n, FPRegisterID m, FPRegisterID dest)
    {
        ASSERT_UNUSED(simdInfo, simdInfo.lane == SIMDLane::i8x16);
        unsigned k = static_cast<unsigned>(firstLane.m_value);
        RELEASE_ASSERT(k < 16);
        if (!k) {
            moveVector(n, dest);
            return;
        }
        emitVMXBinary(m, n, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            m_assembler.vsldoi(t, a, b, 16 - k);
        });
    }
    // ==================================================================
    // Vector splat.
    //
    // mtvsrd lands a GPR in ISA doubleword 0, so the scalar's low byte is
    // ISA byte 7, its low halfword ISA halfword 3 and its low word ISA word
    // 1 -- which is where the element indices below come from. The f32 pair
    // needs no conversion: this port keeps a single as its raw 32-bit
    // pattern in ISA word 1 of the FPR already.
    //
    // The word and doubleword cases are pure VSX and address the JSC vector
    // register directly. The byte and halfword cases have no VSX form on the
    // POWER8 floor -- xxspltib is ISA 3.0, and it takes an immediate rather
    // than a register anyway -- so they go through VMX vspltb/vsplth, which
    // cannot name a VSR below 32, so they go through the bridge above.
    void vectorSplat(SIMDLane lane, RegisterID src, FPRegisterID dest)
    {
        switch (lane) {
        case SIMDLane::i8x16:
            m_assembler.mtvsrd(vectorBridge0VSR, src);
            m_assembler.vspltb(vectorBridge0, vectorBridge0, 7);
            m_assembler.xxlor(dest, vectorBridge0VSR, vectorBridge0VSR);
            return;
        case SIMDLane::i16x8:
            m_assembler.mtvsrd(vectorBridge0VSR, src);
            m_assembler.vsplth(vectorBridge0, vectorBridge0, 3);
            m_assembler.xxlor(dest, vectorBridge0VSR, vectorBridge0VSR);
            return;
        case SIMDLane::i32x4:
            m_assembler.mtvsrd(fpTempRegister, src);
            m_assembler.xxspltw(dest, fpTempRegister, 1);
            return;
        case SIMDLane::i64x2:
            m_assembler.mtvsrd(fpTempRegister, src);
            m_assembler.xxpermdi(dest, fpTempRegister, fpTempRegister, 0);
            return;
        default:
            RELEASE_ASSERT_NOT_REACHED();
        }
    }

    void vectorSplat(SIMDLane lane, FPRegisterID src, FPRegisterID dest)
    {
        switch (lane) {
        case SIMDLane::f32x4:
            m_assembler.xxspltw(dest, src, 1);
            return;
        case SIMDLane::f64x2:
            m_assembler.xxpermdi(dest, src, src, 0);
            return;
        default:
            RELEASE_ASSERT_NOT_REACHED();
        }
    }

    // The per-type names BBQ and B3 also call are GENERATED from the
    // lane-parameterised primitive, exactly as ARM64 and x86_64 generate
    // theirs. They are not a second hand-maintained naming scheme.
    DEFINE_SIMD_FUNCS(vectorSplat);
    // ==================================================================
    // Vector floating-point: the float-only operations.
    //
    // WHAT AN f32x4 LANE IS, stated rather than inherited. This port keeps a
    // SCALAR f32 as its raw single in ISA word 1 of doubleword 0
    // (jsc-ppc64le-yarr-wasm.md section 7). A VECTOR of four f32 lanes is a
    // different question, and the answer is the ordinary one: four packed
    // IEEE singles, memory order equal to wasm lane order, exactly as x86 and
    // ARM64 have them. The two models are not the same statement and only
    // touch at one point -- memory word k is ISA word 3-k, so the scalar
    // position, ISA word 1, is wasm LANE 2 of the vector view. Nothing here
    // converts between single and double format, so the raw-bits model is
    // neither used nor disturbed; xv*sp operate on all four lanes in place.
    //
    // Only operations that exist solely for floating-point lanes are in this
    // group. add, sub, mul, neg and abs also have integer lanes, and those are
    // VMX-form, so they wait on the register-model decision
    // (jsc-ppc64le-vector-register-model.md) rather than being written twice.
    //
    // min, max, pmin and pmax are float-only but are NOT here: wasm's NaN and
    // signed-zero rules do not match the one-instruction VSX behaviour, and
    // jsc-ppc64le-wasm-simd.md section 5 gives them six instructions each.
    // They need values chosen against the spec, not against the hardware.
    void vectorDiv(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        if (simdInfo.lane == SIMDLane::f32x4)
            m_assembler.xvdivsp(dest, left, right);
        else if (simdInfo.lane == SIMDLane::f64x2)
            m_assembler.xvdivdp(dest, left, right);
        else
            RELEASE_ASSERT_NOT_REACHED();
    }

    void vectorSqrt(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest)
    {
        if (simdInfo.lane == SIMDLane::f32x4)
            m_assembler.xvsqrtsp(dest, input);
        else if (simdInfo.lane == SIMDLane::f64x2)
            m_assembler.xvsqrtdp(dest, input);
        else
            RELEASE_ASSERT_NOT_REACHED();
    }

    // The four roundings. xvr*ic is round-to-nearest with ties to EVEN, which
    // is what wasm's f32x4.nearest wants, so no fixup is needed.
    void vectorCeil(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest)
    {
        if (simdInfo.lane == SIMDLane::f32x4)
            m_assembler.xvrspip(dest, input);
        else if (simdInfo.lane == SIMDLane::f64x2)
            m_assembler.xvrdpip(dest, input);
        else
            RELEASE_ASSERT_NOT_REACHED();
    }

    void vectorFloor(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest)
    {
        if (simdInfo.lane == SIMDLane::f32x4)
            m_assembler.xvrspim(dest, input);
        else if (simdInfo.lane == SIMDLane::f64x2)
            m_assembler.xvrdpim(dest, input);
        else
            RELEASE_ASSERT_NOT_REACHED();
    }

    void vectorTrunc(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest)
    {
        if (simdInfo.lane == SIMDLane::f32x4)
            m_assembler.xvrspiz(dest, input);
        else if (simdInfo.lane == SIMDLane::f64x2)
            m_assembler.xvrdpiz(dest, input);
        else
            RELEASE_ASSERT_NOT_REACHED();
    }

    void vectorNearest(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest)
    {
        if (simdInfo.lane == SIMDLane::f32x4)
            m_assembler.xvrspic(dest, input);
        else if (simdInfo.lane == SIMDLane::f64x2)
            m_assembler.xvrdpic(dest, input);
        else
            RELEASE_ASSERT_NOT_REACHED();
    }

    // ==================================================================
    // Vector float compares, min/max, and the saturating conversions.
    //
    // The hardware-versus-specification differences here were probed rather
    // than read, and there are exactly two of them
    // (jsc-ppc64le-vector-conversions.md section 1):
    //
    //   * xvmin/xvmax are minNum/maxNum -- given a NaN operand they return
    //     the OTHER one. wasm wants the NaN. Signed zeros are already right
    //     in both operand orders, so the obvious compare-and-select "fix"
    //     would make those worse.
    //   * xvcvspsxws maps NaN to INT_MIN. wasm wants 0. Range saturation,
    //     -0.0 and truncation direction are all already correct, and the
    //     UNSIGNED form needs no repair at all.
    //
    // Everything else in this group is one instruction.
    void vectorConvert(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest)
    {
        ASSERT(simdInfo.lane == SIMDLane::i32x4);
        if (simdInfo.signMode == SIMDSignMode::Signed)
            m_assembler.xvcvsxwsp(dest, input);
        else
            m_assembler.xvcvuxwsp(dest, input);
    }

    void vectorTruncSat(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest)
    {
        if (simdInfo.lane == SIMDLane::f64x2) {
            // The *_zero forms. The dp->word conversions write each result
            // into BOTH words of its doubleword (jsc-ppc64le-vector-conversions.md
            // section 1.4), so the doubleword-wide NaN mask lines up with
            // them, and vpkudum then keeps one word per doubleword and
            // supplies the zero lanes. The conversion writes the bridge
            // register directly: VSX fields are six bits wide.
            if (simdInfo.signMode == SIMDSignMode::Unsigned)
                m_assembler.xvcvdpuxws(vectorBridge0VSR, input);
            else {
                m_assembler.xvcmpeqdp(fpTempRegister, input, input);
                m_assembler.xvcvdpsxws(vectorBridge0VSR, input);
                m_assembler.xxland(vectorBridge0VSR, vectorBridge0VSR, fpTempRegister);
            }
            emitVectorPackDoublewordsToLowWords(dest);
            return;
        }
        RELEASE_ASSERT(simdInfo.lane == SIMDLane::f32x4);
        if (simdInfo.signMode == SIMDSignMode::Unsigned) {
            // Already gives 0 for NaN and for every negative input.
            m_assembler.xvcvspuxws(dest, input);
            return;
        }
        // Build the not-NaN mask BEFORE converting, so dest may alias input.
        m_assembler.xvcmpeqsp(fpTempRegister, input, input);
        m_assembler.xvcvspsxws(dest, input);
        m_assembler.xxland(dest, dest, fpTempRegister);
    }

    // min/max: six instructions, and the addition is what supplies the NaN --
    // no constant and no memory access. Any NaN operand propagates through it.
    //
    // The integer lanes arrive here too -- BBQ's non-x86 arm routes every
    // min/max through these two -- and are one VMX instruction each, signed
    // or unsigned by the SIMDInfo. The merged layer had only the float arms,
    // so i8x16.min_s reached the float RELEASE_ASSERT: found by the targeted
    // wasm arith test under BBQ, not by review.
    void vectorMin(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        if (scalarTypeIsIntegral(simdInfo.lane)) {
            emitVectorIntegerMinMax(simdInfo, left, right, dest, true);
            return;
        }
        emitVectorMinMax(simdInfo, left, right, dest, true);
    }

    void vectorMax(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        if (scalarTypeIsIntegral(simdInfo.lane)) {
            emitVectorIntegerMinMax(simdInfo, left, right, dest, false);
            return;
        }
        emitVectorMinMax(simdInfo, left, right, dest, false);
    }

    // The pseudo-minimum and pseudo-maximum the specification defines as a
    // plain `b < a ? b : a`, with NO NaN special case -- so two instructions
    // and no repair. Getting min and pmin the same way round would be a
    // conformance bug that only NaN inputs could see.
    void vectorPmin(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest, FPRegisterID scratch)
    {
        ASSERT(scalarTypeIsFloatingPoint(simdInfo.lane));
        emitVectorCompareGreater(simdInfo, left, right, scratch);
        m_assembler.xxsel(dest, left, right, scratch);
    }

    void vectorPmax(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest, FPRegisterID scratch)
    {
        ASSERT(scalarTypeIsFloatingPoint(simdInfo.lane));
        emitVectorCompareGreater(simdInfo, right, left, scratch);
        m_assembler.xxsel(dest, left, right, scratch);
    }

    // ==================================================================
    // Vector shifts.
    //
    // The count is a VECTOR, one per lane, and POWER masks it to the lane
    // width in hardware. Measured here at 0, 1, w-1, w and w+1 for every
    // width: a byte count of 8 behaves as 0 and 9 as 1, a word count of 32 as
    // 0 and 33 as 1, a doubleword count of 64 as 0 and 65 as 1.
    //
    // Unlike ARM64 there is no negated-count convention: ARM64 has only a
    // left shift and reads a negative count as a right shift, whereas POWER
    // has vsl, vsr and vsra as three separate instructions. Adopting that
    // convention here would mean a run-time sign test to undo something that
    // exists only because of another instruction set.
    //
    // The immediate forms splat the count as a BYTE for every lane width,
    // which is what ARM64 does too: only the low bits of each lane's count
    // are read, and the count is already masked below the lane width.
    void vectorUshl(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID shift, FPRegisterID dest)
    {
        emitVMXBinary(input, shift, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            switch (simdInfo.lane) {
            case SIMDLane::i8x16: m_assembler.vslb(t, a, b); return;
            case SIMDLane::i16x8: m_assembler.vslh(t, a, b); return;
            case SIMDLane::i32x4: m_assembler.vslw(t, a, b); return;
            case SIMDLane::i64x2: m_assembler.vsld(t, a, b); return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    void vectorUshr(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID shift, FPRegisterID dest)
    {
        emitVMXBinary(input, shift, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            switch (simdInfo.lane) {
            case SIMDLane::i8x16: m_assembler.vsrb(t, a, b); return;
            case SIMDLane::i16x8: m_assembler.vsrh(t, a, b); return;
            case SIMDLane::i32x4: m_assembler.vsrw(t, a, b); return;
            case SIMDLane::i64x2: m_assembler.vsrd(t, a, b); return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    void vectorSshr(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID shift, FPRegisterID dest)
    {
        emitVMXBinary(input, shift, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            switch (simdInfo.lane) {
            case SIMDLane::i8x16: m_assembler.vsrab(t, a, b); return;
            case SIMDLane::i16x8: m_assembler.vsrah(t, a, b); return;
            case SIMDLane::i32x4: m_assembler.vsraw(t, a, b); return;
            case SIMDLane::i64x2: m_assembler.vsrad(t, a, b); return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    // Put a constant shift count in every byte of fpTempRegister. Byte width
    // serves every lane width because each lane reads only the low bits of
    // its own count, and the caller has already reduced the count below the
    // lane width.
    void emitSplatShiftCount(TrustedImm32 shift)
    {
        auto temp = temps<Data>();
        move(shift, temp.data());
        vectorSplat(SIMDLane::i8x16, temp.data(), fpTempRegister);
    }

    void vectorShl8(SIMDInfo simdInfo, FPRegisterID input, TrustedImm32 shift, FPRegisterID dest)
    {
        emitSplatShiftCount(shift);
        vectorUshl(simdInfo, input, fpTempRegister, dest);
    }

    void vectorUshr8(SIMDInfo simdInfo, FPRegisterID input, TrustedImm32 shift, FPRegisterID dest)
    {
        emitSplatShiftCount(shift);
        vectorUshr(simdInfo, input, fpTempRegister, dest);
    }

    void vectorSshr8(SIMDInfo simdInfo, FPRegisterID input, TrustedImm32 shift, FPRegisterID dest)
    {
        emitSplatShiftCount(shift);
        vectorSshr(simdInfo, input, fpTempRegister, dest);
    }

    // ==================================================================
    // Vector compares, and the two reductions that read CR6.
    //
    // POWER gives equality and greater-than, signed and unsigned, per lane
    // width. Everything else in the wasm set is one of those with the
    // operands SWAPPED, complemented with xxlnor, or both. Operand swapping
    // is the class that produced xxsel's reversed sense, so the tests assert
    // asymmetric operand pairs: a symmetric pair agrees with the swapped and
    // unswapped lowering alike.
    //
    // THE COMPARES DO NOT TOUCH CR6, deliberately. The recording forms exist
    // and are separately named in the assembler, and only the two reductions
    // below use them. Emitting a recording form here would leave the vector
    // result identical and clobber CR6, so nothing in a SIMD test would
    // notice -- and this port keeps every synthesised condition in a CR field
    // (the XER-avoidance policy below), so a gratuitously clobbered field is
    // a real hazard rather than a stylistic one. It uses CR0 and CR7 today,
    // not CR6, which makes the mistake invisible rather than harmless.
    void compareIntegerVector(RelationalCondition cond, SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        bool swap = false;
        bool invert = false;
        VectorCompareKind kind = VectorCompareKind::Equal;
        switch (cond) {
        case RelationalCondition::Equal:              kind = VectorCompareKind::Equal; break;
        case RelationalCondition::NotEqual:           kind = VectorCompareKind::Equal; invert = true; break;
        case RelationalCondition::GreaterThan:        kind = VectorCompareKind::GreaterSigned; break;
        case RelationalCondition::LessThan:           kind = VectorCompareKind::GreaterSigned; swap = true; break;
        case RelationalCondition::GreaterThanOrEqual: kind = VectorCompareKind::GreaterSigned; swap = true; invert = true; break;
        case RelationalCondition::LessThanOrEqual:    kind = VectorCompareKind::GreaterSigned; invert = true; break;
        case RelationalCondition::Above:              kind = VectorCompareKind::GreaterUnsigned; break;
        case RelationalCondition::Below:              kind = VectorCompareKind::GreaterUnsigned; swap = true; break;
        case RelationalCondition::AboveOrEqual:       kind = VectorCompareKind::GreaterUnsigned; swap = true; invert = true; break;
        case RelationalCondition::BelowOrEqual:       kind = VectorCompareKind::GreaterUnsigned; invert = true; break;
        default: RELEASE_ASSERT_NOT_REACHED();
        }
        FPRegisterID a = swap ? right : left;
        FPRegisterID b = swap ? left : right;
        emitVMXBinary(a, b, dest, [&](VRegisterID t, VRegisterID x, VRegisterID y) {
            emitVectorCompareVMX(kind, simdInfo.lane, t, x, y);
        });
        if (invert)
            m_assembler.xxlnor(dest, dest, dest);
    }

    void compareIntegerVectorWithZero(RelationalCondition cond, SIMDInfo simdInfo, FPRegisterID vector, FPRegisterID dest)
    {
        bool swap = false;
        bool invert = false;
        VectorCompareKind kind = VectorCompareKind::Equal;
        switch (cond) {
        case RelationalCondition::Equal:              kind = VectorCompareKind::Equal; break;
        case RelationalCondition::NotEqual:           kind = VectorCompareKind::Equal; invert = true; break;
        case RelationalCondition::GreaterThan:        kind = VectorCompareKind::GreaterSigned; break;
        case RelationalCondition::LessThan:           kind = VectorCompareKind::GreaterSigned; swap = true; break;
        case RelationalCondition::GreaterThanOrEqual: kind = VectorCompareKind::GreaterSigned; swap = true; invert = true; break;
        case RelationalCondition::LessThanOrEqual:    kind = VectorCompareKind::GreaterSigned; invert = true; break;
        default: RELEASE_ASSERT_NOT_REACHED();
        }
        m_assembler.xxlor(vectorBridge0VSR, vector, vector);
        m_assembler.vxor(vectorBridge1, vectorBridge1, vectorBridge1);
        if (swap)
            emitVectorCompareVMX(kind, simdInfo.lane, vectorBridge0, vectorBridge1, vectorBridge0);
        else
            emitVectorCompareVMX(kind, simdInfo.lane, vectorBridge0, vectorBridge0, vectorBridge1);
        m_assembler.xxlor(dest, vectorBridge0VSR, vectorBridge0VSR);
        if (invert)
            m_assembler.xxlnor(dest, dest, dest);
    }

    // The VSX float compares are the ORDERED forms, which is what wasm wants:
    // a NaN operand gives false. "not equal or unordered" is therefore the
    // complement of ordered equality, and is true for a NaN -- which is why
    // it is the only member of the set that needs the complement.
    void compareFloatingPointVector(DoubleCondition cond, SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        RELEASE_ASSERT(scalarTypeIsFloatingPoint(simdInfo.lane));
        bool isFloat = simdInfo.lane == SIMDLane::f32x4;
        switch (cond) {
        case DoubleCondition::DoubleEqualAndOrdered:
            isFloat ? m_assembler.xvcmpeqsp(dest, left, right) : m_assembler.xvcmpeqdp(dest, left, right);
            return;
        case DoubleCondition::DoubleNotEqualOrUnordered:
            isFloat ? m_assembler.xvcmpeqsp(dest, left, right) : m_assembler.xvcmpeqdp(dest, left, right);
            m_assembler.xxlnor(dest, dest, dest);
            return;
        case DoubleCondition::DoubleGreaterThanAndOrdered:
            isFloat ? m_assembler.xvcmpgtsp(dest, left, right) : m_assembler.xvcmpgtdp(dest, left, right);
            return;
        case DoubleCondition::DoubleGreaterThanOrEqualAndOrdered:
            isFloat ? m_assembler.xvcmpgesp(dest, left, right) : m_assembler.xvcmpgedp(dest, left, right);
            return;
        case DoubleCondition::DoubleLessThanAndOrdered:
            isFloat ? m_assembler.xvcmpgtsp(dest, right, left) : m_assembler.xvcmpgtdp(dest, right, left);
            return;
        case DoubleCondition::DoubleLessThanOrEqualAndOrdered:
            isFloat ? m_assembler.xvcmpgesp(dest, right, left) : m_assembler.xvcmpgedp(dest, right, left);
            return;
        default:
            RELEASE_ASSERT_NOT_REACHED();
        }
    }

    // THE TWO CR6 READERS. Measured, not read from the manual: a recording
    // compare of a vector against zero sets CR6 bit 0 when EVERY lane is
    // equal (so the vector is all zero) and CR6 bit 2 when NO lane is equal
    // (so every lane is non-zero). CR6 occupies CR bits 24-27, so bit 0 is
    // CR bit 24 and bit 2 is CR bit 26; the rlwinm rotates the wanted one to
    // bit 31 and masks it.
    void vectorAnyTrue(FPRegisterID vector, RegisterID dest)
    {
        m_assembler.xxlor(vectorBridge0VSR, vector, vector);
        m_assembler.vxor(vectorBridge1, vectorBridge1, vectorBridge1);
        // Byte width is enough: v128.any_true asks whether ANY BIT is set.
        m_assembler.vcmpequb_(vectorBridge2, vectorBridge0, vectorBridge1);
        m_assembler.mfcr(dest);
        m_assembler.rlwinm(dest, dest, 25, 31, 31);   // CR bit 24 -> bit 31
        m_assembler.xori(dest, dest, 1);              // all-zero means NOT any
    }

    void vectorAllTrue(SIMDInfo simdInfo, FPRegisterID vector, RegisterID dest)
    {
        m_assembler.xxlor(vectorBridge0VSR, vector, vector);
        m_assembler.vxor(vectorBridge1, vectorBridge1, vectorBridge1);
        // Here the lane width matters: all_true asks whether every LANE is
        // non-zero, and a byte compare would answer a different question.
        switch (simdInfo.lane) {
        case SIMDLane::i8x16: m_assembler.vcmpequb_(vectorBridge2, vectorBridge0, vectorBridge1); break;
        case SIMDLane::i16x8: m_assembler.vcmpequh_(vectorBridge2, vectorBridge0, vectorBridge1); break;
        case SIMDLane::i32x4: m_assembler.vcmpequw_(vectorBridge2, vectorBridge0, vectorBridge1); break;
        case SIMDLane::i64x2: m_assembler.vcmpequd_(vectorBridge2, vectorBridge0, vectorBridge1); break;
        default: RELEASE_ASSERT_NOT_REACHED();
        }
        m_assembler.mfcr(dest);
        m_assembler.rlwinm(dest, dest, 27, 31, 31);   // CR bit 26 -> bit 31
    }

    // ==================================================================
    // Vector arithmetic: add, subtract, multiply, negate, absolute value.
    //
    // Each of these has BOTH an integer and a floating-point lane set, and
    // both arms land together. Writing one and leaving the other to assert
    // would ship a function that aborts for half its declared domain.
    //
    // The float arms are VSX and address the registers directly. The integer
    // arms are VMX-form -- there is no VSX integer vector add on the POWER8
    // floor -- so they go through the bridge and cost four instructions.
    void vectorAdd(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        if (simdInfo.lane == SIMDLane::f32x4) {
            m_assembler.xvaddsp(dest, left, right);
            return;
        }
        if (simdInfo.lane == SIMDLane::f64x2) {
            m_assembler.xvadddp(dest, left, right);
            return;
        }
        emitVMXBinary(left, right, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            switch (simdInfo.lane) {
            case SIMDLane::i8x16: m_assembler.vaddubm(t, a, b); return;
            case SIMDLane::i16x8: m_assembler.vadduhm(t, a, b); return;
            case SIMDLane::i32x4: m_assembler.vadduwm(t, a, b); return;
            case SIMDLane::i64x2: m_assembler.vaddudm(t, a, b); return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    void vectorSub(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        if (simdInfo.lane == SIMDLane::f32x4) {
            m_assembler.xvsubsp(dest, left, right);
            return;
        }
        if (simdInfo.lane == SIMDLane::f64x2) {
            m_assembler.xvsubdp(dest, left, right);
            return;
        }
        emitVMXBinary(left, right, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            switch (simdInfo.lane) {
            case SIMDLane::i8x16: m_assembler.vsububm(t, a, b); return;
            case SIMDLane::i16x8: m_assembler.vsubuhm(t, a, b); return;
            case SIMDLane::i32x4: m_assembler.vsubuwm(t, a, b); return;
            case SIMDLane::i64x2: m_assembler.vsubudm(t, a, b); return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    void vectorMul(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        if (simdInfo.lane == SIMDLane::f32x4) {
            m_assembler.xvmulsp(dest, left, right);
            return;
        }
        if (simdInfo.lane == SIMDLane::f64x2) {
            m_assembler.xvmuldp(dest, left, right);
            return;
        }
        // wasm has no i8x16.mul, and BBQ scalarizes i64x2.mul itself because
        // the single instruction for it, vmulld, is ISA 3.1 and therefore
        // POWER10. So only the halfword and word forms arrive here.
        emitVMXBinary(left, right, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            switch (simdInfo.lane) {
            case SIMDLane::i16x8:
                // There is no plain halfword multiply: vmladduhm is a
                // multiply-add, and a zero addend makes it one.
                m_assembler.vxor(vectorBridge2, vectorBridge2, vectorBridge2);
                m_assembler.vmladduhm(t, a, b, vectorBridge2);
                return;
            case SIMDLane::i32x4: m_assembler.vmuluwm(t, a, b); return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    void vectorNeg(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest)
    {
        if (simdInfo.lane == SIMDLane::f32x4) {
            m_assembler.xvnegsp(dest, input);
            return;
        }
        if (simdInfo.lane == SIMDLane::f64x2) {
            m_assembler.xvnegdp(dest, input);
            return;
        }
        emitVMXUnary(input, dest, [&](VRegisterID t, VRegisterID b) {
            m_assembler.vxor(vectorBridge2, vectorBridge2, vectorBridge2);
            switch (simdInfo.lane) {
            case SIMDLane::i8x16: m_assembler.vsububm(t, vectorBridge2, b); return;
            case SIMDLane::i16x8: m_assembler.vsubuhm(t, vectorBridge2, b); return;
            case SIMDLane::i32x4: m_assembler.vsubuwm(t, vectorBridge2, b); return;
            case SIMDLane::i64x2: m_assembler.vsubudm(t, vectorBridge2, b); return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    void vectorAbs(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest)
    {
        if (simdInfo.lane == SIMDLane::f32x4) {
            m_assembler.xvabssp(dest, input);
            return;
        }
        if (simdInfo.lane == SIMDLane::f64x2) {
            m_assembler.xvabsdp(dest, input);
            return;
        }
        // max(a, 0 - a), signed. At the most negative value the negation
        // wraps to itself and the maximum returns it -- which is what wasm
        // specifies: i8x16.abs(-128) is -128.
        emitVMXUnary(input, dest, [&](VRegisterID t, VRegisterID b) {
            m_assembler.vxor(vectorBridge2, vectorBridge2, vectorBridge2);
            switch (simdInfo.lane) {
            case SIMDLane::i8x16:
                m_assembler.vsububm(vectorBridge2, vectorBridge2, b);
                m_assembler.vmaxsb(t, b, vectorBridge2);
                return;
            case SIMDLane::i16x8:
                m_assembler.vsubuhm(vectorBridge2, vectorBridge2, b);
                m_assembler.vmaxsh(t, b, vectorBridge2);
                return;
            case SIMDLane::i32x4:
                m_assembler.vsubuwm(vectorBridge2, vectorBridge2, b);
                m_assembler.vmaxsw(t, b, vectorBridge2);
                return;
            case SIMDLane::i64x2:
                m_assembler.vsubudm(vectorBridge2, vectorBridge2, b);
                m_assembler.vmaxsd(t, b, vectorBridge2);
                return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    // ==================================================================
    // Vector bitwise. The VSX logical group is bit-for-bit lane-agnostic, so
    // these are one instruction each and the SIMDInfo is only asserted.
    // No VMX form is involved, so this group does not depend on how the
    // register-model question is settled.
    void vectorAnd(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        ASSERT_UNUSED(simdInfo, simdInfo.lane == SIMDLane::v128);
        m_assembler.xxland(dest, left, right);
    }

    void vectorOr(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        ASSERT_UNUSED(simdInfo, simdInfo.lane == SIMDLane::v128);
        m_assembler.xxlor(dest, left, right);
    }

    void vectorXor(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        ASSERT_UNUSED(simdInfo, simdInfo.lane == SIMDLane::v128);
        m_assembler.xxlxor(dest, left, right);
    }

    // wasm v128.andnot is `left & ~right`, and xxlandc is XA & ~XB in exactly
    // that order -- one instruction, no operand swap.
    void vectorAndnot(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        ASSERT_UNUSED(simdInfo, simdInfo.lane == SIMDLane::v128);
        m_assembler.xxlandc(dest, left, right);
    }

    void vectorNot(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest)
    {
        ASSERT_UNUSED(simdInfo, simdInfo.lane == SIMDLane::v128);
        m_assembler.xxlnor(dest, input, input);
    }

    // ARM64's bsl computes (sel & left) | (~sel & right) with the selector in
    // the destination. xxsel computes (XA & ~XC) | (XB & XC), so the selector
    // is XC and the SENSE IS THE OTHER WAY ROUND: a set selector bit takes XB.
    // left therefore goes in XB and right in XA. XT == XC is safe because the
    // selector is read before the result is written.
    void vectorBitwiseSelect(FPRegisterID left, FPRegisterID right, FPRegisterID inputBitsAndDest)
    {
        m_assembler.xxsel(inputBitsAndDest, right, left, inputBitsAndDest);
    }

    // ==================================================================
    // Saturating arithmetic, widening, narrowing, and the pairwise and
    // extended multiplies.
    //
    // All VMX-form, so all through the bridge. The lowerings are IPInt's
    // (llint/InPlaceInterpreter64.asm, the ipint_simd_* handlers), which the
    // wasm corpus exercises; what is new here is the register plumbing. Two
    // lane-order facts recur (jsc-ppc64le-wasm-simd.md section 2): the ISA's
    // "high" half is the memory-HIGH half, so vupkh*/vmrgh* are wasm's *_high
    // and vupkl*/vmrgl* its *_low; and the packs write VRA into the
    // memory-high half, so wasm's (lower, upper) pair goes in as (upper, lower).
    //
    // The shared contract's lane argument is not uniform, and getting it
    // wrong is a silently wrong width rather than a crash: ExtendLow/High and
    // MulLow/High carry the RESULT lane; Narrow, ExtaddPairwise, ConvertLow,
    // Promote and Demote carry the SOURCE lane (B3ReduceStrength.cpp says so
    // for ExtaddPairwise in as many words; the x86 arms confirm the rest).
    void vectorAddSat(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        ASSERT(simdInfo.signMode != SIMDSignMode::None);
        bool isSigned = simdInfo.signMode == SIMDSignMode::Signed;
        emitVMXBinary(left, right, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            switch (simdInfo.lane) {
            case SIMDLane::i8x16: isSigned ? m_assembler.vaddsbs(t, a, b) : m_assembler.vaddubs(t, a, b); return;
            case SIMDLane::i16x8: isSigned ? m_assembler.vaddshs(t, a, b) : m_assembler.vadduhs(t, a, b); return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    void vectorSubSat(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        ASSERT(simdInfo.signMode != SIMDSignMode::None);
        bool isSigned = simdInfo.signMode == SIMDSignMode::Signed;
        emitVMXBinary(left, right, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            switch (simdInfo.lane) {
            case SIMDLane::i8x16: isSigned ? m_assembler.vsubsbs(t, a, b) : m_assembler.vsububs(t, a, b); return;
            case SIMDLane::i16x8: isSigned ? m_assembler.vsubshs(t, a, b) : m_assembler.vsubuhs(t, a, b); return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    // The "us" packs take SIGNED input and saturate to the unsigned range,
    // which is what narrow_u is. The lane is the SOURCE width.
    void vectorNarrow(SIMDInfo simdInfo, FPRegisterID lower, FPRegisterID upper, FPRegisterID dest, FPRegisterID)
    {
        ASSERT(simdInfo.signMode != SIMDSignMode::None);
        bool isSigned = simdInfo.signMode == SIMDSignMode::Signed;
        // upper in VRA, which becomes the memory-high half; lower in VRB.
        emitVMXBinary(upper, lower, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            switch (simdInfo.lane) {
            case SIMDLane::i16x8: isSigned ? m_assembler.vpkshss(t, a, b) : m_assembler.vpkshus(t, a, b); return;
            case SIMDLane::i32x4: isSigned ? m_assembler.vpkswss(t, a, b) : m_assembler.vpkswus(t, a, b); return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    void vectorExtendLow(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest) { emitVectorExtend(simdInfo, input, dest, false); }
    void vectorExtendHigh(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest) { emitVectorExtend(simdInfo, input, dest, true); }

    // The trailing scratch is x86's; POWER's vmul*e/vmul*o need none. It gets
    // ARM64's InvalidFPRReg default (MacroAssemblerARM64.h) so that Air can
    // declare the four-operand form and not burn a dead FP Tmp per extmul.
    void vectorMulLow(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest, FPRegisterID = InvalidFPRReg) { emitVectorExtendedMultiply(simdInfo, left, right, dest, false); }
    void vectorMulHigh(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest, FPRegisterID = InvalidFPRReg) { emitVectorExtendedMultiply(simdInfo, left, right, dest, true); }

    void vectorPopcnt(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest)
    {
        ASSERT_UNUSED(simdInfo, simdInfo.lane == SIMDLane::i8x16);
        emitVMXUnary(input, dest, [&](VRegisterID t, VRegisterID b) {
            m_assembler.vpopcntb(t, b);
        });
    }

    void vectorAvgRound(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        emitVMXBinary(left, right, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            switch (simdInfo.lane) {
            case SIMDLane::i8x16: m_assembler.vavgub(t, a, b); return;
            case SIMDLane::i16x8: m_assembler.vavguh(t, a, b); return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    // i16x8.q15mulr_sat_s. vmhraddshs rounds and saturates in the one
    // instruction, including the only case that needs saturating:
    // (-32768 * -32768) is 32767. The relaxed form is permitted to be the same.
    void vectorMulSat(FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        emitVMXBinary(left, right, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            m_assembler.vxor(vectorBridge2, vectorBridge2, vectorBridge2);
            m_assembler.vmhraddshs(t, a, b, vectorBridge2);
        });
    }

    void vectorRelaxedQ15Mulr(FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        vectorMulSat(left, right, dest);
    }

    // i32x4.dot_i16x8_s. The pairing is within a word, which byte order
    // cannot disturb.
    void vectorDotProduct(FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        emitVMXBinary(left, right, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            m_assembler.vxor(vectorBridge2, vectorBridge2, vectorBridge2);
            m_assembler.vmsumshm(t, a, b, vectorBridge2);
        });
    }

    // extadd_pairwise: the dot product against a vector of ones. There is no
    // multiply-sum into halfwords, so the byte form is the even and the odd
    // widening products added -- the same sum, each halfword of the result
    // being one even and one odd byte. The lane is the SOURCE width.
    void vectorExtaddPairwise(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest)
    {
        ASSERT(simdInfo.signMode != SIMDSignMode::None);
        bool isSigned = simdInfo.signMode == SIMDSignMode::Signed;
        emitVMXUnary(input, dest, [&](VRegisterID t, VRegisterID b) {
            switch (simdInfo.lane) {
            case SIMDLane::i8x16:
                m_assembler.vspltisb(vectorBridge2, 1);
                if (isSigned) {
                    m_assembler.vmulesb(vectorBridge1, b, vectorBridge2);
                    m_assembler.vmulosb(t, b, vectorBridge2);
                } else {
                    m_assembler.vmuleub(vectorBridge1, b, vectorBridge2);
                    m_assembler.vmuloub(t, b, vectorBridge2);
                }
                m_assembler.vadduhm(t, t, vectorBridge1);
                return;
            case SIMDLane::i16x8:
                m_assembler.vspltish(vectorBridge1, 1);
                m_assembler.vxor(vectorBridge2, vectorBridge2, vectorBridge2);
                isSigned ? m_assembler.vmsumshm(t, b, vectorBridge1, vectorBridge2) : m_assembler.vmsumuhm(t, b, vectorBridge1, vectorBridge2);
                return;
            default:
                RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    // The relaxed byte dot products. relaxed_dot_i8x16_i7x16_s is the
    // halfword pairwise sum above with a real second operand; the _add form
    // then widens pairwise to words against ones and adds the accumulator.
    // Both multiply signed bytes, which is exact over the i7 range and
    // implementation-defined outside it, as the relaxed specification allows.
    void vectorRelaxedDotI8x16I7x16(FPRegisterID left, FPRegisterID right, FPRegisterID dest, FPRegisterID)
    {
        emitVMXBinary(left, right, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            m_assembler.vmulesb(vectorBridge2, a, b);
            m_assembler.vmulosb(t, a, b);
            m_assembler.vadduhm(t, t, vectorBridge2);
        });
    }

    void vectorRelaxedDotI8x16I7x16Add(FPRegisterID left, FPRegisterID right, FPRegisterID addend, FPRegisterID dest, FPRegisterID, FPRegisterID)
    {
        m_assembler.xxlor(vectorBridge0VSR, left, left);
        m_assembler.xxlor(vectorBridge1VSR, right, right);
        m_assembler.vmulesb(vectorBridge2, vectorBridge0, vectorBridge1);
        m_assembler.vmulosb(vectorBridge0, vectorBridge0, vectorBridge1);
        m_assembler.vadduhm(vectorBridge0, vectorBridge0, vectorBridge2);
        m_assembler.vspltish(vectorBridge1, 1);
        m_assembler.vxor(vectorBridge2, vectorBridge2, vectorBridge2);
        m_assembler.vmsumshm(vectorBridge0, vectorBridge0, vectorBridge1, vectorBridge2);
        // right is dead, so its bridge register takes the addend.
        m_assembler.xxlor(vectorBridge1VSR, addend, addend);
        m_assembler.vadduwm(vectorBridge0, vectorBridge0, vectorBridge1);
        m_assembler.xxlor(dest, vectorBridge0VSR, vectorBridge0VSR);
    }

    // ==================================================================
    // The width-changing conversions (jsc-ppc64le-vector-conversions.md
    // section 1.4). Every VSX instruction here lands its result in the wrong
    // word positions and needs a word-granularity fix: the dp->sp and dp->int
    // forms DUPLICATE each result into both words of its doubleword, which
    // vpkudum against zero undoes while supplying the zero lanes; xvcvspdp
    // reads ISA words 0 and 2 -- memory lanes 3 and 1 -- so promote merges
    // the wanted low lanes into those positions first. The VSX conversions
    // name the bridge register directly, their fields being six bits wide,
    // which saves a copy in each direction. The lane is the SOURCE width.
    void vectorPromote(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest)
    {
        ASSERT_UNUSED(simdInfo, simdInfo.lane == SIMDLane::f32x4);
        // [w2, w2, w3, w3] in ISA order: memory lanes 1 and 0 at the words xvcvspdp reads.
        m_assembler.xxmrglw(dest, input, input);
        m_assembler.xvcvspdp(dest, dest);
    }

    void vectorDemote(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest)
    {
        ASSERT_UNUSED(simdInfo, simdInfo.lane == SIMDLane::f64x2);
        m_assembler.xvcvdpsp(vectorBridge0VSR, input);
        emitVectorPackDoublewordsToLowWords(dest);
    }

    void vectorConvertLow(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest)
    {
        ASSERT(simdInfo.lane == SIMDLane::i32x4);
        ASSERT(simdInfo.signMode != SIMDSignMode::None);
        m_assembler.xxlor(vectorBridge0VSR, input, input);
        if (simdInfo.signMode == SIMDSignMode::Signed) {
            m_assembler.vupklsw(vectorBridge0, vectorBridge0);
            m_assembler.xvcvsxddp(dest, vectorBridge0VSR);
            return;
        }
        m_assembler.vxor(vectorBridge2, vectorBridge2, vectorBridge2);
        m_assembler.vmrglw(vectorBridge0, vectorBridge2, vectorBridge0);
        m_assembler.xvcvuxddp(dest, vectorBridge0VSR);
    }

    // ==================================================================
    // Relaxed SIMD: fused multiply-add, min/max, and the two permutes.
    //
    // relaxed_madd is a*b + c with one rounding: xvmadda* with the addend in
    // XT. relaxed_nmadd is -(a*b) + c. The instruction shaped for it,
    // xvnmsuba*, computes -(a*b - c), which differs from fma(-a, b, c) in one
    // place: an EXACT-ZERO result is -0 rather than +0, because the sign of
    // an exact zero is that of the subtraction it came from. The
    // specification's reference is fma(-a, b, c), and ARM64's fmls and x86's
    // mul-then-sub both give +0 there, so this negates a first and uses the
    // positive form: one more instruction. IPInt's handler uses xvnmsuba*
    // and therefore differs from BBQ in that one sign bit.
    void vectorFusedMulAdd(SIMDInfo simdInfo, FPRegisterID mul1, FPRegisterID mul2, FPRegisterID addend, FPRegisterID dest, FPRegisterID)
    {
        emitVectorFusedMultiplyAdd(simdInfo, mul1, mul2, addend, dest, false);
    }

    void vectorFusedNegMulAdd(SIMDInfo simdInfo, FPRegisterID mul1, FPRegisterID mul2, FPRegisterID addend, FPRegisterID dest, FPRegisterID)
    {
        emitVectorFusedMultiplyAdd(simdInfo, mul1, mul2, addend, dest, true);
    }

    // The one-instruction minNum/maxNum that the relaxed specification
    // permits; vectorMin/vectorMax above are the strict forms with the NaN
    // repair.
    void vectorRelaxedMin(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        if (simdInfo.lane == SIMDLane::f32x4)
            m_assembler.xvminsp(dest, left, right);
        else if (simdInfo.lane == SIMDLane::f64x2)
            m_assembler.xvmindp(dest, left, right);
        else
            RELEASE_ASSERT_NOT_REACHED();
    }

    void vectorRelaxedMax(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest)
    {
        if (simdInfo.lane == SIMDLane::f32x4)
            m_assembler.xvmaxsp(dest, left, right);
        else if (simdInfo.lane == SIMDLane::f64x2)
            m_assembler.xvmaxdp(dest, left, right);
        else
            RELEASE_ASSERT_NOT_REACHED();
    }

    // i8x16.swizzle: a control lane of 16 or more must read as zero. vpermr
    // takes its index modulo 32, so 16..31 would select VRA and anything
    // above wraps; the mask is therefore built from the ORIGINAL control and
    // applied afterwards, and VRA may simply be `a` again. The POWER8 arm is
    // vperm, which indexes ISA bytes -- index k there is memory byte 15-k --
    // so the control is complemented: ~k has the same low five bits as 31-k,
    // and five bits is all vperm reads. The same instruction serves the
    // relaxed form, whose out-of-range result is unconstrained.
    void vectorSwizzle(FPRegisterID a, FPRegisterID control, FPRegisterID dest)
    {
        m_assembler.xxlor(vectorBridge0VSR, a, a);
        m_assembler.xxlor(vectorBridge1VSR, control, control);
        m_assembler.vspltisb(vectorBridge2, 15);
        m_assembler.vcmpgtub(vectorBridge2, vectorBridge1, vectorBridge2); // the lanes whose index exceeds 15
        if (Assembler::hasISA30())
            m_assembler.vpermr(vectorBridge0, vectorBridge0, vectorBridge0, vectorBridge1);
        else {
            m_assembler.vnor(vectorBridge1, vectorBridge1, vectorBridge1);
            m_assembler.vperm(vectorBridge0, vectorBridge0, vectorBridge0, vectorBridge1);
        }
        m_assembler.vandc(vectorBridge0, vectorBridge0, vectorBridge2);
        m_assembler.xxlor(dest, vectorBridge0VSR, vectorBridge0VSR);
    }

    // i8x16.shuffle over the 32-byte table a||b. vpermr selects VRB for
    // 0..15 and VRA for 16..31, both in memory order -- wasm's numbering
    // exactly -- so VRA = b and VRB = a, and the complemented-control vperm
    // derivation gives the same operand order. Shuffle immediates are
    // validated below 32, so there is no mask. Unlike ARM64's tbl2, a and b
    // need not be adjacent registers; the shared signature is kept so the
    // BBQ arm is one line.
    void vectorSwizzle2(FPRegisterID a, FPRegisterID b, FPRegisterID control, FPRegisterID dest)
    {
        m_assembler.xxlor(vectorBridge0VSR, a, a);
        m_assembler.xxlor(vectorBridge1VSR, b, b);
        m_assembler.xxlor(vectorBridge2VSR, control, control);
        if (Assembler::hasISA30())
            m_assembler.vpermr(vectorBridge0, vectorBridge1, vectorBridge0, vectorBridge2);
        else {
            m_assembler.vnor(vectorBridge2, vectorBridge2, vectorBridge2);
            m_assembler.vperm(vectorBridge0, vectorBridge1, vectorBridge0, vectorBridge2);
        }
        m_assembler.xxlor(dest, vectorBridge0VSR, vectorBridge0VSR);
    }

    // ==================================================================
    // Bitmask: the sign bit of every lane, lane i at bit i.
    //
    // POWER has no movemask. vgbbd transposes the 8x8 bit matrix of each
    // doubleword, so the TOP byte of each doubleword collects the eight sign
    // bits of that doubleword's bytes, with lane order equal to bit order:
    // memory byte 7 holds lanes 0-7 and memory byte 15 lanes 8-15. The wider
    // lanes are first packed down to bytes with the SATURATING packs, which
    // preserve every lane's sign, against a zero VRB so the lanes land in the
    // memory-high half and a single mfvsrd reads them. i64x2 needs no vector
    // work at all. This lowering is the port's own rather than IPInt's (which
    // loops over the bytes in memory), so it is probed lane by lane in
    // testmasm rather than inherited.
    void vectorBitmask(SIMDInfo simdInfo, FPRegisterID vector, RegisterID dest)
    {
        auto temp = temps<Data>();
        switch (simdInfo.lane) {
        case SIMDLane::i64x2:
            emitVectorDoublewordToGPR(vector, 0, temp.data());    // lane 0
            m_assembler.mfvsrd(dest, vector);                      // lane 1 is ISA doubleword 0
            m_assembler.rldicl(dest, dest, 1, 63);                 // its sign to bit 0
            m_assembler.rldicl(temp.data(), temp.data(), 1, 63);
            m_assembler.sldi(dest, dest, 1);
            m_assembler.or_(dest, dest, temp.data());
            return;
        case SIMDLane::i8x16:
            m_assembler.xxlor(vectorBridge0VSR, vector, vector);
            m_assembler.vgbbd(vectorBridge0, vectorBridge0);
            m_assembler.mfvsrd(dest, vectorBridge0VSR);                    // top byte: lanes 8-15
            emitVectorDoublewordToGPR(vectorBridge0VSR, 0, temp.data());   // top byte: lanes 0-7
            m_assembler.rldicl(dest, dest, 8, 56);
            m_assembler.rldicl(temp.data(), temp.data(), 8, 56);
            m_assembler.sldi(dest, dest, 8);
            m_assembler.or_(dest, dest, temp.data());
            return;
        case SIMDLane::i16x8:
            m_assembler.xxlor(vectorBridge0VSR, vector, vector);
            m_assembler.vxor(vectorBridge2, vectorBridge2, vectorBridge2);
            m_assembler.vpkshss(vectorBridge0, vectorBridge0, vectorBridge2);
            m_assembler.vgbbd(vectorBridge0, vectorBridge0);
            m_assembler.mfvsrd(dest, vectorBridge0VSR);
            m_assembler.rldicl(dest, dest, 8, 56);
            return;
        case SIMDLane::i32x4:
            m_assembler.xxlor(vectorBridge0VSR, vector, vector);
            m_assembler.vxor(vectorBridge2, vectorBridge2, vectorBridge2);
            m_assembler.vpkswss(vectorBridge0, vectorBridge0, vectorBridge2);
            m_assembler.vpkshss(vectorBridge0, vectorBridge0, vectorBridge2);
            m_assembler.vgbbd(vectorBridge0, vectorBridge0);
            m_assembler.mfvsrd(dest, vectorBridge0VSR);
            // The four lanes occupied ISA bytes 0-3: the high nibble of the top byte.
            m_assembler.rldicl(dest, dest, 4, 60);
            return;
        default:
            RELEASE_ASSERT_NOT_REACHED();
        }
    }
    template<PtrTag resultTag, PtrTag locationTag>
    static CodePtr<resultTag> readCallTarget(CodeLocationCall<locationTag> call)
    {
        return CodePtr<resultTag>::fromTaggedPtr(Assembler::readCallTarget(call.dataLocation()));
    }

    template<PtrTag tag>
    static void replaceWithVMHalt(CodeLocationLabel<tag> instructionStart)
    {
        Assembler::replaceWithVMHalt(instructionStart.dataLocation());
    }

    template<PtrTag startTag, PtrTag destTag>
    static void replaceWithJump(CodeLocationLabel<startTag> instructionStart, CodeLocationLabel<destTag> destination)
    {
        Assembler::replaceWithJump(instructionStart.dataLocation(), destination.dataLocation());
    }

    template<PtrTag startTag>
    static void replaceWithNops(CodeLocationLabel<startTag> instructionStart, size_t memoryToFillWithNopsInBytes)
    {
        Assembler::replaceWithNops(instructionStart.dataLocation(), memoryToFillWithNopsInBytes);
    }

    // branchPtrWithPatch puts the five-word constant ladder FIRST, so the
    // start of the branch and the start of the patchable constant are the
    // same address, and replaceWithJump's one-word overwrite lands on the
    // ladder's first word. revertJumpReplacementToPatch rewrites all five.
    template<PtrTag tag>
    static CodeLocationLabel<tag> startOfBranchPtrWithPatchOnRegister(CodeLocationDataLabelPtr<tag> label)
    {
        return label.labelAtOffset(0);
    }

    template<PtrTag tag>
    static void revertJumpReplacementToBranchPtrWithPatch(CodeLocationLabel<tag> instructionStart, RegisterID rd, void* initialValue)
    {
        Assembler::revertJumpReplacementToPatch(instructionStart.dataLocation(), rd, initialValue);
    }

    // Three-way, unlike RISCV64's two-way: on PowerPC a tail call is `b` and
    // a call is `bl`, and they differ in the LK bit that writeJumpSite sets
    // from its `link` argument, so the tail case cannot share the call path.
    template<PtrTag tag>
    static void linkCall(void* code, Call call, CodePtr<tag> function)
    {
        if (!call.isFlagSet(Call::Near))
            Assembler::linkPointer(code, call.m_label, function.taggedPtr());
        else if (call.isFlagSet(Call::Tail))
            Assembler::linkJump(code, call.m_label, function.untaggedPtr());
        else
            Assembler::linkCall(code, call.m_label, function.untaggedPtr());
    }

    template<PtrTag callTag, PtrTag destTag>
    static void repatchCall(CodeLocationCall<callTag> call, CodeLocationLabel<destTag> destination)
    {
        Assembler::repatchPointer(call.dataLocation(), destination.taggedPtr());
    }

    template<PtrTag callTag, PtrTag destTag>
    static void repatchCall(CodeLocationCall<callTag> call, CodePtr<destTag> destination)
    {
        Assembler::repatchPointer(call.dataLocation(), destination.taggedPtr());
    }
    // ==================================================================
    // Control transfer.
    //
    // THE CENTRAL ABI RULE OF THIS PORT, and the thing most likely to be got
    // wrong: a call to a C/C++ function and a call to generated code need
    // DIFFERENT sequences, and the difference is not cosmetic.
    //
    // ELFv2 requires the CALLER to own a 32-byte linkage area at r1. A
    // non-leaf callee writes its return address to 16(r1) -- its caller's
    // frame -- before establishing a frame of its own, and may write CR to
    // 8(r1). So a C call must move sp down by 32 first, or the callee
    // scribbles on whatever the caller had there.
    //
    // A JavaScript call must do the exact opposite: sp at a JS call already
    // points at the callee's new JS frame, and the callee's prologue writes
    // CallerFrame and ReturnPC relative to it. Moving sp by 32 there shifts
    // the whole frame and corrupts everything.
    //
    // The LLInt hit precisely this: jsc-ppc64le-port.md section 5.3 records
    // `std 2, 24(1)` landing in the Callee slot of a live JS frame, so
    // handleHostCall() received a callee equal to r2. offlineasm/ppc64.rb
    // answered it by making them two different instructions (`call` versus
    // `ppc64JSCall`) rather than one with a flag. The MacroAssembler cannot
    // do that -- call(RegisterID, PtrTag) and call(Address, PtrTag) are each
    // used for both -- so the discriminator here is the PtrTag's callee
    // type, which JSCPtrTag.h already records for every tag.
    //
    // maxFrameExtentForSlowPathCall (32 on this target) is a SEPARATE
    // reservation, made by the caller for outgoing stack arguments; pokes go
    // to sp+0.. and, after this sequence moves sp down by 32, land exactly
    // where ELFv2 puts the first stack parameter. The two do not overlap.
    // ==================================================================

    static constexpr bool callTargetIsNativeCode(PtrTag tag)
    {
        switch (tag) {
#define JSC_PPC64_CALLEE_TYPE_CASE(name, calleeTypeValue, callerTypeValue) \
        case JSC::name: return (calleeTypeValue) == PtrTagCalleeType::Native;
        FOR_EACH_JSC_PTRTAG(JSC_PPC64_CALLEE_TYPE_CASE)
#undef JSC_PPC64_CALLEE_TYPE_CASE
        // CFunctionPtrTag is WTF's, not JSC's, so FOR_EACH_JSC_PTRTAG does
        // not cover it -- but it is the one tag outside that list whose whole
        // meaning is the answer to this question. bun:ffi calls its target
        // with it, and an arbitrary C function is exactly what needs the
        // linkage area, the r12 entry-point register and the r2 save. This is
        // a classification, not a guess; every other unlisted tag still stops
        // below.
        case CFunctionPtrTag:
            return true;
        default:
            break;
        }
        // A tag that is not in JSC's list reached a call. Rather than guess
        // which ABI it wants, stop: guessing "generated code" corrupts the
        // stack of a C callee, and guessing "C" corrupts a JS frame.
        RELEASE_ASSERT_NOT_REACHED();
        return false;
    }

    // r2 is the TOC pointer and is invariant across the whole engine
    // (jsc-ppc64le-port.md section 5.3): never written by generated code,
    // saved and restored around every call that could go through a linker
    // stub. The explicit restore makes this correct whatever the linker does
    // with the call site.
    // True while generating a call whose caller has already reserved the
    // 32-byte ELFv2 linkage area inside its own frame. Air does: see
    // computeCCallingConvention, which asks for 32 + 8 * doublewords. In that
    // case this must NOT move sp -- the argument stores have already been
    // emitted at their callArg offsets from the current sp, and pushing here
    // would put every one of them 32 bytes above where the callee looks.
    bool m_cCallLinkageAreaIsReserved { false };

    void emitCCallLinkageAreaSetup()
    {
        if (!m_cCallLinkageAreaIsReserved)
            m_assembler.addi(PPC64Registers::r1, PPC64Registers::r1, -32);
        // 0(r1) is the ELFv2 BACK CHAIN, and this stores the JS call frame
        // pointer into it rather than the previous r1. That is deliberate,
        // and it is what makes DECLARE_CALL_FRAME work on this target.
        //
        // JSC operations recover their CallFrame* with
        //   DECLARE_CALL_FRAME(vm) == __builtin_frame_address(1)
        // (interpreter/CallFrame.h). That identity holds on x86_64 and ARM64
        // only because JSC deliberately makes callFrameRegister the SAME
        // register the C compiler uses as a frame pointer -- rbp and x29. On
        // PowerPC there is no such coincidence available: the C frame chain
        // runs through r1's back chain, while cfr is r31. An operation
        // reading __builtin_frame_address(1) here gets the JIT's stack
        // pointer, not its call frame, and then reads garbage out of
        // [cfr + CodeBlock].
        //
        // Planting cfr in the back-chain slot bridges the two: the callee's
        // own prologue makes __builtin_frame_address(1) our r1, and one more
        // dereference -- the back chain -- yields cfr. It is also a coherent
        // chain to walk, because JSC's [cfr + 0] is CallerFrame, which is the
        // back-chain convention already.
        //
        // The other half of this lives in the CPU(PPC64LE) arm of
        // DECLARE_CALL_FRAME; neither half is correct without the other.
        m_assembler.std(framePointerRegister, PPC64Registers::r1, 0);
        m_assembler.std(PPC64Registers::r2, PPC64Registers::r1, 24);
    }

    void emitCCallLinkageAreaTeardown()
    {
        m_assembler.ld(PPC64Registers::r2, PPC64Registers::r1, 24);
        if (!m_cCallLinkageAreaIsReserved)
            m_assembler.addi(PPC64Registers::r1, PPC64Registers::r1, 32);
    }

    // call(), for a caller whose frame already holds the linkage area. The
    // back chain and the TOC slot are still written -- they are what make
    // DECLARE_CALL_FRAME work here -- but in place, at 0(r1) and 24(r1) of the
    // frame the caller already sized for them.
    template<typename... Args>
    Call callWithReservedLinkageArea(Args&&... args)
    {
        bool saved = m_cCallLinkageAreaIsReserved;
        m_cCallLinkageAreaIsReserved = true;
        Call result = call(std::forward<Args>(args)...);
        m_cCallLinkageAreaIsReserved = saved;
        return result;
    }

    Jump jump()
    {
        auto label = m_assembler.label();
        m_assembler.insn(Assembler::nopInsn());
        m_assembler.insn(Assembler::unlinkedBranchInsn(false));
        return Jump(label);
    }

    // farJump is a tail transfer: no return address, so no linkage area is
    // needed even when the target is C code (ThunkGenerators does that once,
    // for operationCompareStringEq). The callee will write its return
    // address into 16(r1) of whatever frame is current, which for a tail
    // jump is the frame our own caller already provided.
    void emitIndirectJump(RegisterID target)
    {
        m_assembler.mtctr(target);
        m_assembler.bctr();
    }

    // A TAIL call into a C function has the same ELFv2 entry requirement as a
    // call: the callee's global entry point computes its own TOC from r12, so
    // r12 must hold the entry address. emitIndirectCall says this for the call
    // case; farJump used to discard the tag and emit a bare mtctr/bctr, so a
    // tail call into a C operation entered with a stale r12 and the callee
    // derived a garbage r2 from it. Nothing faults at the jump: intra-module
    // code in this binary needs no TOC, so the wrong r2 survives until the
    // first PLT-routed libc call inside the operation. It surfaced as a
    // SIGSEGV in __plt_malloc under JSRopeString::resolveRope, reached from
    // the DFG's stringEqualThunkGenerator slow path, which tail-calls
    // operationCompareStringEq.
    //
    // No linkage area is set up here, and none is wanted: a tail call reuses
    // the caller's frame and the callee returns past us to the original
    // caller.
    //
    // callTargetIsNativeCode() cannot be reused: it RELEASE_ASSERTs on tags
    // outside FOR_EACH_JSC_PTRTAG, and farJump is reached with NoPtrTag among
    // others. The two tags that mean "a C function" are named explicitly.
    //
    // This predicate USED TO BE AN OVER-APPROXIMATION and is not any more.
    // OperationPtrTag once covered both C operations and the LLInt and IPInt
    // entry points, which are native code entered from generated code but are
    // not C functions and do not obey the platform ABI. The entry thunks now
    // carry LLIntEntryPtrTag, a tag in OperationPtrTag's own category added
    // for exactly this distinction (runtime/JSCPtrTag.h). Everything this
    // function gates -- the r12 the ELFv2 global entry needs, and the back
    // chain the callee reads as its CallFrame* -- is now asked of a target
    // that genuinely wants it, and of no other.
    //
    // The list below is hand-written because the distinction it draws does
    // not exist in the category table: OperationPtrTag and LLIntEntryPtrTag
    // are deliberately the SAME (Native callee, JIT caller) pair, since on
    // every other architecture they are the same thing. So the list is made
    // checkable instead of trusted: a new tag landing in that category fails
    // this build until somebody decides which side of the ABI it is on.
    static constexpr bool jumpTargetIsNativeCode(PtrTag tag)
    {
        return tag == OperationPtrTag || tag == CFunctionPtrTag;
    }

#define JSC_PPC64_CLASSIFY_NATIVE_CALLEE_JIT_CALLER_TAG(name, calleeTypeValue, callerTypeValue) \
    static_assert((calleeTypeValue) != PtrTagCalleeType::Native \
        || (callerTypeValue) != PtrTagCallerType::JIT \
        || JSC::name == JSC::OperationPtrTag || JSC::name == JSC::LLIntEntryPtrTag, \
        "A new (Native callee, JIT caller) PtrTag exists. PPC64LE has to know whether its " \
        "target is a C function -- which needs r12 at its global entry and reads cfr out of " \
        "the back chain at 0(r1) -- or generated code, which needs neither. Classify it in " \
        "jumpTargetIsNativeCode().");
    FOR_EACH_JSC_PTRTAG(JSC_PPC64_CLASSIFY_NATIVE_CALLEE_JIT_CALLER_TAG)
#undef JSC_PPC64_CLASSIFY_NATIVE_CALLEE_JIT_CALLER_TAG

    // THE TAIL-TRANSFER HALF OF THE LINKAGE AREA, and the history that
    // decides its shape.
    //
    // A C function entered from JSC-generated code finds its CallFrame* at
    // 0(incoming r1). That is this port's invariant, not ELFv2's: the back
    // chain would ordinarily hold the caller's r1, and
    // emitCCallLinkageAreaSetup plants cfr there instead so that
    // DECLARE_CALL_FRAME -- *(void**)__builtin_frame_address(1) on this
    // target -- yields the JS frame. A call has a producer. A TAIL JUMP into
    // a C function had none, so JITOperationPrologueCallFrameTracer wrote
    // whatever was last poked at 0(sp) into vm.topCallFrame, and every
    // consumer of that -- exception unwinding, StackVisitor behind
    // Error.stack, the sampling profiler -- read garbage. The store below is
    // that missing producer.
    //
    // It could not be written until the discriminator was right, and the
    // first attempt proved it the hard way. Planted for every
    // jumpTargetIsNativeCode() tag, it was an immediate SIGSEGV in
    // llint_program_prologue on `jsc -e "print(1+1)"`, with r1 == r31 at the
    // fault [MEASURED, twice, four months apart]. The reason is that
    // OperationPtrTag then covered two different callees. Preprocessed with
    // this build's flags, four native-tag farJump sites exist on this target:
    // LLIntThunks.cpp:95, :122 and :133, whose target is offlineasm LLInt and
    // IPInt code, and ThunkGenerators.cpp:743, whose target is
    // operationCompareStringEq. The first three are ENTRY thunks, entered
    // with r1 == cfr because the callee's frame is not pushed yet, so 0(r1)
    // is the live JS frame's CallerFrame slot and storing cfr there makes a
    // frame its own caller. LLInt entry points also have no global entry
    // point and never read r12: llint_program_prologue begins `mflr r0`, not
    // `addis r2,r12` [MEASURED, objdump]. Both halves of what this function
    // does were being asked of code that wanted neither.
    //
    // Those thunks now carry LLIntEntryPtrTag and this only fires for a
    // genuine C tail call. The precondition it needs is the one the design
    // left [CODE] and that is now checked: at such a site 0(r1)..31(r1) is
    // dead scratch owned by the current frame. It holds at the one site that
    // reaches here, because the stringEqual thunk pops back to its JIT
    // caller's sp before jumping and both tiers reserve the extent below
    // their locals -- JIT::frameRegisterCountFor adds
    // maxFrameExtentForSlowPathCallInRegisters to numCalleeLocals, and
    // Graph::frameRegisterCount takes the max of it and the parameter slots.
    // The callee's own prologue is what consumes that reservation, and it is
    // visible in the shipped object: operationCompareStringEq opens
    // `stdu r1,-176(r1)` then `std r0,192(r1)`, which is its LR into 16 of
    // OUR frame, and then `ld r3,0(r31); ld r3,0(r3)`, which is
    // DECLARE_CALL_FRAME reading the word stored below [MEASURED, objdump].
    // Thirty-two bytes is exactly the linkage area the callee assumes, and
    // maxFrameExtentForSlowPathCall = 32 is the only thing keeping it off a
    // DFG local.
    //
    // No sp adjustment: a tail jump reuses the caller's frame, which already
    // has those 32 bytes. No r2 save: r2 is invariant across the engine, the
    // callee re-derives it from r12 at its global entry, and it returns past
    // us to the original JIT caller with that value.
    //
    // testmasm's testPPC64TailCallBackChainSeam measures all three shapes
    // from one frame with the same reader.
    //
    // Designed in powerpc64le-handbook docs/jsc-ppc64le-tail-call-seam.md,
    // whose site census and precondition are corrected by its erratum.
    void emitIndirectJump(RegisterID target, PtrTag tag)
    {
        if (jumpTargetIsNativeCode(tag)) {
            // The tail-transfer half of emitCCallLinkageAreaSetup: the same
            // word, in the same place, for the same reader.
            m_assembler.std(framePointerRegister, PPC64Registers::r1, 0);
            if (target != PPC64Registers::r12) {
                m_assembler.mr(PPC64Registers::r12, target);
                target = PPC64Registers::r12;
            }
        }
        emitIndirectJump(target);
    }

    void farJump(RegisterID target, PtrTag tag) { emitIndirectJump(target, tag); }

    void farJump(AbsoluteAddress address, PtrTag tag)
    {
        auto temp = temps<Data>();
        loadImmediate(TrustedImmPtr(address.m_ptr), temp.data());
        m_assembler.ld(temp.data(), temp.data(), 0);
        emitIndirectJump(temp.data(), tag);
    }

    void farJump(Address address, PtrTag tag)
    {
        auto temp = temps<Data>();
        load64(address, temp.data());
        emitIndirectJump(temp.data(), tag);
    }

    void farJump(BaseIndex address, PtrTag tag)
    {
        auto temp = temps<Data>();
        load64(address, temp.data());
        emitIndirectJump(temp.data(), tag);
    }

    void farJump(TrustedImmPtr imm, PtrTag tag)
    {
        auto temp = temps<Data>();
        loadImmediate(imm, temp.data());
        emitIndirectJump(temp.data(), tag);
    }

    // The dynamic-tag overloads exist for ARM64E's pointer authentication.
    // There is nothing to authenticate here, so the tag is ignored -- but it
    // is ignored explicitly, not by falling into the PtrTag overload with
    // some default.
    void farJump(RegisterID target, RegisterID) { emitIndirectJump(target); }
    void farJump(AbsoluteAddress address, RegisterID) { farJump(address, NoPtrTag); }
    void farJump(Address address, RegisterID) { farJump(address, NoPtrTag); }
    void farJump(BaseIndex address, RegisterID) { farJump(address, NoPtrTag); }

    // nearCall and nearTailCall target generated code by construction --
    // they take no tag and JSC only links them to thunks and JIT code -- so
    // they never carry a linkage area.
    Call nearCall()
    {
        auto label = m_assembler.label();
        m_assembler.insn(Assembler::nopInsn());
        m_assembler.insn(Assembler::unlinkedBranchInsn(true));
        return Call(label, Call::LinkableNear);
    }

    Call nearTailCall()
    {
        auto label = m_assembler.label();
        m_assembler.insn(Assembler::nopInsn());
        m_assembler.insn(Assembler::unlinkedBranchInsn(false));
        return Call(label, Call::LinkableNearTail);
    }

    Call threadSafePatchableNearCall()
    {
        // Relinking rewrites only the second word, and a single aligned
        // 32-bit store is atomic with respect to a concurrently executing
        // thread, so this needs no separate padding or fence discipline
        // beyond the icache flush relinkCall already does.
        return nearCall();
    }

    Call threadSafePatchableNearTailCall() { return nearTailCall(); }

    void ret() { m_assembler.blr(); }

    // ---- the link register ----
    //
    // There is deliberately no `linkRegister` GPR constant: on PowerPC the
    // link register is an SPR reached through mflr/mtlr, and inventing a
    // GPRReg for it would let generic ARM64/RISCV64-shaped code compile into
    // something that reads the wrong register. Anything that needs the
    // return address goes through one of these instead, and the call sites
    // in AssemblyHelpers and CCallHelpers name PPC64 explicitly.

    void moveFromLinkRegister(RegisterID dest) { m_assembler.mflr(dest); }
    void moveToLinkRegister(RegisterID src) { m_assembler.mtlr(src); }

    void loadToLinkRegister(Address address)
    {
        auto temp = temps<Data>();
        load64(address, temp.data());
        m_assembler.mtlr(temp.data());
    }

    // The JS frame prologue/epilogue pair. This must produce exactly the
    // frame the LLInt builds, because the two call each other:
    //   [cfr + 0] CallerFrame (the caller's cfr)
    //   [cfr + 8] ReturnPC
    // which is what offlineasm's `push cfr, lr` lowers to. r0 is the shuttle
    // for the link register -- not a pooled temporary, because the very
    // first instruction of a prologue runs before anything has been saved
    // and must not destroy a caller's register. That was defect 1 of the
    // LLInt bring-up.
    void pushFramePointerAndLinkRegister()
    {
        m_assembler.mflr(PPC64Registers::r0);
        m_assembler.addi(PPC64Registers::r1, PPC64Registers::r1, -16);
        m_assembler.std(framePointerRegister, PPC64Registers::r1, 0);
        m_assembler.std(PPC64Registers::r0, PPC64Registers::r1, 8);
    }

    void popFramePointerAndLinkRegister()
    {
        m_assembler.ld(PPC64Registers::r0, PPC64Registers::r1, 8);
        m_assembler.ld(framePointerRegister, PPC64Registers::r1, 0);
        m_assembler.mtlr(PPC64Registers::r0);
        m_assembler.addi(PPC64Registers::r1, PPC64Registers::r1, 16);
    }
    // ==================================================================
    // Comparisons.
    //
    // On PowerPC the signedness of a comparison is a property of the COMPARE
    // instruction, not of the branch: cmpw/cmpd are signed, cmplw/cmpld
    // unsigned, and both set the same LT/GT/EQ bits. So every one of these
    // returns a CRTest saying which CR0 bit the caller should look at and in
    // which sense, and the caller turns that into either a branch or a 0/1
    // value. Nothing may be emitted between the compare and its use, because
    // CR0 is scratch.
    //
    // The 32-bit compares need no extension of their operands: cmpw and
    // cmplw read only bits 32:63.
    // ==================================================================

    static bool isUnsigned(RelationalCondition cond)
    {
        return Assembler::isUnsignedCondition(static_cast<Assembler::Condition>(cond));
    }

    CRTest emitCompare32(RelationalCondition cond, RegisterID left, RegisterID right)
    {
        if (isUnsigned(cond))
            m_assembler.cmplw(CRField::CR0, left, right);
        else
            m_assembler.cmpw(CRField::CR0, left, right);
        return crTestFor(cond);
    }

    CRTest emitCompare32(RelationalCondition cond, RegisterID left, TrustedImm32 imm)
    {
        if (isUnsigned(cond)) {
            uint32_t value = static_cast<uint32_t>(imm.m_value);
            if (value <= 0xffff) {
                m_assembler.cmplwi(CRField::CR0, left, value);
                return crTestFor(cond);
            }
        } else if (Assembler::isValidSigned16(imm.m_value)) {
            m_assembler.cmpwi(CRField::CR0, left, imm.m_value);
            return crTestFor(cond);
        }
        auto temp = temps<Data>();
        loadImmediate(imm, temp.data());
        return emitCompare32(cond, left, temp.data());
    }

    CRTest emitCompare64(RelationalCondition cond, RegisterID left, RegisterID right)
    {
        if (isUnsigned(cond))
            m_assembler.cmpld(CRField::CR0, left, right);
        else
            m_assembler.cmpd(CRField::CR0, left, right);
        return crTestFor(cond);
    }

    CRTest emitCompare64(RelationalCondition cond, RegisterID left, int64_t value)
    {
        if (isUnsigned(cond)) {
            if (value >= 0 && value <= 0xffff) {
                m_assembler.cmpldi(CRField::CR0, left, static_cast<uint32_t>(value));
                return crTestFor(cond);
            }
        } else if (Assembler::isValidSigned16(value)) {
            m_assembler.cmpdi(CRField::CR0, left, static_cast<int32_t>(value));
            return crTestFor(cond);
        }
        auto temp = temps<Data>();
        m_assembler.loadImmediate64(temp.data(), value);
        return emitCompare64(cond, left, temp.data());
    }

    // A TrustedImm32 compared against a 64-bit register means the
    // sign-extended value.
    CRTest emitCompare64(RelationalCondition cond, RegisterID left, TrustedImm32 imm)
    {
        return emitCompare64(cond, left, static_cast<int64_t>(imm.m_value));
    }

    // ---- ResultCondition: the state of a value that an operation produced ----

    static CRTest crTestForResult(ResultCondition cond)
    {
        switch (cond) {
        case Zero:           return { CRBit::EQ, true };
        case NonZero:        return { CRBit::EQ, false };
        case Signed:         return { CRBit::LT, true };
        case PositiveOrZero: return { CRBit::LT, false };
        case Overflow:
        case Carry:
            // These do not come from comparing a result against zero; the
            // arithmetic helpers below produce their own CRTest. Reaching
            // here means a caller asked for one on an operation that cannot
            // produce it.
            RELEASE_ASSERT_NOT_REACHED();
        }
        RELEASE_ASSERT_NOT_REACHED();
        return { CRBit::EQ, true };
    }

    CRTest emitTestResult32(ResultCondition cond, RegisterID value)
    {
        m_assembler.cmpwi(CRField::CR0, value, 0);
        return crTestForResult(cond);
    }

    CRTest emitTestResult64(ResultCondition cond, RegisterID value)
    {
        m_assembler.cmpdi(CRField::CR0, value, 0);
        return crTestForResult(cond);
    }

    // reg & mask, compared against zero. A mask of -1 means "the value
    // itself", which is the default JSC passes for a plain "is it zero".
    CRTest emitTest32(ResultCondition cond, RegisterID reg, TrustedImm32 mask)
    {
        if (mask.m_value == -1)
            return emitTestResult32(cond, reg);
        auto temp = temps<Data>();
        and32(mask, reg, temp.data());
        return emitTestResult32(cond, temp.data());
    }

    CRTest emitTest32(ResultCondition cond, RegisterID reg, RegisterID mask)
    {
        if (reg == mask)
            return emitTestResult32(cond, reg);
        auto temp = temps<Data>();
        m_assembler.and_(temp.data(), reg, mask);
        return emitTestResult32(cond, temp.data());
    }

    CRTest emitTest64(ResultCondition cond, RegisterID reg, TrustedImm32 mask)
    {
        if (mask.m_value == -1)
            return emitTestResult64(cond, reg);
        auto temp = temps<Data>();
        and64(mask, reg, temp.data());
        return emitTestResult64(cond, temp.data());
    }

    CRTest emitTest64(ResultCondition cond, RegisterID reg, TrustedImm64 mask)
    {
        if (mask.m_value == -1)
            return emitTestResult64(cond, reg);
        auto temp = temps<Data>();
        and64(mask, reg, temp.data());
        return emitTestResult64(cond, temp.data());
    }

    CRTest emitTest64(ResultCondition cond, RegisterID reg, RegisterID mask)
    {
        if (reg == mask)
            return emitTestResult64(cond, reg);
        auto temp = temps<Data>();
        m_assembler.and_(temp.data(), reg, mask);
        return emitTestResult64(cond, temp.data());
    }

    // ---- materialising a CR0 test as a 0/1 value ----
    //
    // mfocrf moves one CR field into a GPR; the field lands in the same bit
    // positions it occupies in the 32-bit CR, so CR0's LT/GT/EQ/SO are at
    // big-endian bit positions 0/1/2/3, i.e. little-endian 31/30/29/28. A
    // rotate of (bit + 1) brings the wanted one to bit 0 and the 31,31 mask
    // discards the rest. This is the same sequence offlineasm/ppc64.rb uses
    // for `setcr`.
    // `dest` is the staging register, not dataTempRegister. It can be, because
    // the CR field is not a GPR: by the time this runs the comparison that set
    // it has already read its operands for the last time, so nothing this
    // writes can still be wanted -- including when `dest` aliases one of them.
    //
    // It HAS to be, because Air generates under
    // DisallowMacroScratchRegisterUsage (AirGenerate.cpp:183,
    // AirAllocateRegistersAndStackAndGenerateCode.cpp:540), the allocator may
    // have handed r29 or r30 to a live Tmp, and this is the tail of every
    // compare32, compare64, test32, test64, compareDouble and compareFloat --
    // which is to say, of the two most common opcodes this target claims a
    // form for. Reaching for the temp here cost 12 of a 100-case testb3
    // failure sample.
    void emitSetFromCR0(CRTest test, RegisterID dest)
    {
        unsigned fieldIndex = static_cast<unsigned>(test.field);
        // FXM is a one-hot field selector in big-endian bit order, so CR0 is
        // 0x80 and CR7 is 0x01.
        m_assembler.mfocrf(dest, 0x80u >> fieldIndex);
        // mfocrf leaves the field in the bit positions it occupies in the
        // 32-bit CR, so the wanted bit is at big-endian position
        // fieldIndex * 4 + bit; rotating left by one more than that brings
        // it to bit 0.
        m_assembler.rlwinm(dest, dest, crBitIndex(test.field, test.bit) + 1, 31, 31);
        if (!test.branchIfSet)
            m_assembler.xori(dest, dest, 1);
    }

    void compare8(RelationalCondition cond, Address address, TrustedImm32 imm, RegisterID dest)
    {
        auto temp = temps<Memory>();
        load8(address, temp.memory());
        emitSetFromCR0(emitCompare32(cond, temp.memory(), imm), dest);
    }

    void compare32(RelationalCondition cond, RegisterID left, RegisterID right, RegisterID dest)
    {
        emitSetFromCR0(emitCompare32(cond, left, right), dest);
    }

    void compare32(RelationalCondition cond, RegisterID left, TrustedImm32 imm, RegisterID dest)
    {
        emitSetFromCR0(emitCompare32(cond, left, imm), dest);
    }

    void compare32(RelationalCondition cond, Address address, RegisterID right, RegisterID dest)
    {
        auto temp = temps<Memory>();
        load32(address, temp.memory());
        emitSetFromCR0(emitCompare32(cond, temp.memory(), right), dest);
    }

    void compare64(RelationalCondition cond, RegisterID left, RegisterID right, RegisterID dest)
    {
        emitSetFromCR0(emitCompare64(cond, left, right), dest);
    }

    void compare64(RelationalCondition cond, RegisterID left, TrustedImm32 imm, RegisterID dest)
    {
        emitSetFromCR0(emitCompare64(cond, left, imm), dest);
    }

    void compare64(RelationalCondition cond, RegisterID left, TrustedImm64 imm, RegisterID dest)
    {
        emitSetFromCR0(emitCompare64(cond, left, imm.m_value), dest);
    }

    void test8(ResultCondition cond, Address address, TrustedImm32 mask, RegisterID dest)
    {
        auto temp = temps<Memory>();
        load8(address, temp.memory());
        emitSetFromCR0(emitTest32(cond, temp.memory(), TrustedImm32(mask.m_value & 0xff)), dest);
    }

    void test32(ResultCondition cond, RegisterID reg, RegisterID mask, RegisterID dest)
    {
        emitSetFromCR0(emitTest32(cond, reg, mask), dest);
    }

    void test32(ResultCondition cond, RegisterID reg, TrustedImm32 mask, RegisterID dest)
    {
        emitSetFromCR0(emitTest32(cond, reg, mask), dest);
    }

    void test32(ResultCondition cond, Address address, TrustedImm32 mask, RegisterID dest)
    {
        auto temp = temps<Memory>();
        load32(address, temp.memory());
        emitSetFromCR0(emitTest32(cond, temp.memory(), mask), dest);
    }

    void test64(ResultCondition cond, RegisterID reg, RegisterID mask, RegisterID dest)
    {
        emitSetFromCR0(emitTest64(cond, reg, mask), dest);
    }

    void test64(ResultCondition cond, RegisterID reg, TrustedImm32 mask, RegisterID dest)
    {
        emitSetFromCR0(emitTest64(cond, reg, mask), dest);
    }

    // setCarry has one caller in the whole tree, B3CheckSpecial.cpp:201 and
    // :224, which undoes a BranchAdd32/64 that the register allocator has
    // coalesced into an add-to-self. It reads a carry flag that this target
    // does not have: every overflow and carry test here is synthesised as a
    // comparison into a CR field rather than read out of XER, and the CR field
    // live on that late path holds the OVERFLOW verdict, because
    // B3LowerToAir.cpp:6353 always builds the check with
    // Arg::resCond(MacroAssembler::Overflow). Reading it would hand back the
    // wrong bit, silently.
    //
    // Declared with its real signature rather than the variadic accept-anything
    // stub RISCV64 uses, so that only this exact call compiles and every other
    // spelling stays a compile error. Loud at run time, never wrong.
    NO_RETURN_DUE_TO_CRASH void setCarry(RegisterID)
    {
        UNREACHABLE_FOR_PLATFORM();
    }
    enum class VectorCompareKind : uint8_t { Equal, GreaterSigned, GreaterUnsigned };

    void emitVectorCompareVMX(VectorCompareKind kind, SIMDLane lane, VRegisterID t, VRegisterID a, VRegisterID b)
    {
        switch (kind) {
        case VectorCompareKind::Equal:
            switch (lane) {
            case SIMDLane::i8x16: m_assembler.vcmpequb(t, a, b); return;
            case SIMDLane::i16x8: m_assembler.vcmpequh(t, a, b); return;
            case SIMDLane::i32x4: m_assembler.vcmpequw(t, a, b); return;
            case SIMDLane::i64x2: m_assembler.vcmpequd(t, a, b); return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        case VectorCompareKind::GreaterSigned:
            switch (lane) {
            case SIMDLane::i8x16: m_assembler.vcmpgtsb(t, a, b); return;
            case SIMDLane::i16x8: m_assembler.vcmpgtsh(t, a, b); return;
            case SIMDLane::i32x4: m_assembler.vcmpgtsw(t, a, b); return;
            case SIMDLane::i64x2: m_assembler.vcmpgtsd(t, a, b); return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        case VectorCompareKind::GreaterUnsigned:
            switch (lane) {
            case SIMDLane::i8x16: m_assembler.vcmpgtub(t, a, b); return;
            case SIMDLane::i16x8: m_assembler.vcmpgtuh(t, a, b); return;
            case SIMDLane::i32x4: m_assembler.vcmpgtuw(t, a, b); return;
            case SIMDLane::i64x2: m_assembler.vcmpgtud(t, a, b); return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        }
        RELEASE_ASSERT_NOT_REACHED();
    }

    // The bridge, in one place. Every VMX-form vector operation goes through
    // one of these two, so the four-instruction cost documented at the bridge
    // declaration is paid in exactly two functions rather than a hundred.
    //
    // The emitted operation is handed VRegisterIDs and may use vectorBridge2
    // as scratch; it must not assume anything survives the call.
    template<typename EmitOp>
    void emitVMXUnary(FPRegisterID src, FPRegisterID dest, EmitOp emit)
    {
        m_assembler.xxlor(vectorBridge0VSR, src, src);
        emit(vectorBridge0, vectorBridge0);
        m_assembler.xxlor(dest, vectorBridge0VSR, vectorBridge0VSR);
    }

    template<typename EmitOp>
    void emitVMXBinary(FPRegisterID left, FPRegisterID right, FPRegisterID dest, EmitOp emit)
    {
        m_assembler.xxlor(vectorBridge0VSR, left, left);
        m_assembler.xxlor(vectorBridge1VSR, right, right);
        emit(vectorBridge0, vectorBridge0, vectorBridge1);
        m_assembler.xxlor(dest, vectorBridge0VSR, vectorBridge0VSR);
    }

    void emitVectorCompareGreater(SIMDInfo simdInfo, FPRegisterID a, FPRegisterID b, FPRegisterID dest)
    {
        if (simdInfo.lane == SIMDLane::f32x4)
            m_assembler.xvcmpgtsp(dest, a, b);
        else if (simdInfo.lane == SIMDLane::f64x2)
            m_assembler.xvcmpgtdp(dest, a, b);
        else
            RELEASE_ASSERT_NOT_REACHED();
    }

    void emitVectorIntegerMinMax(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest, bool isMin)
    {
        ASSERT(simdInfo.signMode != SIMDSignMode::None);
        bool isSigned = simdInfo.signMode == SIMDSignMode::Signed;
        emitVMXBinary(left, right, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            switch (simdInfo.lane) {
            case SIMDLane::i8x16:
                if (isMin) isSigned ? m_assembler.vminsb(t, a, b) : m_assembler.vminub(t, a, b);
                else isSigned ? m_assembler.vmaxsb(t, a, b) : m_assembler.vmaxub(t, a, b);
                return;
            case SIMDLane::i16x8:
                if (isMin) isSigned ? m_assembler.vminsh(t, a, b) : m_assembler.vminuh(t, a, b);
                else isSigned ? m_assembler.vmaxsh(t, a, b) : m_assembler.vmaxuh(t, a, b);
                return;
            case SIMDLane::i32x4:
                if (isMin) isSigned ? m_assembler.vminsw(t, a, b) : m_assembler.vminuw(t, a, b);
                else isSigned ? m_assembler.vmaxsw(t, a, b) : m_assembler.vmaxuw(t, a, b);
                return;
            case SIMDLane::i64x2:
                if (isMin) isSigned ? m_assembler.vminsd(t, a, b) : m_assembler.vminud(t, a, b);
                else isSigned ? m_assembler.vmaxsd(t, a, b) : m_assembler.vmaxud(t, a, b);
                return;
            default:
                RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    void emitVectorMinMax(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest, bool isMin)
    {
        bool isFloat = simdInfo.lane == SIMDLane::f32x4;
        RELEASE_ASSERT(isFloat || simdInfo.lane == SIMDLane::f64x2);

        // ok = (left == left) & (right == right): zero in any lane where
        // either operand is NaN, since NaN compares unequal to itself.
        if (isFloat) {
            m_assembler.xvcmpeqsp(fpTempRegister, left, left);
            m_assembler.xvcmpeqsp(fpTempRegister2, right, right);
        } else {
            m_assembler.xvcmpeqdp(fpTempRegister, left, left);
            m_assembler.xvcmpeqdp(fpTempRegister2, right, right);
        }
        m_assembler.xxland(fpTempRegister, fpTempRegister, fpTempRegister2);

        // left + right is a NaN in exactly the lanes where either was one.
        if (isFloat)
            m_assembler.xvaddsp(fpTempRegister2, left, right);
        else
            m_assembler.xvadddp(fpTempRegister2, left, right);

        // dest may alias left or right; both are dead after this point.
        if (isFloat)
            isMin ? m_assembler.xvminsp(dest, left, right) : m_assembler.xvmaxsp(dest, left, right);
        else
            isMin ? m_assembler.xvmindp(dest, left, right) : m_assembler.xvmaxdp(dest, left, right);

        // A set ok bit takes XB, the min/max; a clear one takes XA, the NaN.
        m_assembler.xxsel(dest, fpTempRegister2, dest, fpTempRegister);
    }

    void emitVectorExtend(SIMDInfo simdInfo, FPRegisterID input, FPRegisterID dest, bool high)
    {
        ASSERT(simdInfo.signMode != SIMDSignMode::None);
        bool isSigned = simdInfo.signMode == SIMDSignMode::Signed;
        emitVMXUnary(input, dest, [&](VRegisterID t, VRegisterID b) {
            if (isSigned) {
                switch (simdInfo.lane) { // the RESULT lane
                case SIMDLane::i16x8: high ? m_assembler.vupkhsb(t, b) : m_assembler.vupklsb(t, b); return;
                case SIMDLane::i32x4: high ? m_assembler.vupkhsh(t, b) : m_assembler.vupklsh(t, b); return;
                case SIMDLane::i64x2: high ? m_assembler.vupkhsw(t, b) : m_assembler.vupklsw(t, b); return;
                default: RELEASE_ASSERT_NOT_REACHED();
                }
            }
            // Zero-extension is a merge against zero: vmrgl* t, 0, b
            // interleaves 0 b0 0 b1 ... from the memory-low half.
            VRegisterID zero = vectorBridge2;
            m_assembler.vxor(zero, zero, zero);
            switch (simdInfo.lane) {
            case SIMDLane::i16x8: high ? m_assembler.vmrghb(t, zero, b) : m_assembler.vmrglb(t, zero, b); return;
            case SIMDLane::i32x4: high ? m_assembler.vmrghh(t, zero, b) : m_assembler.vmrglh(t, zero, b); return;
            case SIMDLane::i64x2: high ? m_assembler.vmrghw(t, zero, b) : m_assembler.vmrglw(t, zero, b); return;
            default: RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    // extmul: widen both operands as above, then multiply at the result
    // width. The i64x2 form has no 64-bit multiply on the POWER8 floor and
    // needs none: duplicating each wanted word (vmrg*w v, v, v) puts it in
    // the odd position the 32x32->64 odd-word multiply reads.
    void emitVectorExtendedMultiply(SIMDInfo simdInfo, FPRegisterID left, FPRegisterID right, FPRegisterID dest, bool high)
    {
        ASSERT(scalarTypeIsIntegral(simdInfo.lane));
        ASSERT(simdInfo.signMode != SIMDSignMode::None);
        bool isSigned = simdInfo.signMode == SIMDSignMode::Signed;
        emitVMXBinary(left, right, dest, [&](VRegisterID t, VRegisterID a, VRegisterID b) {
            VRegisterID zero = vectorBridge2;
            switch (simdInfo.lane) { // the RESULT lane
            case SIMDLane::i16x8:
                m_assembler.vxor(zero, zero, zero);
                if (isSigned) {
                    high ? m_assembler.vupkhsb(a, a) : m_assembler.vupklsb(a, a);
                    high ? m_assembler.vupkhsb(b, b) : m_assembler.vupklsb(b, b);
                } else {
                    high ? m_assembler.vmrghb(a, zero, a) : m_assembler.vmrglb(a, zero, a);
                    high ? m_assembler.vmrghb(b, zero, b) : m_assembler.vmrglb(b, zero, b);
                }
                // No plain halfword multiply exists; the multiply-add with a zero addend is one.
                m_assembler.vmladduhm(t, a, b, zero);
                return;
            case SIMDLane::i32x4:
                if (isSigned) {
                    high ? m_assembler.vupkhsh(a, a) : m_assembler.vupklsh(a, a);
                    high ? m_assembler.vupkhsh(b, b) : m_assembler.vupklsh(b, b);
                } else {
                    m_assembler.vxor(zero, zero, zero);
                    high ? m_assembler.vmrghh(a, zero, a) : m_assembler.vmrglh(a, zero, a);
                    high ? m_assembler.vmrghh(b, zero, b) : m_assembler.vmrglh(b, zero, b);
                }
                m_assembler.vmuluwm(t, a, b);
                return;
            case SIMDLane::i64x2:
                high ? m_assembler.vmrghw(a, a, a) : m_assembler.vmrglw(a, a, a);
                high ? m_assembler.vmrghw(b, b, b) : m_assembler.vmrglw(b, b, b);
                isSigned ? m_assembler.vmulosw(t, a, b) : m_assembler.vmulouw(t, a, b);
                return;
            default:
                RELEASE_ASSERT_NOT_REACHED();
            }
        });
    }

    // After a doubleword-to-word conversion into vectorBridge0: one word per
    // doubleword into memory lanes 0 and 1, zero into lanes 2 and 3.
    void emitVectorPackDoublewordsToLowWords(FPRegisterID dest)
    {
        m_assembler.vxor(vectorBridge2, vectorBridge2, vectorBridge2);
        // VRA's words land in the memory-high half: the zero there, the results below.
        m_assembler.vpkudum(vectorBridge0, vectorBridge2, vectorBridge0);
        m_assembler.xxlor(dest, vectorBridge0VSR, vectorBridge0VSR);
    }

    // dest = (negateProduct ? -mul1 : mul1) * mul2 + addend, one rounding.
    // xvmadda* accumulates into XT, so the addend has to start in the
    // register that becomes the result; dest can be that register only if no
    // multiplicand still to be read lives there.
    void emitVectorFusedMultiplyAdd(SIMDInfo simdInfo, FPRegisterID mul1, FPRegisterID mul2, FPRegisterID addend, FPRegisterID dest, bool negateProduct)
    {
        bool isFloat = simdInfo.lane == SIMDLane::f32x4;
        RELEASE_ASSERT(isFloat || simdInfo.lane == SIMDLane::f64x2);
        FPRegisterID a = mul1;
        if (negateProduct) {
            isFloat ? m_assembler.xvnegsp(fpTempRegister, mul1) : m_assembler.xvnegdp(fpTempRegister, mul1);
            a = fpTempRegister;
        }
        auto multiplyAddInto = [&](FPRegisterID accumulator) {
            isFloat ? m_assembler.xvmaddasp(accumulator, a, mul2) : m_assembler.xvmaddadp(accumulator, a, mul2);
        };
        if (dest == addend) {
            multiplyAddInto(dest);
            return;
        }
        bool destIsMultiplicand = dest == mul2 || (dest == mul1 && !negateProduct);
        if (!destIsMultiplicand) {
            moveVector(addend, dest);
            multiplyAddInto(dest);
            return;
        }
        moveVector(addend, fpTempRegister2);
        multiplyAddInto(fpTempRegister2);
        moveVector(fpTempRegister2, dest);
    }

    // Memory doubleword d (0 = bytes 0-7, 1 = bytes 8-15) into a GPR.
    // mfvsrd reads ISA doubleword 0, which IS memory doubleword 1, so only
    // memory doubleword 0 needs the swap.
    void emitVectorDoublewordToGPR(FPRegisterID src, unsigned memoryDoubleword, RegisterID dest)
    {
        if (memoryDoubleword) {
            m_assembler.mfvsrd(dest, src);
            return;
        }
        m_assembler.xxpermdi(fpTempRegister2, src, src, 3);
        m_assembler.mfvsrd(dest, fpTempRegister2);
    }

    // Put the ISA doubleword 0 of `value` into memory doubleword d of `dest`,
    // keeping dest's other half.
    void emitVectorMergeDoubleword(FPRegisterID dest, FPRegisterID value, unsigned memoryDoubleword)
    {
        if (memoryDoubleword)
            m_assembler.xxpermdi(dest, value, dest, 1);
        else
            m_assembler.xxpermdi(dest, dest, value, 0);
    }

    // The ISA30/POWER8 seam for 128-bit memory access. RA is r0, which reads
    // as the literal zero in the base position, so the folded address
    // register is the X-form index.
    void emitLoadVector(FPRegisterID dest, RegisterID addressRegister)
    {
        if (Assembler::hasISA30()) {
            m_assembler.lxvx(dest, PPC64Registers::r0, addressRegister);
            return;
        }
        m_assembler.lxvd2x(dest, PPC64Registers::r0, addressRegister);
        m_assembler.xxswapd(dest, dest);
    }

    void emitStoreVector(FPRegisterID src, RegisterID addressRegister)
    {
        if (Assembler::hasISA30()) {
            m_assembler.stxvx(src, PPC64Registers::r0, addressRegister);
            return;
        }
        // src must not be clobbered, so the swap goes through the FP temp.
        m_assembler.xxswapd(fpTempRegister, src);
        m_assembler.stxvd2x(fpTempRegister, PPC64Registers::r0, addressRegister);
    }

    // ==================================================================
    // Branches.
    //
    // A conditional branch is the two-word site described in
    // PPC64Assembler.h: the guard word tests the INVERTED condition and
    // skips the second word, which is the `b` that link time points at the
    // target. Two words, always, whether the target turns out near or far.
    //
    // Everything below funnels through makeBranch, so there is exactly one
    // place where a condition becomes machine code.
    // ==================================================================

    Jump makeBranch(CRTest test)
    {
        auto label = m_assembler.label();
        // Guard: branch over the following word when the condition does NOT
        // hold, hence BOFalse for a branch-if-set test and vice versa.
        m_assembler.insn(Assembler::conditionalGuardInsn(
            test.branchIfSet ? Assembler::BOFalse : Assembler::BOTrue,
            crBitIndex(test.field, test.bit)));
        m_assembler.insn(Assembler::unlinkedBranchInsn(false));
        return Jump(label);
    }

    Jump branch8(RelationalCondition cond, Address address, TrustedImm32 imm)
    {
        auto temp = temps<Memory>();
        load8(address, temp.memory());
        return makeBranch(emitCompare32(cond, temp.memory(), TrustedImm32(imm.m_value & 0xff)));
    }

    Jump branch8(RelationalCondition cond, AbsoluteAddress address, TrustedImm32 imm)
    {
        auto temp = temps<Memory>();
        load8(address.m_ptr, temp.memory());
        return makeBranch(emitCompare32(cond, temp.memory(), TrustedImm32(imm.m_value & 0xff)));
    }

    Jump branch16(RelationalCondition cond, Address address, TrustedImm32 imm)
    {
        auto temp = temps<Memory>();
        load16(address, temp.memory());
        return makeBranch(emitCompare32(cond, temp.memory(), TrustedImm32(imm.m_value & 0xffff)));
    }

    Jump branch16(RelationalCondition cond, AbsoluteAddress address, TrustedImm32 imm)
    {
        auto temp = temps<Memory>();
        load16(address.m_ptr, temp.memory());
        return makeBranch(emitCompare32(cond, temp.memory(), TrustedImm32(imm.m_value & 0xffff)));
    }

    Jump branch32(RelationalCondition cond, RegisterID left, RegisterID right)
    {
        return makeBranch(emitCompare32(cond, left, right));
    }

    Jump branch32(RelationalCondition cond, RegisterID left, TrustedImm32 imm)
    {
        return makeBranch(emitCompare32(cond, left, imm));
    }

    Jump branch32(RelationalCondition cond, RegisterID left, Address address)
    {
        auto temp = temps<Memory>();
        load32(address, temp.memory());
        return makeBranch(emitCompare32(cond, left, temp.memory()));
    }

    Jump branch32(RelationalCondition cond, Address address, RegisterID right)
    {
        auto temp = temps<Memory>();
        load32(address, temp.memory());
        return makeBranch(emitCompare32(cond, temp.memory(), right));
    }

    Jump branch32(RelationalCondition cond, Address address, TrustedImm32 imm)
    {
        auto temp = temps<Memory>();
        load32(address, temp.memory());
        return makeBranch(emitCompare32(cond, temp.memory(), imm));
    }

    Jump branch32(RelationalCondition cond, AbsoluteAddress address, RegisterID right)
    {
        auto temp = temps<Memory>();
        load32(address.m_ptr, temp.memory());
        return makeBranch(emitCompare32(cond, temp.memory(), right));
    }

    Jump branch32(RelationalCondition cond, BaseIndex address, TrustedImm32 imm)
    {
        auto temp = temps<Memory>();
        load32(address, temp.memory());
        return makeBranch(emitCompare32(cond, temp.memory(), imm));
    }

    // POWER8+ loads unaligned words in hardware, so this is just branch32.
    Jump branch32WithUnalignedHalfWords(RelationalCondition cond, BaseIndex address, TrustedImm32 imm)
    {
        return branch32(cond, address, imm);
    }

    Jump branch32WithMemory16(RelationalCondition cond, Address address, RegisterID right)
    {
        auto temp = temps<Memory>();
        load16(address, temp.memory());
        return makeBranch(emitCompare32(cond, temp.memory(), right));
    }

    Jump branch64(RelationalCondition cond, RegisterID left, RegisterID right)
    {
        return makeBranch(emitCompare64(cond, left, right));
    }

    Jump branch64(RelationalCondition cond, RegisterID left, TrustedImm32 imm)
    {
        return makeBranch(emitCompare64(cond, left, imm));
    }

    Jump branch64(RelationalCondition cond, RegisterID left, TrustedImm64 imm)
    {
        return makeBranch(emitCompare64(cond, left, imm.m_value));
    }

    Jump branch64(RelationalCondition cond, RegisterID left, Imm64 imm)
    {
        return branch64(cond, left, imm.asTrustedImm64());
    }

    Jump branch64(RelationalCondition cond, RegisterID left, Address address)
    {
        auto temp = temps<Memory>();
        load64(address, temp.memory());
        return makeBranch(emitCompare64(cond, left, temp.memory()));
    }

    Jump branch64(RelationalCondition cond, RegisterID left, AbsoluteAddress address)
    {
        auto temp = temps<Memory>();
        load64(address.m_ptr, temp.memory());
        return makeBranch(emitCompare64(cond, left, temp.memory()));
    }

    Jump branch64(RelationalCondition cond, Address address, RegisterID right)
    {
        auto temp = temps<Memory>();
        load64(address, temp.memory());
        return makeBranch(emitCompare64(cond, temp.memory(), right));
    }

    Jump branch64(RelationalCondition cond, Address address, TrustedImm32 imm)
    {
        auto temp = temps<Memory>();
        load64(address, temp.memory());
        return makeBranch(emitCompare64(cond, temp.memory(), imm));
    }

    Jump branch64(RelationalCondition cond, Address address, TrustedImm64 imm)
    {
        auto temp = temps<Memory>();
        load64(address, temp.memory());
        return makeBranch(emitCompare64(cond, temp.memory(), imm.m_value));
    }

    Jump branch64(RelationalCondition cond, AbsoluteAddress address, RegisterID right)
    {
        auto temp = temps<Memory>();
        load64(address.m_ptr, temp.memory());
        return makeBranch(emitCompare64(cond, temp.memory(), right));
    }

    Jump branch64(RelationalCondition cond, AbsoluteAddress address, TrustedImm32 imm)
    {
        auto temp = temps<Memory>();
        load64(address.m_ptr, temp.memory());
        return makeBranch(emitCompare64(cond, temp.memory(), imm));
    }

    Jump branch64(RelationalCondition cond, AbsoluteAddress address, TrustedImm64 imm)
    {
        auto temp = temps<Memory>();
        load64(address.m_ptr, temp.memory());
        return makeBranch(emitCompare64(cond, temp.memory(), imm.m_value));
    }

    Jump branch64(RelationalCondition cond, BaseIndex address, RegisterID right)
    {
        auto temp = temps<Memory>();
        load64(address, temp.memory());
        return makeBranch(emitCompare64(cond, temp.memory(), right));
    }

    // Both operands in memory: this is the one case that needs both temps at
    // once, which is exactly why there are two.
    Jump branch64(RelationalCondition cond, Address left, Address right)
    {
        auto temp = temps<Data, Memory>();
        load64(left, temp.data());
        load64(right, temp.memory());
        return makeBranch(emitCompare64(cond, temp.data(), temp.memory()));
    }
    // ==================================================================
    // Arithmetic that branches on overflow or carry.
    //
    // None of this touches XER. Reading XER back into a CR field needs
    // mcrxrx, which is ISA 3.0 (POWER9-only), and the LuaJIT ppc64le port's
    // correction ledger records XER manipulation as both slow and easy to
    // get subtly wrong. Every test below is a comparison instead, which is
    // POWER8-clean and can be reasoned about directly:
    //
    //   32-bit overflow: do the arithmetic EXACTLY in 64 bits on
    //     sign-extended operands, then ask whether the 64-bit result still
    //     equals the sign-extension of its own low word. This is the idiom
    //     V8 and SpiderMonkey use on this target.
    //   64-bit add overflow: the sign test ((r^a) & (r^b)) < 0.
    //   64-bit sub overflow: ((a^b) & (a^r)) < 0.
    //   64-bit mul overflow: the high half must equal the sign-extension of
    //     the low half.
    //   carry (unsigned): the result of an add is smaller than an operand;
    //     the borrow of a subtract is a < b.
    //
    // Where a third scratch is needed, `dest` is used for it -- but only
    // after both source operands have been read for the last time, which is
    // why the instruction order in these helpers is not free to change.
    // ==================================================================

    // THE ALIASING CONTRACT OF THIS FAMILY, and why it needs stating.
    //
    // temps<>() hands every caller the same two physical registers and tracks
    // nothing, so it cannot tell an outer method that has staged a value into
    // memoryTempRegister from an inner one about to overwrite it. Every
    // immediate entry point below stages its operand exactly there --
    // `loadImmediate(imm, temp.memory())` and then passes temp.memory() as a
    // source -- so `b` routinely IS memoryTempRegister, and the Address form
    // of branchAdd32 does the same for `a`. A helper that writes a temp before
    // its last read of the operand that lives in it silently computes
    // something else. Two helpers did, and neither had a caller that could
    // reach it, which is exactly why nothing noticed.
    //
    // So: each helper reads every source operand before writing any temp that
    // could be that operand, and states which aliases it tolerates with a
    // RELEASE_ASSERT at emit time. The assertion is the list; there is no
    // hand-maintained table anywhere else, and a new entry point that stages
    // an operand somewhere new trips it instead of miscompiling.

    CRTest emitAdd32Overflow(RegisterID a, RegisterID b, RegisterID dest)
    {
        // b is read after the first write to dataTempRegister.
        RELEASE_ASSERT(b != dataTempRegister);
        auto temp = temps<Data, Memory>();
        m_assembler.extsw(temp.data(), a);
        m_assembler.extsw(temp.memory(), b);
        m_assembler.add(temp.data(), temp.data(), temp.memory());
        m_assembler.extsw(temp.memory(), temp.data());
        m_assembler.cmpd(CRField::CR0, temp.data(), temp.memory());
        m_assembler.clrldi(dest, temp.data(), 32);
        return { CRBit::EQ, false }; // differ => overflowed int32
    }

    CRTest emitAdd32OverflowImm(RegisterID src, int32_t value, RegisterID dest)
    {
        auto temp = temps<Data, Memory>();
        m_assembler.extsw(temp.data(), src);
        addImmediate64(temp.data(), static_cast<int64_t>(value), temp.data());
        m_assembler.extsw(temp.memory(), temp.data());
        m_assembler.cmpd(CRField::CR0, temp.data(), temp.memory());
        m_assembler.clrldi(dest, temp.data(), 32);
        return { CRBit::EQ, false };
    }

    CRTest emitAdd32Carry(RegisterID a, RegisterID b, RegisterID dest)
    {
        // a is read again after the add writes dataTempRegister. b may be
        // memoryTempRegister -- the immediate form always makes it so -- and
        // a may be too, from the Address form; both are read before anything
        // writes it.
        RELEASE_ASSERT(a != dataTempRegister);
        auto temp = temps<Data, Memory>();
        // The add goes FIRST because it is the only instruction that reads b,
        // and the clrldi below writes the register b may be living in. With
        // the two the other way round, branchAdd32(Carry, src, imm, dest)
        // computed src + zext32(src) and compared it against zext32(src):
        // a wrong value, not merely a wrong flag.
        m_assembler.add(temp.data(), a, b);
        m_assembler.clrldi(temp.memory(), a, 32);
        m_assembler.clrldi(temp.data(), temp.data(), 32);
        m_assembler.cmpld(CRField::CR0, temp.data(), temp.memory());
        m_assembler.mr(dest, temp.data());
        return { CRBit::LT, true }; // sum < addend => carried out
    }

    CRTest emitSub32Overflow(RegisterID a, RegisterID b, RegisterID dest)
    {
        // b is read after the first write to dataTempRegister.
        RELEASE_ASSERT(b != dataTempRegister);
        auto temp = temps<Data, Memory>();
        m_assembler.extsw(temp.data(), a);
        m_assembler.extsw(temp.memory(), b);
        m_assembler.subf(temp.data(), temp.memory(), temp.data());
        m_assembler.extsw(temp.memory(), temp.data());
        m_assembler.cmpd(CRField::CR0, temp.data(), temp.memory());
        m_assembler.clrldi(dest, temp.data(), 32);
        return { CRBit::EQ, false };
    }

    CRTest emitSub32Carry(RegisterID a, RegisterID b, RegisterID dest)
    {
        // Both operands are read a second time by the subf below, after both
        // temps have been written. That is safe for the alias that actually
        // occurs -- b == memoryTempRegister, from the immediate form -- but
        // only because the value it was overwritten with is zext32 of itself,
        // which is congruent mod 2^32 and the result is masked to 32 bits
        // anyway. It is not safe the other way round: a in memoryTempRegister
        // would be read back as zext32(b).
        RELEASE_ASSERT(a != memoryTempRegister && b != dataTempRegister);
        auto temp = temps<Data, Memory>();
        m_assembler.clrldi(temp.data(), a, 32);
        m_assembler.clrldi(temp.memory(), b, 32);
        m_assembler.cmpld(CRField::CR0, temp.data(), temp.memory());
        m_assembler.subf(dest, b, a);
        m_assembler.clrldi(dest, dest, 32);
        return { CRBit::LT, true }; // a < b => borrow
    }

    CRTest emitMul32Overflow(RegisterID a, RegisterID b, RegisterID dest)
    {
        // |a|, |b| < 2^31, so the exact product fits comfortably in 64 bits
        // and mulld cannot itself overflow.
        // b is read after the first write to dataTempRegister.
        RELEASE_ASSERT(b != dataTempRegister);
        auto temp = temps<Data, Memory>();
        m_assembler.extsw(temp.data(), a);
        m_assembler.extsw(temp.memory(), b);
        m_assembler.mulld(temp.data(), temp.data(), temp.memory());
        m_assembler.extsw(temp.memory(), temp.data());
        m_assembler.cmpd(CRField::CR0, temp.data(), temp.memory());
        m_assembler.clrldi(dest, temp.data(), 32);
        return { CRBit::EQ, false };
    }

    CRTest emitNeg32Overflow(RegisterID srcDest)
    {
        // The only int32 whose negation overflows is INT32_MIN.
        auto temp = temps<Data, Memory>();
        m_assembler.extsw(temp.data(), srcDest);
        m_assembler.neg(temp.data(), temp.data());
        m_assembler.extsw(temp.memory(), temp.data());
        m_assembler.cmpd(CRField::CR0, temp.data(), temp.memory());
        m_assembler.clrldi(srcDest, temp.data(), 32);
        return { CRBit::EQ, false };
    }

    CRTest emitAdd64Overflow(RegisterID a, RegisterID b, RegisterID dest)
    {
        // b may be memoryTempRegister, because branchAdd64(Overflow, src,
        // TrustedImm32, dest) stages it there; a may be dest, because
        // branchAdd64(cond, TrustedImm32, dest) passes dest as a. Both of
        // those are tolerated below and the order is what tolerates them.
        // a may not be either temp and b may not be dataTempRegister; no
        // entry point in this file does that.
        RELEASE_ASSERT(a != dataTempRegister && a != memoryTempRegister && b != dataTempRegister);
        auto temp = temps<Data, Memory>();
        m_assembler.add(temp.data(), a, b);              // r
        // r ^ b comes FIRST, and into memoryTempRegister, because this is the
        // last read of b and memoryTempRegister is where b may be living. The
        // other order -- r ^ a into the memory temp, then r ^ b -- read a b
        // that had just been overwritten with r ^ a, which collapses the
        // predicate ((r^a) & (r^b)) < 0 into ((r^a) & a) < 0. That misses
        // EVERY overflow of a positive immediate and invents overflows for a
        // negative a, and no random-input test can find it: with a 32-bit
        // immediate an overflow only exists when a is within 2^31 of a
        // boundary, so uniform operands produce no overflows to disagree
        // about at all.
        m_assembler.xor_(temp.memory(), temp.data(), b); // r ^ b -- last read of b
        m_assembler.xor_(dest, temp.data(), a);          // r ^ a -- last read of a
        m_assembler.and_(temp.memory(), temp.memory(), dest);
        m_assembler.cmpdi(CRField::CR0, temp.memory(), 0);
        m_assembler.mr(dest, temp.data());
        return { CRBit::LT, true };
    }

    CRTest emitSub64Overflow(RegisterID a, RegisterID b, RegisterID dest)
    {
        // b's last read is the xor that writes memoryTempRegister, in the same
        // instruction, so b may be that register -- which the immediate form
        // makes it. a is read up to the third instruction, which writes dest
        // in the same instruction, so a may be dest but neither temp.
        RELEASE_ASSERT(a != dataTempRegister && a != memoryTempRegister && b != dataTempRegister);
        auto temp = temps<Data, Memory>();
        m_assembler.subf(temp.data(), b, a);             // r = a - b
        m_assembler.xor_(temp.memory(), a, b);           // a ^ b
        m_assembler.xor_(dest, a, temp.data());          // a ^ r -- last read of a
        m_assembler.and_(temp.memory(), temp.memory(), dest);
        m_assembler.cmpdi(CRField::CR0, temp.memory(), 0);
        m_assembler.mr(dest, temp.data());
        return { CRBit::LT, true };
    }

    CRTest emitMul64Overflow(RegisterID a, RegisterID b, RegisterID dest)
    {
        // Both operands are read again by the mulld, after mulhd has written
        // dataTempRegister; the mulld writes memoryTempRegister in the same
        // instruction that reads them, so that one is fine.
        RELEASE_ASSERT(a != dataTempRegister && b != dataTempRegister);
        auto temp = temps<Data, Memory>();
        m_assembler.mulhd(temp.data(), a, b);
        m_assembler.mulld(temp.memory(), a, b);          // last read of a and b
        m_assembler.sradi(dest, temp.memory(), 63);      // sign-extension of the low half
        m_assembler.cmpd(CRField::CR0, temp.data(), dest);
        m_assembler.mr(dest, temp.memory());
        return { CRBit::EQ, false };
    }

    CRTest emitNeg64Overflow(RegisterID srcDest)
    {
        RegisterID scratch = immediateScratch(srcDest, srcDest);
        m_assembler.loadImmediate64(scratch, std::numeric_limits<int64_t>::min());
        m_assembler.cmpd(CRField::CR0, srcDest, scratch);
        m_assembler.neg(srcDest, srcDest);
        return { CRBit::EQ, true };
    }

    CRTest emitAdd64Carry(RegisterID a, RegisterID b, RegisterID dest)
    {
        // a is read again by the compare, after the add has written
        // dataTempRegister. b is read once, by the add itself, so b may be
        // either temp -- which is what makes the immediate form safe here and
        // not in emitAdd32Carry.
        RELEASE_ASSERT(a != dataTempRegister);
        auto temp = temps<Data>();
        m_assembler.add(temp.data(), a, b);
        m_assembler.cmpld(CRField::CR0, temp.data(), a);
        m_assembler.mr(dest, temp.data());
        return { CRBit::LT, true };
    }

    CRTest emitSub64Carry(RegisterID a, RegisterID b, RegisterID dest)
    {
        m_assembler.cmpld(CRField::CR0, a, b);
        m_assembler.subf(dest, b, a);
        return { CRBit::LT, true };
    }

    // ---- the branchXxx entry points ----

    Jump branchAdd32(ResultCondition cond, RegisterID a, RegisterID b, RegisterID dest)
    {
        if (cond == Overflow)
            return makeBranch(emitAdd32Overflow(a, b, dest));
        if (cond == Carry)
            return makeBranch(emitAdd32Carry(a, b, dest));
        add32(a, b, dest);
        return makeBranch(emitTestResult32(cond, dest));
    }

    Jump branchAdd32(ResultCondition cond, RegisterID src, RegisterID dest) { return branchAdd32(cond, src, dest, dest); }

    Jump branchAdd32(ResultCondition cond, RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        if (cond == Overflow)
            return makeBranch(emitAdd32OverflowImm(src, imm.m_value, dest));
        if (cond == Carry) {
            auto temp = temps<Memory>();
            loadImmediate(imm, temp.memory());
            return makeBranch(emitAdd32Carry(src, temp.memory(), dest));
        }
        add32(imm, src, dest);
        return makeBranch(emitTestResult32(cond, dest));
    }

    Jump branchAdd32(ResultCondition cond, TrustedImm32 imm, RegisterID dest) { return branchAdd32(cond, dest, imm, dest); }

    Jump branchAdd32(ResultCondition cond, Address address, RegisterID dest)
    {
        auto temp = temps<Memory>();
        load32(address, temp.memory());
        return branchAdd32(cond, temp.memory(), dest, dest);
    }

    // The memory-destination forms are the profiling counters. They need the
    // address to stay live across the arithmetic, and the overflow helpers
    // use both temps plus dest, so there is nowhere to keep it. JSC only ever
    // asks these for zero/sign conditions; anything else is refused loudly
    // rather than computed wrongly.
    Jump branchAdd32(ResultCondition cond, TrustedImm32 imm, Address address)
    {
        RELEASE_ASSERT(cond != Overflow && cond != Carry);
        auto temp = temps<Data>();
        load32(address, temp.data());
        addImmediate64(temp.data(), static_cast<int64_t>(imm.m_value), temp.data());
        m_assembler.clrldi(temp.data(), temp.data(), 32);
        store32(temp.data(), address);
        return makeBranch(emitTestResult32(cond, temp.data()));
    }

    Jump branchAdd32(ResultCondition cond, TrustedImm32 imm, AbsoluteAddress address)
    {
        RELEASE_ASSERT(cond != Overflow && cond != Carry);
        auto temp = temps<Data>();
        load32(address.m_ptr, temp.data());
        addImmediate64(temp.data(), static_cast<int64_t>(imm.m_value), temp.data());
        m_assembler.clrldi(temp.data(), temp.data(), 32);
        store32(temp.data(), address.m_ptr);
        return makeBranch(emitTestResult32(cond, temp.data()));
    }

    Jump branchAdd64(ResultCondition cond, RegisterID a, RegisterID b, RegisterID dest)
    {
        if (cond == Overflow)
            return makeBranch(emitAdd64Overflow(a, b, dest));
        if (cond == Carry)
            return makeBranch(emitAdd64Carry(a, b, dest));
        add64(a, b, dest);
        return makeBranch(emitTestResult64(cond, dest));
    }

    Jump branchAdd64(ResultCondition cond, RegisterID src, RegisterID dest) { return branchAdd64(cond, src, dest, dest); }

    Jump branchAdd64(ResultCondition cond, RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        if (cond == Overflow || cond == Carry) {
            auto temp = temps<Memory>();
            loadSignExtendedImmediate32(imm.m_value, temp.memory());
            return branchAdd64(cond, src, temp.memory(), dest);
        }
        add64(imm, src, dest);
        return makeBranch(emitTestResult64(cond, dest));
    }

    Jump branchAdd64(ResultCondition cond, TrustedImm32 imm, RegisterID dest) { return branchAdd64(cond, dest, imm, dest); }

    Jump branchSub32(ResultCondition cond, RegisterID a, RegisterID b, RegisterID dest)
    {
        if (cond == Overflow)
            return makeBranch(emitSub32Overflow(a, b, dest));
        if (cond == Carry)
            return makeBranch(emitSub32Carry(a, b, dest));
        sub32(a, b, dest);
        return makeBranch(emitTestResult32(cond, dest));
    }

    Jump branchSub32(ResultCondition cond, RegisterID src, RegisterID dest) { return branchSub32(cond, dest, src, dest); }

    Jump branchSub32(ResultCondition cond, RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        if (cond == Overflow || cond == Carry) {
            auto temp = temps<Memory>();
            loadImmediate(imm, temp.memory());
            return branchSub32(cond, src, temp.memory(), dest);
        }
        sub32(src, imm, dest);
        return makeBranch(emitTestResult32(cond, dest));
    }

    Jump branchSub32(ResultCondition cond, TrustedImm32 imm, RegisterID dest) { return branchSub32(cond, dest, imm, dest); }

    Jump branchSub64(ResultCondition cond, RegisterID a, RegisterID b, RegisterID dest)
    {
        if (cond == Overflow)
            return makeBranch(emitSub64Overflow(a, b, dest));
        if (cond == Carry)
            return makeBranch(emitSub64Carry(a, b, dest));
        sub64(a, b, dest);
        return makeBranch(emitTestResult64(cond, dest));
    }

    Jump branchSub64(ResultCondition cond, RegisterID src, RegisterID dest) { return branchSub64(cond, dest, src, dest); }

    Jump branchSub64(ResultCondition cond, RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        if (cond == Overflow || cond == Carry) {
            auto temp = temps<Memory>();
            loadSignExtendedImmediate32(imm.m_value, temp.memory());
            return branchSub64(cond, src, temp.memory(), dest);
        }
        sub64(src, imm, dest);
        return makeBranch(emitTestResult64(cond, dest));
    }

    Jump branchSub64(ResultCondition cond, TrustedImm32 imm, RegisterID dest) { return branchSub64(cond, dest, imm, dest); }

    Jump branchMul32(ResultCondition cond, RegisterID a, RegisterID b, RegisterID dest)
    {
        if (cond == Overflow)
            return makeBranch(emitMul32Overflow(a, b, dest));
        RELEASE_ASSERT(cond != Carry); // multiply has no carry-out
        mul32(a, b, dest);
        return makeBranch(emitTestResult32(cond, dest));
    }

    Jump branchMul32(ResultCondition cond, RegisterID src, RegisterID dest) { return branchMul32(cond, src, dest, dest); }

    Jump branchMul32(ResultCondition cond, RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        auto temp = temps<Memory>();
        loadImmediate(imm, temp.memory());
        return branchMul32(cond, src, temp.memory(), dest);
    }

    Jump branchMul32(ResultCondition cond, TrustedImm32 imm, RegisterID dest) { return branchMul32(cond, dest, imm, dest); }

    // Air's BranchMul64 form carries a Scratch operand, because ARM64's smulh
    // sequence needs a staging register the allocator has to provide. This
    // target does not: emitMul64Overflow stages in the data and memory temps,
    // which are reserved here and cost the allocator nothing. The operand is
    // accepted and ignored rather than used, which wastes one Tmp per
    // BranchMul64 and is deliberate -- using it would need the sequence
    // reordered around the possibility that Air handed us the same register as
    // dest, and that is an optimisation with no measurement behind it on an
    // opcode CheckMul reaches rarely.
    Jump branchMul64(ResultCondition cond, RegisterID a, RegisterID b, RegisterID, RegisterID dest)
    {
        return branchMul64(cond, a, b, dest);
    }

    Jump branchMul64(ResultCondition cond, RegisterID a, RegisterID b, RegisterID dest)
    {
        if (cond == Overflow)
            return makeBranch(emitMul64Overflow(a, b, dest));
        RELEASE_ASSERT(cond != Carry);
        mul64(a, b, dest);
        return makeBranch(emitTestResult64(cond, dest));
    }

    Jump branchMul64(ResultCondition cond, RegisterID src, RegisterID dest) { return branchMul64(cond, src, dest, dest); }

    Jump branchMul64(ResultCondition cond, RegisterID src, TrustedImm32 imm, RegisterID dest)
    {
        auto temp = temps<Memory>();
        loadSignExtendedImmediate32(imm.m_value, temp.memory());
        return branchMul64(cond, src, temp.memory(), dest);
    }

    Jump branchMul64(ResultCondition cond, TrustedImm32 imm, RegisterID dest) { return branchMul64(cond, dest, imm, dest); }

    Jump branchNeg32(ResultCondition cond, RegisterID srcDest)
    {
        if (cond == Overflow)
            return makeBranch(emitNeg32Overflow(srcDest));
        RELEASE_ASSERT(cond != Carry);
        neg32(srcDest);
        return makeBranch(emitTestResult32(cond, srcDest));
    }

    Jump branchNeg64(ResultCondition cond, RegisterID srcDest)
    {
        if (cond == Overflow)
            return makeBranch(emitNeg64Overflow(srcDest));
        RELEASE_ASSERT(cond != Carry);
        neg64(srcDest);
        return makeBranch(emitTestResult64(cond, srcDest));
    }
    // ---- branchTest: AND against a mask, then compare with zero ----
    //
    // The narrow forms mask the immediate down to the width first, so that
    // the default TrustedImm32(-1) means "all the bits of a byte" rather
    // than "all 32 bits" -- otherwise a loaded byte would be tested against
    // a mask with bits it can never have set.

    Jump branchTest8(ResultCondition cond, Address address, TrustedImm32 mask = TrustedImm32(-1))
    {
        auto temp = temps<Memory>();
        load8(address, temp.memory());
        return makeBranch(emitTest32(cond, temp.memory(), TrustedImm32(mask.m_value & 0xff)));
    }

    Jump branchTest8(ResultCondition cond, AbsoluteAddress address, TrustedImm32 mask = TrustedImm32(-1))
    {
        auto temp = temps<Memory>();
        load8(address.m_ptr, temp.memory());
        return makeBranch(emitTest32(cond, temp.memory(), TrustedImm32(mask.m_value & 0xff)));
    }

    Jump branchTest8(ResultCondition cond, BaseIndex address, TrustedImm32 mask = TrustedImm32(-1))
    {
        auto temp = temps<Memory>();
        load8(address, temp.memory());
        return makeBranch(emitTest32(cond, temp.memory(), TrustedImm32(mask.m_value & 0xff)));
    }

    Jump branchTest8(ResultCondition cond, ExtendedAddress address, TrustedImm32 mask = TrustedImm32(-1))
    {
        auto temp = temps<Memory>();
        auto resolution = resolveAddress(address, temp.memory(), false);
        m_assembler.lbz(temp.memory(), resolution.base, resolution.offset);
        return makeBranch(emitTest32(cond, temp.memory(), TrustedImm32(mask.m_value & 0xff)));
    }

    Jump branchTest16(ResultCondition cond, Address address, TrustedImm32 mask = TrustedImm32(-1))
    {
        auto temp = temps<Memory>();
        load16(address, temp.memory());
        return makeBranch(emitTest32(cond, temp.memory(), TrustedImm32(mask.m_value & 0xffff)));
    }

    Jump branchTest16(ResultCondition cond, BaseIndex address, TrustedImm32 mask = TrustedImm32(-1))
    {
        auto temp = temps<Memory>();
        load16(address, temp.memory());
        return makeBranch(emitTest32(cond, temp.memory(), TrustedImm32(mask.m_value & 0xffff)));
    }

    Jump branchTest32(ResultCondition cond, RegisterID reg, RegisterID mask)
    {
        return makeBranch(emitTest32(cond, reg, mask));
    }

    Jump branchTest32(ResultCondition cond, RegisterID reg, TrustedImm32 mask = TrustedImm32(-1))
    {
        return makeBranch(emitTest32(cond, reg, mask));
    }

    Jump branchTest32(ResultCondition cond, Address address, TrustedImm32 mask = TrustedImm32(-1))
    {
        auto temp = temps<Memory>();
        load32(address, temp.memory());
        return makeBranch(emitTest32(cond, temp.memory(), mask));
    }

    Jump branchTest32(ResultCondition cond, AbsoluteAddress address, TrustedImm32 mask = TrustedImm32(-1))
    {
        auto temp = temps<Memory>();
        load32(address.m_ptr, temp.memory());
        return makeBranch(emitTest32(cond, temp.memory(), mask));
    }

    Jump branchTest64(ResultCondition cond, RegisterID reg, RegisterID mask)
    {
        return makeBranch(emitTest64(cond, reg, mask));
    }

    // ---- bit tests ----
    //
    // x86's BT takes its bit index modulo the operand width; the variable
    // shifts below already mask the shift count to the same width through
    // maskedShiftCount(.., 31/63, ..), so that rule comes out of the existing
    // primitives and no new encoding is introduced. testmasm's
    // testBranchTestBit{32,64}{RegReg,RegImm,AddrImm} are upstream's and check
    // exactly (value >> (bit % width)) & 1.

    Jump branchTestBit32(ResultCondition cond, RegisterID reg, RegisterID bit)
    {
        auto temp = temps<Data, Memory>();
        urshift32(reg, bit, temp.memory());
        return branchTest32(cond, temp.memory(), TrustedImm32(1));
    }

    Jump branchTestBit32(ResultCondition cond, RegisterID reg, TrustedImm32 bit)
    {
        auto temp = temps<Data, Memory>();
        urshift32(reg, TrustedImm32(bit.m_value & 31), temp.memory());
        return branchTest32(cond, temp.memory(), TrustedImm32(1));
    }

    Jump branchTestBit32(ResultCondition cond, Address address, TrustedImm32 bit)
    {
        auto temp = temps<Data, Memory>();
        load32(address, temp.memory());
        urshift32(temp.memory(), TrustedImm32(bit.m_value & 31), temp.memory());
        return branchTest32(cond, temp.memory(), TrustedImm32(1));
    }

    Jump branchTestBit64(ResultCondition cond, RegisterID reg, RegisterID bit)
    {
        auto temp = temps<Data, Memory>();
        urshift64(reg, bit, temp.memory());
        return branchTest64(cond, temp.memory(), TrustedImm32(1));
    }

    Jump branchTestBit64(ResultCondition cond, RegisterID reg, TrustedImm32 bit)
    {
        auto temp = temps<Data, Memory>();
        urshift64(reg, TrustedImm32(bit.m_value & 63), temp.memory());
        return branchTest64(cond, temp.memory(), TrustedImm32(1));
    }

    Jump branchTestBit64(ResultCondition cond, Address address, TrustedImm32 bit)
    {
        auto temp = temps<Data, Memory>();
        load64(address, temp.memory());
        urshift64(temp.memory(), TrustedImm32(bit.m_value & 63), temp.memory());
        return branchTest64(cond, temp.memory(), TrustedImm32(1));
    }

    Jump branchTest64(ResultCondition cond, RegisterID reg, TrustedImm32 mask = TrustedImm32(-1))
    {
        return makeBranch(emitTest64(cond, reg, mask));
    }

    Jump branchTest64(ResultCondition cond, RegisterID reg, TrustedImm64 mask)
    {
        return makeBranch(emitTest64(cond, reg, mask));
    }

    Jump branchTest64(ResultCondition cond, Address address, RegisterID mask)
    {
        auto temp = temps<Memory>();
        load64(address, temp.memory());
        return makeBranch(emitTest64(cond, temp.memory(), mask));
    }

    Jump branchTest64(ResultCondition cond, Address address, TrustedImm32 mask = TrustedImm32(-1))
    {
        auto temp = temps<Memory>();
        load64(address, temp.memory());
        return makeBranch(emitTest64(cond, temp.memory(), mask));
    }

    Jump branchTest64(ResultCondition cond, AbsoluteAddress address, TrustedImm32 mask = TrustedImm32(-1))
    {
        auto temp = temps<Memory>();
        load64(address.m_ptr, temp.memory());
        return makeBranch(emitTest64(cond, temp.memory(), mask));
    }

    Jump branchTest64(ResultCondition cond, BaseIndex address, TrustedImm32 mask = TrustedImm32(-1))
    {
        auto temp = temps<Memory>();
        load64(address, temp.memory());
        return makeBranch(emitTest64(cond, temp.memory(), mask));
    }

    // The two branchPtr overloads MacroAssembler.h does not synthesise from
    // branch64.
    Jump branchPtr(RelationalCondition cond, BaseIndex address, RegisterID right)
    {
        return branch64(cond, address, right);
    }

    Jump branchPtr(RelationalCondition cond, Address left, Address right)
    {
        return branch64(cond, left, right);
    }
    // ==================================================================
    // Patchable constants.
    //
    // Every patchable constant is the FIXED five-word ladder
    // (lis/ori/rldicr/oris/ori), never the shortened one that
    // loadImmediate64 would pick, so that repatching a small value with a
    // large one does not need to move anything. writeFixedLoadImmediate64
    // and readFixedLoadImmediate64 are the only two functions allowed to
    // assume that layout.
    // ==================================================================

    DataLabelPtr moveWithPatch(TrustedImmPtr imm, RegisterID dest)
    {
        DataLabelPtr label(this);
        m_assembler.emitFixedLoadImmediate64(dest, reinterpret_cast<int64_t>(imm.m_value));
        return label;
    }

    DataLabel32 moveWithPatch(TrustedImm32 imm, RegisterID dest)
    {
        DataLabel32 label(this);
        m_assembler.emitFixedLoadImmediate64(dest, static_cast<int64_t>(imm.m_value));
        return label;
    }

    DataLabelPtr storePtrWithPatch(TrustedImmPtr imm, Address address)
    {
        auto temp = temps<Data>();
        DataLabelPtr label = moveWithPatch(imm, temp.data());
        store64(temp.data(), address);
        return label;
    }

    DataLabelPtr storePtrWithPatch(Address address) { return storePtrWithPatch(TrustedImmPtr(nullptr), address); }

    Jump branchPtrWithPatch(RelationalCondition cond, RegisterID left, DataLabelPtr& dataLabel, TrustedImmPtr initialRightValue = TrustedImmPtr(nullptr))
    {
        auto temp = temps<Data>();
        dataLabel = moveWithPatch(initialRightValue, temp.data());
        return makeBranch(emitCompare64(cond, left, temp.data()));
    }

    Jump branchPtrWithPatch(RelationalCondition cond, Address address, DataLabelPtr& dataLabel, TrustedImmPtr initialRightValue = TrustedImmPtr(nullptr))
    {
        auto temp = temps<Data, Memory>();
        load64(address, temp.memory());
        dataLabel = moveWithPatch(initialRightValue, temp.data());
        return makeBranch(emitCompare64(cond, temp.memory(), temp.data()));
    }

    Jump branch32WithPatch(RelationalCondition cond, Address address, DataLabel32& dataLabel, TrustedImm32 initialRightValue = TrustedImm32(0))
    {
        auto temp = temps<Data, Memory>();
        load32(address, temp.memory());
        dataLabel = moveWithPatch(initialRightValue, temp.data());
        return makeBranch(emitCompare32(cond, temp.memory(), temp.data()));
    }

    PatchableJump patchableBranch64(RelationalCondition cond, RegisterID left, RegisterID right)
    {
        return PatchableJump(branch64(cond, left, right));
    }
    // ---- floating-point conditions ----
    //
    // fcmpu sets exactly one of LT, GT, EQ, SO in its target field: SO means
    // "unordered", i.e. at least one operand is NaN, and in that case LT, GT
    // and EQ are all clear. Six of JSC's twelve DoubleConditions are single
    // bits of that; the other six are disjunctions of two, which need a
    // cror. The result of that cror MUST land in a different field from its
    // inputs, which is what cr7 is reserved for -- cr2 to cr4 are
    // callee-saved and are never written by this port.
    CRTest emitDoubleConditionFromCR0(DoubleCondition cond)
    {
        constexpr CRField source = CRField::CR0;
        constexpr CRField composed = CRField::CR7;
        auto composeInto = [&](CRBit first, CRBit second) -> CRTest {
            m_assembler.cror(crBitIndex(composed, CRBit::LT),
                crBitIndex(source, first), crBitIndex(source, second));
            return { CRBit::LT, true, composed };
        };

        switch (cond) {
        // Single-bit tests.
        case DoubleEqualAndOrdered:                return { CRBit::EQ, true };
        case DoubleGreaterThanAndOrdered:          return { CRBit::GT, true };
        case DoubleLessThanAndOrdered:             return { CRBit::LT, true };
        // "or unordered" complements of the above: NaN clears the tested bit,
        // so testing it as FALSE already includes the unordered case.
        case DoubleNotEqualOrUnordered:            return { CRBit::EQ, false };
        case DoubleGreaterThanOrEqualOrUnordered:  return { CRBit::LT, false };
        case DoubleLessThanOrEqualOrUnordered:     return { CRBit::GT, false };
        // Two-bit disjunctions.
        case DoubleNotEqualAndOrdered:             return composeInto(CRBit::LT, CRBit::GT);
        case DoubleGreaterThanOrEqualAndOrdered:   return composeInto(CRBit::GT, CRBit::EQ);
        case DoubleLessThanOrEqualAndOrdered:      return composeInto(CRBit::LT, CRBit::EQ);
        case DoubleEqualOrUnordered:               return composeInto(CRBit::EQ, CRBit::SO);
        case DoubleGreaterThanOrUnordered:         return composeInto(CRBit::GT, CRBit::SO);
        case DoubleLessThanOrUnordered:            return composeInto(CRBit::LT, CRBit::SO);
        }
        RELEASE_ASSERT_NOT_REACHED();
        return { CRBit::EQ, true };
    }

    CRTest emitDoubleCompare(DoubleCondition cond, FPRegisterID a, FPRegisterID b)
    {
        // fcmpu, not fcmpo: JSC compares values that may legitimately be
        // NaN and must not raise an invalid-operation exception for it.
        m_assembler.fcmpu(CRField::CR0, a, b);
        return emitDoubleConditionFromCR0(cond);
    }

    CRTest emitDoubleCompareWithZero(DoubleCondition cond, FPRegisterID reg)
    {
        m_assembler.xxlxor(fpTempRegister, fpTempRegister, fpTempRegister);
        return emitDoubleCompare(cond, reg, fpTempRegister);
    }

    // fcmpu is a scalar double compare and there is no single-precision
    // equivalent that yields CR bits -- xvcmp*sp produces lane masks -- so a
    // float compare widens both operands into the double model first. The
    // widening is exact and order-preserving, so the twelve DoubleConditions
    // mean the same thing on the result, NaN included.
    CRTest emitFloatCompare(DoubleCondition cond, FPRegisterID a, FPRegisterID b)
    {
        convertFloatToDouble(a, fpTempRegister);
        convertFloatToDouble(b, fpTempRegister2);
        return emitDoubleCompare(cond, fpTempRegister, fpTempRegister2);
    }

    CRTest emitFloatCompareWithZero(DoubleCondition cond, FPRegisterID reg)
    {
        convertFloatToDouble(reg, fpTempRegister);
        m_assembler.xxlxor(fpTempRegister2, fpTempRegister2, fpTempRegister2);
        return emitDoubleCompare(cond, fpTempRegister, fpTempRegister2);
    }

    Jump branchDouble(DoubleCondition cond, FPRegisterID a, FPRegisterID b) { return makeBranch(emitDoubleCompare(cond, a, b)); }
    Jump branchFloat(DoubleCondition cond, FPRegisterID a, FPRegisterID b) { return makeBranch(emitFloatCompare(cond, a, b)); }
    Jump branchDoubleWithZero(DoubleCondition cond, FPRegisterID reg) { return makeBranch(emitDoubleCompareWithZero(cond, reg)); }
    Jump branchFloatWithZero(DoubleCondition cond, FPRegisterID reg) { return makeBranch(emitFloatCompareWithZero(cond, reg)); }

    Jump branchDoubleNonZero(FPRegisterID reg, FPRegisterID) { return branchDoubleWithZero(DoubleNotEqualAndOrdered, reg); }
    Jump branchDoubleZeroOrNaN(FPRegisterID reg, FPRegisterID) { return branchDoubleWithZero(DoubleEqualOrUnordered, reg); }

    void compareDouble(DoubleCondition cond, FPRegisterID a, FPRegisterID b, RegisterID dest) { emitSetFromCR0(emitDoubleCompare(cond, a, b), dest); }
    void compareFloat(DoubleCondition cond, FPRegisterID a, FPRegisterID b, RegisterID dest) { emitSetFromCR0(emitFloatCompare(cond, a, b), dest); }
    void compareDoubleWithZero(DoubleCondition cond, FPRegisterID reg, RegisterID dest) { emitSetFromCR0(emitDoubleCompareWithZero(cond, reg), dest); }
    void compareFloatWithZero(DoubleCondition cond, FPRegisterID reg, RegisterID dest) { emitSetFromCR0(emitFloatCompareWithZero(cond, reg), dest); }

    // Truncate toward zero into an int32, and report whether the value was
    // representable. The test is a round trip against friz(src), which is
    // exact: it succeeds precisely when trunc(src) fits in an int32 and src
    // is not NaN. Checking the saturated result against INT32_MIN/MAX
    // instead would misreport the values that legitimately truncate to those.
    Jump branchTruncateDoubleToInt32(FPRegisterID src, RegisterID dest, BranchTruncateType branchType = BranchIfTruncateFailed)
    {
        m_assembler.friz(fpTempRegister2, src);      // trunc(src), still a double
        m_assembler.fctiwz(fpTempRegister, src);     // saturating 32-bit convert
        m_assembler.mfvsrwz(dest, fpTempRegister);
        m_assembler.mtvsrwa(fpTempRegister, dest);
        m_assembler.fcfid(fpTempRegister, fpTempRegister);
        m_assembler.fcmpu(CRField::CR0, fpTempRegister, fpTempRegister2);
        return makeBranch(emitDoubleConditionFromCR0(
            branchType == BranchIfTruncateSuccessful ? DoubleEqualAndOrdered : DoubleNotEqualOrUnordered));
    }

    // Convert to an int32, and fail unless the double was EXACTLY that
    // int32. This is not branchTruncateDoubleToInt32 with a different name:
    // that one asks whether trunc(src) fits, and answers yes for 5.25. This
    // one asks whether src is an integer at all, so the round trip has to be
    // compared against `src` itself and never against trunc(src) -- the same
    // thing ARM64 does with fcvtns/scvtf. Delegating to the truncating form
    // made JITDivGenerator decide that 21/4 "is actually an integer" and
    // hand JavaScript back the number 5.
    void branchConvertDoubleToInt32(FPRegisterID src, RegisterID dest, JumpList& failureCases, FPRegisterID, bool negZeroCheck = true)
    {
        m_assembler.fctiwz(fpTempRegister, src);     // saturating 32-bit convert
        m_assembler.mfvsrwz(dest, fpTempRegister);
        m_assembler.mtvsrwa(fpTempRegister, dest);
        m_assembler.fcfid(fpTempRegister, fpTempRegister);
        // Unordered covers NaN; saturation covers out-of-range, because a
        // saturated result cannot compare equal to the value that saturated
        // it. A fractional value fails here and only here.
        failureCases.append(makeBranch(emitDoubleCompare(DoubleNotEqualOrUnordered, fpTempRegister, src)));
        if (!negZeroCheck)
            return;
        // A result of zero is ambiguous between +0.0 and -0.0, and JSC needs
        // -0.0 to fail so it stays a double. The sign bit of the ORIGINAL
        // value is the only place that survives the conversion.
        Jump notZero = branchTest32(NonZero, dest);
        auto temp = temps<Data>();
        m_assembler.mfvsrd(temp.data(), src);
        failureCases.append(makeBranch(emitCompare64(LessThan, temp.data(), static_cast<int64_t>(0))));
        notZero.link(this);
    }
    // Indirect call through `target`. For a C callee, ELFv2 wants the entry
    // address in r12 as well as in CTR, because the callee's global entry
    // point computes its own TOC from r12. For generated code r12 must be
    // left alone: it is regT9, which is also GPRInfo::handlerGPR, and an
    // inline-cache handler is passed to its callee in exactly that register.
    void emitIndirectCall(RegisterID target, bool isNativeCallee)
    {
        if (!isNativeCallee) {
            m_assembler.mtctr(target);
            m_assembler.bctrl();
            return;
        }
        if (target != PPC64Registers::r12)
            m_assembler.mr(PPC64Registers::r12, target);
        m_assembler.mtctr(PPC64Registers::r12);
        emitCCallLinkageAreaSetup();
        m_assembler.bctrl();
    }

    // A patchable call to an address not known until link time. The target
    // is a C function outside the executable pool, so this is the seven-word
    // pointer site: five words of constant ladder that linkPointer() fills
    // in, then mtctr/bctrl.
    Call call(PtrTag tag)
    {
        bool isNative = callTargetIsNativeCode(tag);
        if (isNative)
            emitCCallLinkageAreaSetup();
        auto label = m_assembler.label();
        m_assembler.emitPointerCallSitePlaceholder();
        Call result(label, Call::Linkable);
        if (isNative)
            emitCCallLinkageAreaTeardown();
        return result;
    }

    Call call(RegisterID target, PtrTag tag)
    {
        bool isNative = callTargetIsNativeCode(tag);
        emitIndirectCall(target, isNative);
        // The label is the return address, taken before the teardown so it
        // is the address the callee will actually return to.
        Call result(m_assembler.labelIgnoringWatchpoints(), Call::None);
        if (isNative)
            emitCCallLinkageAreaTeardown();
        return result;
    }

    Call call(Address address, PtrTag tag)
    {
        bool isNative = callTargetIsNativeCode(tag);
        RegisterID target = isNative ? PPC64Registers::r12 : static_cast<RegisterID>(dataTempRegister);
        load64(address, target);
        return call(target, tag);
    }

    // The dynamic-tag overloads (ARM64E pointer authentication). Nothing in
    // this port can tell a C target from a JIT one at run time, and choosing
    // wrongly corrupts a stack either way, so these refuse rather than pick.
    Call call(RegisterID) { UNREACHABLE_FOR_PLATFORM(); return { }; }
    Call call(RegisterID, RegisterID) { UNREACHABLE_FOR_PLATFORM(); return { }; }
    Call call(Address, RegisterID) { UNREACHABLE_FOR_PLATFORM(); return { }; }

    // Routed through call(RegisterID, PtrTag) on purpose: implementing this
    // as a bare bctrl -- which is what MacroAssemblerRISCV64 and
    // MacroAssemblerX86_64 do -- would bypass the linkage-area logic, and
    // callOperation is the hottest C++ call in the Baseline tier
    // (jit/SlowPathCall.cpp).
    template<PtrTag tag>
    void callOperation(const CodePtr<tag> operation)
    {
        auto temp = temps<Data>();
        move(TrustedImmPtr(operation.taggedPtr()), temp.data());
        call(temp.data(), tag);
    }

    // ExceptionOperationResult<T> is `{ T value; Exception* exception; }`.
    // Spelled structurally rather than by name so this header does not have
    // to include jit/OperationResult.h.
    template<typename T>
    static constexpr bool isFloatingPointExceptionOperationResult()
    {
        if constexpr (requires (T t) { t.value; t.exception; })
            return std::is_floating_point_v<std::remove_cvref_t<decltype(std::declval<T>().value)>>;
        else
            return false;
    }

    // The one seam between ELFv2's float convention and this port's float
    // register model. ELFv2 returns a bare float in f1 in DOUBLE format; the
    // model wants the raw single in the low word. Hooking it here means a
    // float-returning operation added upstream needs no site: WTF::CodePtr
    // converts implicitly from Out(*)(In...), so a
    // callOperation<tag>(someOperation) that would otherwise land on the
    // CodePtr overload above lands here instead and gets the conversion.
    //
    // Float FPR *arguments* cannot occur: CCallHelpers::setupArgumentsImpl
    // static_asserts that an FPR argument is a double.
    //
    // The hazard this does NOT cover is a float-returning operation reached
    // some other way -- move(TrustedImmPtr(fn)) then call(reg), or an
    // offlineasm cCall. That is silent, and the grep for it is
    // `grep -rn 'JIT_OPERATION(.*, float,' Source/JavaScriptCore` at every
    // rebase. See jsc-ppc64le-yarr-wasm.md section 7.7.
    template<PtrTag tag, typename Out, typename... In>
    void callOperation(Out (*operation)(In...))
    {
        static_assert(!isFloatingPointExceptionOperationResult<Out>(),
            "A floating-point operation result must not be wrapped in ExceptionOperationResult on this "
            "target: ELFv2 returns the {float, Exception*} aggregate in r3:r4, not f1. Restore the "
            "CPU(PPC64LE) arm of canMakeExceptionOperationResult in jit/OperationResult.h.");
        callOperation<tag>(CodePtr<tag>(operation));
        if constexpr (std::is_same_v<Out, float>) {
            // Exact: the value is already single-valued, this only moves it
            // from double format into the low word.
            convertDoubleToFloat(PPC64Registers::f1, PPC64Registers::f1);
        }
    }

    void getEffectiveAddress(BaseIndex address, RegisterID dest)
    {
        auto resolution = resolveAddress(address, dest, false);
        if (resolution.offset)
            addImmediate64(resolution.base, resolution.offset, dest);
        else
            move(resolution.base, dest);
    }
    // ==================================================================
    // Floating point.
    //
    // THE FLOAT REGISTER MODEL. A "float" lives in an FPR as its raw 32-bit
    // IEEE single pattern in the low word of doubleword 0 -- ISA word 1, the
    // word mfvsrwz reads and stfd puts at byte offset 0 -- and the other 96
    // bits of the register are don't-care. That is the invariant ARM64
    // (fmov<32>), X86_64 (the low xmm lane) and RISCV64 (fmv.x.w) all
    // provide, and shared code depends on it in places that have no type
    // information at all: IPInt's 16-byte value slots, wasm globals, packed
    // struct and array fields, f32.reinterpret_i32. See
    // jsc-ppc64le-yarr-wasm.md section 7.
    //
    // It is NOT ELFv2's model, which keeps a float in an FPR in double
    // format -- so this port carries two conventions for one register class
    // and converts at the seam. The seam is exactly one shape: a
    // float-returning JIT operation, hooked once in callOperation below.
    // Float FPR *arguments* cannot occur (CCallHelpers static_asserts them
    // away) and every other crossing to C is through memory, where ELFv2's
    // format for a float is the raw single -- this model's own.
    //
    // Mechanically: the xv*sp vector family computes each 32-bit lane
    // independently, so f32 arithmetic is one instruction on a register
    // whose other lanes hold garbage; lxsiwzx/stxsiwx and mtvsrwz/mfvsrwz
    // move the word; and the two conversions to and from the double model
    // are a splat plus xscvspdpn / xscvdpsp plus a splat.
    // ==================================================================

    void loadDouble(Address address, FPRegisterID dest)
    {
        auto temp = lazyTemp<Memory>();
        auto resolution = resolveAddress(address, temp, false);
        m_assembler.lfd(dest, resolution.base, resolution.offset);
    }

    void loadDouble(BaseIndex address, FPRegisterID dest)
    {
        if (isXFormBaseIndex(address)) {
            ASSERT(address.base != PPC64Registers::r0);
            m_assembler.lfdx(dest, address.base, address.index);
            return;
        }
        auto temp = temps<Memory>();
        auto resolution = resolveAddress(address, temp.memory(), false);
        m_assembler.lfd(dest, resolution.base, resolution.offset);
    }

    void loadDouble(TrustedImmPtr address, FPRegisterID dest)
    {
        auto temp = temps<Memory>();
        loadImmediate(address, temp.memory());
        m_assembler.lfd(dest, temp.memory(), 0);
    }

    // lxsiwzx/stxsiwx are X-form -- EA = (RA|0) + RB, no displacement -- so
    // any displacement resolveAddress leaves behind is folded into a
    // register first. With RA = r0 the form reads r0 as the literal zero,
    // which is why the address always goes in RB.
    RegisterID foldOffsetIntoAddressRegister(AddressResolution resolution, RegisterID scratch)
    {
        if (!resolution.offset)
            return resolution.base;
        m_assembler.addi(scratch, resolution.base, resolution.offset);
        return scratch;
    }

    void loadFloat(Address address, FPRegisterID dest)
    {
        auto temp = lazyTemp<Memory>();
        auto resolution = resolveAddress(address, temp, false);
        m_assembler.lxsiwzx(dest, PPC64Registers::r0, foldOffsetIntoAddressRegister(resolution, temp));
    }

    void loadFloat(BaseIndex address, FPRegisterID dest)
    {
        if (isXFormBaseIndex(address)) {
            ASSERT(address.base != PPC64Registers::r0);
            m_assembler.lxsiwzx(dest, address.base, address.index);
            return;
        }
        auto temp = temps<Memory>();
        auto resolution = resolveAddress(address, temp.memory(), false);
        m_assembler.lxsiwzx(dest, PPC64Registers::r0, foldOffsetIntoAddressRegister(resolution, temp.memory()));
    }

    void loadFloat(TrustedImmPtr address, FPRegisterID dest)
    {
        auto temp = temps<Memory>();
        loadImmediate(address, temp.memory());
        m_assembler.lxsiwzx(dest, PPC64Registers::r0, temp.memory());
    }

    void storeDouble(FPRegisterID src, Address address)
    {
        auto temp = lazyTemp<Memory>();
        auto resolution = resolveAddress(address, temp, false);
        m_assembler.stfd(src, resolution.base, resolution.offset);
    }

    void storeDouble(FPRegisterID src, BaseIndex address)
    {
        if (isXFormBaseIndex(address)) {
            ASSERT(address.base != PPC64Registers::r0);
            m_assembler.stfdx(src, address.base, address.index);
            return;
        }
        auto temp = temps<Memory>();
        auto resolution = resolveAddress(address, temp.memory(), false);
        m_assembler.stfd(src, resolution.base, resolution.offset);
    }

    void storeDouble(FPRegisterID src, TrustedImmPtr address)
    {
        auto temp = temps<Memory>();
        loadImmediate(address, temp.memory());
        m_assembler.stfd(src, temp.memory(), 0);
    }

    void storeFloat(FPRegisterID src, Address address)
    {
        auto temp = lazyTemp<Memory>();
        auto resolution = resolveAddress(address, temp, false);
        m_assembler.stxsiwx(src, PPC64Registers::r0, foldOffsetIntoAddressRegister(resolution, temp));
    }

    void storeFloat(FPRegisterID src, BaseIndex address)
    {
        if (isXFormBaseIndex(address)) {
            ASSERT(address.base != PPC64Registers::r0);
            m_assembler.stxsiwx(src, address.base, address.index);
            return;
        }
        auto temp = temps<Memory>();
        auto resolution = resolveAddress(address, temp.memory(), false);
        m_assembler.stxsiwx(src, PPC64Registers::r0, foldOffsetIntoAddressRegister(resolution, temp.memory()));
    }

    void storeFloat(FPRegisterID src, TrustedImmPtr address)
    {
        auto temp = temps<Memory>();
        loadImmediate(address, temp.memory());
        m_assembler.stxsiwx(src, PPC64Registers::r0, temp.memory());
    }

    void addDouble(FPRegisterID a, FPRegisterID b, FPRegisterID dest) { m_assembler.fadd(dest, a, b); }
    void addDouble(FPRegisterID src, FPRegisterID dest) { m_assembler.fadd(dest, dest, src); }
    void addFloat(FPRegisterID a, FPRegisterID b, FPRegisterID dest) { m_assembler.xvaddsp(dest, a, b); }
    void addFloat(FPRegisterID src, FPRegisterID dest) { m_assembler.xvaddsp(dest, dest, src); }

    void addDouble(AbsoluteAddress address, FPRegisterID dest)
    {
        loadDouble(TrustedImmPtr(address.m_ptr), fpTempRegister);
        m_assembler.fadd(dest, dest, fpTempRegister);
    }

    // dest = dest - src for the two-operand form; fsub(frt, fra, frb) is
    // frt = fra - frb.
    void subDouble(FPRegisterID a, FPRegisterID b, FPRegisterID dest) { m_assembler.fsub(dest, a, b); }
    void subDouble(FPRegisterID src, FPRegisterID dest) { m_assembler.fsub(dest, dest, src); }
    void subFloat(FPRegisterID a, FPRegisterID b, FPRegisterID dest) { m_assembler.xvsubsp(dest, a, b); }
    void subFloat(FPRegisterID src, FPRegisterID dest) { m_assembler.xvsubsp(dest, dest, src); }

    void mulDouble(FPRegisterID a, FPRegisterID b, FPRegisterID dest) { m_assembler.fmul(dest, a, b); }
    void mulDouble(FPRegisterID src, FPRegisterID dest) { m_assembler.fmul(dest, dest, src); }
    void mulFloat(FPRegisterID a, FPRegisterID b, FPRegisterID dest) { m_assembler.xvmulsp(dest, a, b); }
    void mulFloat(FPRegisterID src, FPRegisterID dest) { m_assembler.xvmulsp(dest, dest, src); }

    void mulDouble(Address address, FPRegisterID dest)
    {
        loadDouble(address, fpTempRegister);
        m_assembler.fmul(dest, dest, fpTempRegister);
    }

    void divDouble(FPRegisterID a, FPRegisterID b, FPRegisterID dest) { m_assembler.fdiv(dest, a, b); }
    void divDouble(FPRegisterID src, FPRegisterID dest) { m_assembler.fdiv(dest, dest, src); }
    void divFloat(FPRegisterID a, FPRegisterID b, FPRegisterID dest) { m_assembler.xvdivsp(dest, a, b); }
    void divFloat(FPRegisterID src, FPRegisterID dest) { m_assembler.xvdivsp(dest, dest, src); }

    void sqrtDouble(FPRegisterID src, FPRegisterID dest) { m_assembler.fsqrt(dest, src); }
    void sqrtFloat(FPRegisterID src, FPRegisterID dest) { m_assembler.xvsqrtsp(dest, src); }

    void absDouble(FPRegisterID src, FPRegisterID dest) { m_assembler.fabs_(dest, src); }
    void absFloat(FPRegisterID src, FPRegisterID dest) { m_assembler.xvabssp(dest, src); }
    void negateDouble(FPRegisterID src, FPRegisterID dest) { m_assembler.fneg(dest, src); }
    void negateFloat(FPRegisterID src, FPRegisterID dest) { m_assembler.xvnegsp(dest, src); }

    void ceilDouble(FPRegisterID src, FPRegisterID dest) { m_assembler.frip(dest, src); }
    void ceilFloat(FPRegisterID src, FPRegisterID dest) { m_assembler.xvrspip(dest, src); }
    void floorDouble(FPRegisterID src, FPRegisterID dest) { m_assembler.frim(dest, src); }
    void floorFloat(FPRegisterID src, FPRegisterID dest) { m_assembler.xvrspim(dest, src); }
    void truncDouble(FPRegisterID src, FPRegisterID dest) { m_assembler.friz(dest, src); }
    void truncFloat(FPRegisterID src, FPRegisterID dest) { m_assembler.xvrspiz(dest, src); }
    void roundTowardZeroDouble(FPRegisterID src, FPRegisterID dest) { m_assembler.friz(dest, src); }
    void roundTowardZeroFloat(FPRegisterID src, FPRegisterID dest) { m_assembler.xvrspiz(dest, src); }

    // JavaScript's round-to-nearest is ties-to-EVEN. frin is ties-AWAY-from-
    // zero and is therefore the wrong instruction, however much its name
    // suggests otherwise. xsrdpic rounds using the current FPSCR mode, whose
    // default is round-to-nearest-even.
    //
    // [SPEC] jsc-ppc64le-port.md section 5.6 flags this as needing a probe:
    // nothing has yet confirmed that FPSCR is in its default mode everywhere
    // JIT code runs. testmasm is where that gets settled.
    void roundTowardNearestIntDouble(FPRegisterID src, FPRegisterID dest) { m_assembler.xsrdpic(dest, src); }
    void roundTowardNearestIntFloat(FPRegisterID src, FPRegisterID dest) { m_assembler.xvrspic(dest, src); }

    // Bitwise operations on floating-point values: VSR n and FPR n are the
    // same register, so the VSX logical ops apply directly.
    void andDouble(FPRegisterID a, FPRegisterID b, FPRegisterID dest) { m_assembler.xxland(dest, a, b); }
    void andFloat(FPRegisterID a, FPRegisterID b, FPRegisterID dest) { m_assembler.xxland(dest, a, b); }
    void orDouble(FPRegisterID a, FPRegisterID b, FPRegisterID dest) { m_assembler.xxlor(dest, a, b); }
    void orFloat(FPRegisterID a, FPRegisterID b, FPRegisterID dest) { m_assembler.xxlor(dest, a, b); }
    // ---- integer <-> floating point ----
    //
    // The GPR/FPR path is the VSX direct-move family (ISA 2.07), not a store
    // and reload through memory. mtvsrwa sign-extends the low word into the
    // VSR, mtvsrwz zero-extends it, and mtvsrd moves all 64 bits; fcfid and
    // fcfidu then interpret the doubleword as a signed or unsigned integer.
    // Pairing the wrong two of those is a silent numeric error, so the
    // signed and unsigned paths are spelled out separately rather than
    // sharing a helper.

    void convertInt32ToDouble(RegisterID src, FPRegisterID dest)
    {
        m_assembler.mtvsrwa(dest, src); // sign-extend: the value is an int32
        m_assembler.fcfid(dest, dest);
    }

    void convertInt32ToDouble(TrustedImm32 imm, FPRegisterID dest)
    {
        auto temp = temps<Data>();
        loadImmediate(imm, temp.data());
        convertInt32ToDouble(temp.data(), dest);
    }

    // mtvsrwa sign-extends the int32 across doubleword 0, so ISA word 1 --
    // where the model keeps a float -- holds the original value and word 0
    // holds its sign extension. xvcvsxwsp converts each word independently,
    // so lane 1 comes out as (float)src with one rounding.
    void convertInt32ToFloat(RegisterID src, FPRegisterID dest)
    {
        m_assembler.mtvsrwa(dest, src);
        m_assembler.xvcvsxwsp(dest, dest);
    }

    void convertUInt32ToDouble(RegisterID src, FPRegisterID dest)
    {
        m_assembler.mtvsrwz(dest, src); // zero-extend: the value is a uint32
        m_assembler.fcfidu(dest, dest);
    }

    // Symmetric with convertInt32ToFloat above: mtvsrwz puts the zero-extended
    // word where mtvsrwa puts the sign-extended one, and the vector convert
    // leaves the single in ISA word 1, which is where the float register model
    // wants it. No xscvdpsp/xxspltw tail is needed -- that is only for the
    // scalar fcfid*s path the 64-bit conversions take.
    void convertUInt32ToFloat(RegisterID src, FPRegisterID dest)
    {
        m_assembler.mtvsrwz(dest, src); // zero-extend: the value is a uint32
        m_assembler.xvcvuxwsp(dest, dest);
    }

    void convertInt64ToDouble(RegisterID src, FPRegisterID dest)
    {
        m_assembler.mtvsrd(dest, src);
        m_assembler.fcfid(dest, dest);
    }

    // No vector form takes a 64-bit integer, so this goes through the scalar
    // single conversion and then into the model. The narrowing is exact: the
    // value is already single-valued after fcfids.
    void convertInt64ToFloat(RegisterID src, FPRegisterID dest)
    {
        m_assembler.mtvsrd(dest, src);
        m_assembler.fcfids(dest, dest);
        m_assembler.xscvdpsp(dest, dest);
        m_assembler.xxspltw(dest, dest, 0);
    }

    void convertUInt64ToDouble(RegisterID src, FPRegisterID dest)
    {
        m_assembler.mtvsrd(dest, src);
        m_assembler.fcfidu(dest, dest);
    }

    void convertUInt64ToFloat(RegisterID src, FPRegisterID dest)
    {
        m_assembler.mtvsrd(dest, src);
        m_assembler.fcfidus(dest, dest);
        m_assembler.xscvdpsp(dest, dest);
        m_assembler.xxspltw(dest, dest, 0);
    }

    // The two crossings between the float model and the double model.
    //
    // xscvspdpn reads its single from ISA word 0 and the model keeps it in
    // word 1, so widening splats word 1 across the register first; it is the
    // non-signalling form because JSC moves raw patterns through here and a
    // signalling NaN's payload must survive. Narrowing is the reverse:
    // xscvdpsp ROUNDS (xscvdpspn does not -- it differs on a third of all
    // inputs) and writes ISA word 0, so the splat puts it back in word 1.
    // ISA 2.07 defines only word 0 for xscvdpsp; POWER9 happens to write
    // word 1 as well, and this does not rely on that.
    void convertFloatToDouble(FPRegisterID src, FPRegisterID dest)
    {
        m_assembler.xxspltw(dest, src, 1);
        m_assembler.xscvspdpn(dest, dest);
    }

    void convertDoubleToFloat(FPRegisterID src, FPRegisterID dest)
    {
        m_assembler.xscvdpsp(dest, src);
        m_assembler.xxspltw(dest, dest, 0);
    }

    // Truncations round toward zero and SATURATE on overflow, which is the
    // ARM64 fcvtz* behaviour JSC expects; NaN becomes zero for the unsigned
    // forms and the minimum value for the signed ones. Callers that need to
    // know whether the value was representable use
    // branchTruncateDoubleToInt32 instead.
    //
    // fctiw* leaves its 32-bit result in the low word of the FPR, and
    // mfvsrwz brings that word back zero-extended -- which is exactly the
    // 32-bit invariant, at no extra cost.
    void truncateDoubleToInt32(FPRegisterID src, RegisterID dest)
    {
        m_assembler.fctiwz(fpTempRegister, src);
        m_assembler.mfvsrwz(dest, fpTempRegister);
    }

    void truncateDoubleToUint32(FPRegisterID src, RegisterID dest)
    {
        m_assembler.fctiwuz(fpTempRegister, src);
        m_assembler.mfvsrwz(dest, fpTempRegister);
    }

    void truncateDoubleToInt64(FPRegisterID src, RegisterID dest)
    {
        m_assembler.fctidz(fpTempRegister, src);
        m_assembler.mfvsrd(dest, fpTempRegister);
    }

    void truncateDoubleToUint64(FPRegisterID src, RegisterID dest)
    {
        m_assembler.fctiduz(fpTempRegister, src);
        m_assembler.mfvsrd(dest, fpTempRegister);
    }

    // The four-argument form exists because x86 needs scratch registers to
    // do an unsigned 64-bit conversion. PowerPC has the instruction, so the
    // scratches are unused.
    void truncateDoubleToUint64(FPRegisterID src, RegisterID dest, FPRegisterID, FPRegisterID) { truncateDoubleToUint64(src, dest); }

    // VSX has no truncation of a single that matches fctiw*'s saturation and
    // NaN behaviour (xvcvspsxws differs on both), so a float truncation
    // widens into the double model first and reuses the validated pair. The
    // temporary is fpTempRegister2 because truncateDoubleTo* uses
    // fpTempRegister itself.
    FPRegisterID widenFloatToDoubleTemp(FPRegisterID src)
    {
        convertFloatToDouble(src, fpTempRegister2);
        return fpTempRegister2;
    }

    void truncateFloatToInt32(FPRegisterID src, RegisterID dest) { truncateDoubleToInt32(widenFloatToDoubleTemp(src), dest); }
    void truncateFloatToUint32(FPRegisterID src, RegisterID dest) { truncateDoubleToUint32(widenFloatToDoubleTemp(src), dest); }
    void truncateFloatToInt64(FPRegisterID src, RegisterID dest) { truncateDoubleToInt64(widenFloatToDoubleTemp(src), dest); }
    void truncateFloatToUint64(FPRegisterID src, RegisterID dest) { truncateDoubleToUint64(widenFloatToDoubleTemp(src), dest); }
    void truncateFloatToUint64(FPRegisterID src, RegisterID dest, FPRegisterID, FPRegisterID) { truncateFloatToUint64(src, dest); }
    // ---- stack ----
    //
    // ELFv2 requires r1 to stay 16-byte aligned at all times, so a single
    // push moves it by 16 and not by 8. ARM64 does the same for the same
    // reason. pushToSaveByteOffset() below reports that to the generic code
    // that reasons about how much a push consumed.

    void push(RegisterID src)
    {
        m_assembler.addi(PPC64Registers::r1, PPC64Registers::r1, -16);
        m_assembler.std(src, PPC64Registers::r1, 0);
    }

    void push(TrustedImm32 imm)
    {
        auto temp = temps<Data>();
        loadImmediate(imm, temp.data());
        push(temp.data());
    }

    void pop(RegisterID dest)
    {
        m_assembler.ld(dest, PPC64Registers::r1, 0);
        m_assembler.addi(PPC64Registers::r1, PPC64Registers::r1, 16);
    }

    // Matches ARM64's stp/ldp ordering: the first register goes at the lower
    // address. That ordering is what makes pushPair(fp, lr) produce the
    // CallerFrame/ReturnPC layout JSC expects.
    void pushPair(RegisterID first, RegisterID second)
    {
        m_assembler.addi(PPC64Registers::r1, PPC64Registers::r1, -16);
        m_assembler.std(first, PPC64Registers::r1, 0);
        m_assembler.std(second, PPC64Registers::r1, 8);
    }

    void popPair(RegisterID first, RegisterID second)
    {
        m_assembler.ld(first, PPC64Registers::r1, 0);
        m_assembler.ld(second, PPC64Registers::r1, 8);
        m_assembler.addi(PPC64Registers::r1, PPC64Registers::r1, 16);
    }

    static constexpr ptrdiff_t pushToSaveByteOffset() { return 16; }
    // The reason (and any extra datum) are left in the two temp registers so
    // they show up in the register dump of the resulting crash, then `trap`
    // raises SIGTRAP. This is the ARM64 shape.
    void abortWithReason(AbortReason reason)
    {
        move(TrustedImm32(static_cast<int32_t>(reason)), dataTempRegister);
        breakpoint();
    }

    void abortWithReason(AbortReason reason, intptr_t misc)
    {
        move(TrustedImm64(misc), memoryTempRegister);
        abortWithReason(reason);
    }
    // ==================================================================
    // Compare-and-swap.
    //
    // ONE larx/stcx. attempt, with no inner loop. That is what "weak" means:
    // the CAS may report failure although memory held the expected value,
    // because the reservation was lost for any of the reasons Book II
    // section 1.7.4.1 lists. The only caller today is the DFG's typed-array
    // Atomics arm -- compileAtomicsReadModifyWrite in DFGSpeculativeJIT64.cpp
    // -- which already owns the retry loop and has to, because Atomics.add
    // computes its new value from the old one and must recompute it after a
    // mismatch. Its loop absorbs a value mismatch, a lost reservation and a
    // spurious failure identically, so a strong CAS in here would be a loop
    // inside a loop re-storing against an expected value nobody rechecked.
    //
    // Every Atomics.* on a typed array is that loop, INCLUDING load and
    // store, so the barriers below are the only barriers those two
    // operations get. Sequential consistency -- the ordering JavaScript
    // specifies Atomics with -- has to be assembled from parts, because
    // larx/stcx. order nothing by themselves: a full `sync` before the larx,
    // and an `lwsync` after the stcx. on BOTH the stored and the mismatched
    // path. This is the leading-sync convention, and joining it is not a free
    // choice: the same SharedArrayBuffer word is reached from other threads
    // by the C++ slow paths in AtomicsObject.cpp, which gcc and clang compile
    // leading-sync, and mixing the two conventions in one program leaves an
    // SC store and an SC load with no full barrier between them. Substituting
    // `lwsync` for the leading `sync` would be measurably cheaper and would
    // drop the StoreLoad edge, which is precisely the edge sequential
    // consistency adds to acquire/release.
    //
    // The `sync` sits OUTSIDE the reservation window deliberately -- gcc's
    // and the kernel's placement, not clang's. The window from larx to stcx.
    // holds one compare and one branch and nothing else, because while it is
    // open any store from any other thread anywhere in the 128-byte
    // reservation granule fails the stcx. and costs the caller another lap,
    // with the sync paid again.
    //
    // See powerpc64le-handbook jsc-ppc64le-atomics-cas.md.
    // ==================================================================

    template<unsigned bitSize>
    void loadAndReserve(RegisterID dest, RegisterID address)
    {
        // r0 in an RA field reads as the literal zero, so these are plain
        // register-indirect accesses: EA = 0 + address.
        if constexpr (bitSize == 8)
            m_assembler.lbarx(dest, PPC64Registers::r0, address);
        else if constexpr (bitSize == 16)
            m_assembler.lharx(dest, PPC64Registers::r0, address);
        else if constexpr (bitSize == 32)
            m_assembler.lwarx(dest, PPC64Registers::r0, address);
        else
            m_assembler.ldarx(dest, PPC64Registers::r0, address);
    }

    template<unsigned bitSize>
    void storeConditional(RegisterID source, RegisterID address)
    {
        // The widths must pair with the larx above. A reservation taken by
        // lbarx and closed by stwcx. is the architecturally undefined case
        // even at the same address, which is why one bitSize dispatches both
        // halves and they can never be mixed.
        if constexpr (bitSize == 8)
            m_assembler.stbcx_(source, PPC64Registers::r0, address);
        else if constexpr (bitSize == 16)
            m_assembler.sthcx_(source, PPC64Registers::r0, address);
        else if constexpr (bitSize == 32)
            m_assembler.stwcx_(source, PPC64Registers::r0, address);
        else
            m_assembler.stdcx_(source, PPC64Registers::r0, address);
    }

    // stcx. reports success in CR0[EQ], not in a register. ARM64's
    // storeCondRel* hands the caller a status GPR to test; this hands back a
    // Jump taken when the reservation was LOST, which is the same control
    // flow with three fewer instructions per lap -- no mfcr/rlwinm/xori to
    // materialise a status that is immediately branched on anyway.
    //
    // Pair it with loadAndReserve/storeConditional of the SAME bitSize, and
    // keep the window between them as short as the architecture note above
    // requires.
    Jump branchStoreConditionalFailed() { return makeBranch({ CRBit::EQ, false }); }

    // popcntw/popcntd are POWER7, so the FPRegisterID temp the shared
    // signature carries (ARM64 routes through a vector popcount) is unused
    // here. The 32-bit form needs no mask: popcntw's result is 0..32.
    void countPopulation32(RegisterID src, RegisterID dst) { m_assembler.popcntw(dst, src); }
    void countPopulation64(RegisterID src, RegisterID dst) { m_assembler.popcntd(dst, src); }
    void countPopulation32(RegisterID src, RegisterID dst, FPRegisterID) { countPopulation32(src, dst); }
    void countPopulation64(RegisterID src, RegisterID dst, FPRegisterID) { countPopulation64(src, dst); }

    // dest = minuend - mulLeft * mulRight. maddld is ISA 3.0 and would need a
    // negated addend, so this is the POWER8-legal pair. mulld's low doubleword
    // is correct whatever the operands' signs.
    void multiplySub64(RegisterID mulLeft, RegisterID mulRight, RegisterID minuend, RegisterID dest)
    {
        auto temp = temps<Data>();
        m_assembler.mulld(temp.data(), mulLeft, mulRight);
        m_assembler.subf(dest, temp.data(), minuend);
    }

    // The atomic read-modify-writes BBQ needs, in x86's `lock xadd`/`xchg`
    // shape: the operation is applied to memory and the register is left
    // holding the OLD value.
    //
    // The address must have no displacement, which is not a restriction
    // imposed here -- larx and stcx. have no D-form, so the effective address
    // has to be final before any reservation exists, and the existing
    // storeCondImpl asserts the same thing. BBQ satisfies it by construction:
    // "For Atomic access, we need SimpleAddress (uoffset = 0)", folding the
    // offset into the pointer register before building the Address
    // (WasmBBQJIT64.cpp).
    //
    // Ordering is this port's leading-sync convention, matching
    // emitAtomicStrongCAS: sync ahead of the loop, lwsync after it. Nothing is
    // emitted between the larx and the stcx. but the arithmetic itself.
    template<unsigned bitSize, bool isAdd>
    void emitAtomicRMW(RegisterID reg, Address address)
    {
        static_assert(bitSize == 8 || bitSize == 16 || bitSize == 32 || bitSize == 64);
        RELEASE_ASSERT(!address.offset);
        auto temp = temps<Data, Memory>();
        // The operand has to outlive a failed stcx., because reg is where the
        // loaded value goes and is therefore destroyed on every iteration.
        RegisterID operand = temp.data();
        move(reg, operand);

        memoryFence();
        auto reload = label();
        loadAndReserve<bitSize>(reg, address.base);
        RegisterID toStore = operand;
        if constexpr (isAdd) {
            // A 64-bit add is right for every width: stcx. of 8, 16 or 32 bits
            // writes only the low bits, and the loaded value was zero-extended
            // by lbarx/lharx/lwarx, so the sum's low bits are the wrapped
            // result the width wants.
            m_assembler.add(temp.memory(), reg, operand);
            toStore = temp.memory();
        }
        storeConditional<bitSize>(toStore, address.base);
        makeBranch({ CRBit::EQ, false }).linkTo(reload, this);
        loadFence();
    }

    void atomicXchgAdd8(RegisterID reg, Address address) { emitAtomicRMW<8, true>(reg, address); }
    void atomicXchgAdd16(RegisterID reg, Address address) { emitAtomicRMW<16, true>(reg, address); }
    void atomicXchgAdd32(RegisterID reg, Address address) { emitAtomicRMW<32, true>(reg, address); }
    void atomicXchgAdd64(RegisterID reg, Address address) { emitAtomicRMW<64, true>(reg, address); }
    void atomicXchg8(RegisterID reg, Address address) { emitAtomicRMW<8, false>(reg, address); }
    void atomicXchg16(RegisterID reg, Address address) { emitAtomicRMW<16, false>(reg, address); }
    void atomicXchg32(RegisterID reg, Address address) { emitAtomicRMW<32, false>(reg, address); }
    void atomicXchg64(RegisterID reg, Address address) { emitAtomicRMW<64, false>(reg, address); }

    // ==================================================================
    // The load-linked / store-conditional pair B3 lowers atomics onto for any
    // target without a single-instruction CAS. ARM64 reaches these the same way
    // whenever it has no LSE: B3LowerToAir's atomic lowering builds the retry
    // loop itself and asks the MacroAssembler only for the two halves.
    //
    // THE STATUS POLARITY IS INVERTED RELATIVE TO THE HARDWARE, and that is the
    // contract, not a mistake. ARM64's stxr writes 0 to its status register on
    // SUCCESS, and the loop B3 builds ends in
    //   BranchTest32 Zero, boolResult -> doneBlock, reloopBlock
    // so zero means done. PPC's stcx. is the other way round: it sets CR0[EQ] on
    // success. CRTest { CRBit::EQ, false } is what reconciles them --
    // emitSetFromCR0 appends an `xori dest, dest, 1` when branchIfSet is false --
    // so these write 0 on success and 1 on failure, like ARM64.
    //
    // The barriers are split across the pair because B3 splits them: the fenced
    // variants are selected together by loadLinkOpcode/storeCondOpcode on
    // atomic->hasFence(), so LoadLinkAcq + StoreCondRel reassemble this port's
    // existing seq_cst RMW shape -- leading `sync` before the larx, trailing
    // `lwsync` after the stcx. -- which is the leading-sync convention
    // jsc-ppc64le-atomics-cas.md 3.2 says must not be mixed within a program.
    // Putting the release half BEFORE the stcx. instead would leave the pair with
    // no trailing barrier at all and no acquire edge.
    //
    // One cost worth naming: B3 puts the load inside the retry loop, so the
    // leading `sync` is paid on every lap. gcc hoists it out of the loop
    // (3.1 of the same document). Correct, and more expensive than the
    // hand-written CAS above, which keeps its sync outside the window.
    //
    // Air hands these a SimpleAddr, which is an Address with no displacement.
    // That is asserted rather than folded: larx and stcx. have no D-form, so a
    // displacement would need a staging register, and Air generates under
    // DisallowMacroScratchRegisterUsage.
    // ==================================================================

    template<unsigned bitSize>
    void loadLinkImpl(Address address, RegisterID dest, bool acquire)
    {
        RELEASE_ASSERT(!address.offset);
        if (acquire)
            memoryFence();
        loadAndReserve<bitSize>(dest, address.base);
    }

    template<unsigned bitSize>
    void storeCondImpl(RegisterID src, Address address, RegisterID result, bool release)
    {
        RELEASE_ASSERT(!address.offset);
        storeConditional<bitSize>(src, address.base);
        emitSetFromCR0({ CRBit::EQ, false }, result);
        if (release)
            loadFence();
    }

    void loadLink8(Address address, RegisterID dest) { loadLinkImpl<8>(address, dest, false); }
    void loadLinkAcq8(Address address, RegisterID dest) { loadLinkImpl<8>(address, dest, true); }
    void storeCond8(RegisterID src, Address address, RegisterID result) { storeCondImpl<8>(src, address, result, false); }
    void storeCondRel8(RegisterID src, Address address, RegisterID result) { storeCondImpl<8>(src, address, result, true); }

    void loadLink16(Address address, RegisterID dest) { loadLinkImpl<16>(address, dest, false); }
    void loadLinkAcq16(Address address, RegisterID dest) { loadLinkImpl<16>(address, dest, true); }
    void storeCond16(RegisterID src, Address address, RegisterID result) { storeCondImpl<16>(src, address, result, false); }
    void storeCondRel16(RegisterID src, Address address, RegisterID result) { storeCondImpl<16>(src, address, result, true); }

    void loadLink32(Address address, RegisterID dest) { loadLinkImpl<32>(address, dest, false); }
    void loadLinkAcq32(Address address, RegisterID dest) { loadLinkImpl<32>(address, dest, true); }
    void storeCond32(RegisterID src, Address address, RegisterID result) { storeCondImpl<32>(src, address, result, false); }
    void storeCondRel32(RegisterID src, Address address, RegisterID result) { storeCondImpl<32>(src, address, result, true); }

    void loadLink64(Address address, RegisterID dest) { loadLinkImpl<64>(address, dest, false); }
    void loadLinkAcq64(Address address, RegisterID dest) { loadLinkImpl<64>(address, dest, true); }
    void storeCond64(RegisterID src, Address address, RegisterID result) { storeCondImpl<64>(src, address, result, false); }
    void storeCondRel64(RegisterID src, Address address, RegisterID result) { storeCondImpl<64>(src, address, result, true); }

    template<unsigned bitSize>
    JumpList branchAtomicWeakCASImpl(StatusCondition cond, RegisterID expectedAndClobbered, RegisterID newValue, BaseIndex address)
    {
        static_assert(bitSize == 8 || bitSize == 16 || bitSize == 32 || bitSize == 64);
        auto temp = temps<Data, Memory>();

        // The effective address is finished BEFORE the barrier and before the
        // reservation exists. larx and stcx. have no D-form, so a
        // displacement has to be folded in here, and once the reservation is
        // held nothing may compute, load or store.
        auto resolution = resolveAddress(address, temp.memory());
        RegisterID effectiveAddress = resolution.base;
        if (resolution.offset) {
            addImmediate64(resolution.base, static_cast<int64_t>(resolution.offset), temp.memory());
            effectiveAddress = temp.memory();
        }

        // THE SIGN-EXTENSION SEAM, and it is load-bearing. lbarx and lharx
        // zero-extend, but the expected value arrived from the DFG's
        // loadFromIntTypedArray, which uses load8SignedExtendTo32 for an
        // Int8Array: the expected value of the byte 0xff is 0xffffffff.
        // Without this mask the compare below never succeeds, the store is
        // skipped, and the DFG's loop reloads the same -1 and tries again --
        // forever. That failure is not a crash and not a wrong answer, it is
        // a HANG on the first Atomics.sub of a negative Int8Array element,
        // at the DFG tier only. This is the compiler's own `rlwinm 4,4,0,0xff`
        // from the same sequence. The register is documented clobberable and
        // the DFG keeps its result in a separate copy, so the mask is free.
        // At 32 and 64 bits nothing is masked: cmplw reads only bits 32:63,
        // and cmpld reads the whole register.
        if constexpr (bitSize < 32)
            m_assembler.clrldi(expectedAndClobbered, expectedAndClobbered, 64 - bitSize);

        memoryFence();
        loadAndReserve<bitSize>(temp.data(), effectiveAddress);
        if constexpr (bitSize == 64)
            m_assembler.cmpld(CRField::CR0, temp.data(), expectedAndClobbered);
        else
            m_assembler.cmplw(CRField::CR0, temp.data(), expectedAndClobbered);
        // A one-word guard -- the same primitive makeBranch is built from --
        // skipping the store-conditional when CR0.EQ is clear. On that path
        // CR0.EQ stays 0, which is already the answer the status branch
        // wants, and the reservation left standing is harmless: the next larx
        // anywhere replaces it. The stcx. is reachable by this guard falling
        // through and from nowhere else, which is the rule that keeps a
        // stcx. from ever meeting a reservation it did not take.
        m_assembler.insn(Assembler::conditionalGuardInsn(Assembler::BOFalse, crBitIndex(CRField::CR0, CRBit::EQ)));
        storeConditional<bitSize>(newValue, effectiveAddress);
        loadFence();

        // CR0.EQ now means "the store happened", on either path: the compare
        // cleared it on a mismatch and the stcx. recorded it on an attempt,
        // and no barrier writes a condition register.
        return JumpList(makeBranch({ CRBit::EQ, cond == Success }));
    }

    JumpList branchAtomicWeakCAS8(StatusCondition cond, RegisterID expectedAndClobbered, RegisterID newValue, BaseIndex address)
    {
        return branchAtomicWeakCASImpl<8>(cond, expectedAndClobbered, newValue, address);
    }

    JumpList branchAtomicWeakCAS16(StatusCondition cond, RegisterID expectedAndClobbered, RegisterID newValue, BaseIndex address)
    {
        return branchAtomicWeakCASImpl<16>(cond, expectedAndClobbered, newValue, address);
    }

    JumpList branchAtomicWeakCAS32(StatusCondition cond, RegisterID expectedAndClobbered, RegisterID newValue, BaseIndex address)
    {
        return branchAtomicWeakCASImpl<32>(cond, expectedAndClobbered, newValue, address);
    }

    // Unreachable from the DFG, which asserts on any other element size and
    // sends BigInt64 atomics down the C++ path. It is here because it is the
    // same template and because Air's AtomicStrongCAS64/LoadLink64 will want
    // it. testmasm is its only caller today.
    JumpList branchAtomicWeakCAS64(StatusCondition cond, RegisterID expectedAndClobbered, RegisterID newValue, BaseIndex address)
    {
        return branchAtomicWeakCASImpl<64>(cond, expectedAndClobbered, newValue, address);
    }

    // ==================================================================
    // Strong compare-and-swap.
    //
    // The sibling of the weak form above, and the whole difference is one
    // inner loop. A STRONG CAS fails only on a genuine value mismatch. It
    // may not report failure because the reservation was lost, and on an
    // LL/SC machine a lost reservation is the only other way a stcx. can
    // fail, so the stcx. result -- and only the stcx. result -- is retried.
    // The compare is INSIDE that retry because after a failed stcx. the
    // location may hold anything: a CAS that re-stores without re-comparing
    // is not a CAS, it is a store that waited.
    //
    //         sync                       leading barrier, ONCE
    //     1:  l{b,h,w,d}arx  rD,0,ea
    //         cmpl{w,d}      cr0,rD,expected
    //         bne            cr0,2f      genuine mismatch: leave, CR0.EQ = 0
    //         st{b,h,w,d}cx. new,0,ea    CR0.EQ = stored
    //         bne            cr0,1b      reservation lost: reload, RE-COMPARE
    //     2:  lwsync                     trailing barrier, BOTH paths
    //         mr             expected,rD the value seen
    //
    // The leading `sync` is outside the loop, which is where gcc puts it and
    // is not an optimisation to be second-guessed: a sync orders everything
    // before it against everything after it, including a re-executed larx,
    // so repeating it per lap would be correct and useless. It is also still
    // outside the reservation window, so the executed window on the storing
    // path holds one compare and one guard branch and nothing else, exactly
    // as the weak form's does. Everything section 3 of
    // jsc-ppc64le-atomics-cas.md says about the leading-sync convention
    // applies here unchanged, including why `lwsync` in its place would be
    // a bug that only many threads find: lwsync has no StoreLoad edge, and
    // StoreLoad is precisely what sequential consistency adds to
    // acquire/release. Do not reach for the ARM64 shape either. ldaxr/stlxr
    // give a CAS loop SC semantics on the instructions themselves, which is
    // why MacroAssemblerARM64's atomics have no barriers near them;
    // transplanting that here compiles, passes every single-threaded test,
    // and is wrong.
    //
    // WHERE THE LOOP CLOSES IS A CORRECTNESS PROPERTY, not a style choice.
    // The retry edge is on the stcx. only. Closing it over the mismatch as
    // well would make the sign-extension seam below -- which costs the weak
    // form a wrong answer that the DFG's outer loop turns into a hang --
    // hang INSIDE this primitive, where there is no outer loop to absorb it
    // and no tier below to fall back to. As written, a mismatch always
    // leaves, so the worst a missing mask can do here is report Failure for
    // a CAS that should have succeeded.
    //
    // The clrldi is that mask, and it is load-bearing for the same reason it
    // is in the weak form: lbarx and lharx zero-extend while the callers'
    // sub-word loads sign-extend, so the expected value of the byte 0xff
    // arrives as 0xffffffff and would never compare equal to 0x000000ff.
    // All four larx/stcx. widths are ISA 2.07 -- POWER8, this port's floor
    // (docs/power8-baseline-power9-paths.md) -- so there is no hasISA30()
    // gate here and both generations execute identical code.
    //
    // Status arrives in CR0.EQ for the compare and for the stcx. alike, and
    // no barrier and no `mr` writes a condition register, so by the join it
    // means "the store happened" on either path. Two finishers consume it:
    // makeBranch for the branch form, and emitSetFromCR0 -- mfocrf plus
    // rlwinm, gcc's own `mfcr 3,128; rlwinm 3,3,3,1` -- for the form that
    // owes its caller a 0/1 in a GPR. ISA 3.0's `setb` would shorten the
    // second by one instruction and is deliberately not used: it would be
    // the only ISA-3.0 dependency in this family, for an optimisation, on a
    // path that would then differ between POWER8 and POWER9.
    //
    // See powerpc64le-handbook jsc-ppc64le-atomics-cas.md sections 4 and 5.
    // ==================================================================

    // Leaves the CAS status in CR0.EQ (1 = the store happened) and the value
    // it saw in expectedAndResult. Every public strong form below is this
    // plus a finisher.
    template<unsigned bitSize, typename AddressType>
    void emitAtomicStrongCAS(RegisterID expectedAndResult, RegisterID newValue, AddressType address)
    {
        static_assert(bitSize == 8 || bitSize == 16 || bitSize == 32 || bitSize == 64);
        auto temp = temps<Data, Memory>();

        // As in the weak form: the effective address is finished before the
        // barrier and before any reservation exists, because larx and stcx.
        // have no D-form and because nothing may compute, load or store
        // between a larx and its stcx. Note that it is also finished before
        // the LOOP, so a retry re-executes the larx and nothing else.
        auto resolution = resolveAddress(address, temp.memory());
        RegisterID effectiveAddress = resolution.base;
        if (resolution.offset) {
            addImmediate64(resolution.base, static_cast<int64_t>(resolution.offset), temp.memory());
            effectiveAddress = temp.memory();
        }

        if constexpr (bitSize < 32)
            m_assembler.clrldi(expectedAndResult, expectedAndResult, 64 - bitSize);

        memoryFence();

        auto reload = label();
        loadAndReserve<bitSize>(temp.data(), effectiveAddress);
        if constexpr (bitSize == 64)
            m_assembler.cmpld(CRField::CR0, temp.data(), expectedAndResult);
        else
            m_assembler.cmplw(CRField::CR0, temp.data(), expectedAndResult);
        // A genuine mismatch leaves the loop with CR0.EQ clear, which is
        // already the answer both finishers want. The guard word of this
        // branch is the only instruction between the larx and the stcx. on
        // the storing path; its `b` word is skipped there.
        auto mismatch = makeBranch({ CRBit::EQ, false });
        storeConditional<bitSize>(newValue, effectiveAddress);
        // The one retry edge: the store-conditional failed, so the
        // reservation was lost and nothing was written. Reload and compare
        // again against the same expected value, which is still the
        // caller's -- expectedAndResult is not written until the join.
        makeBranch({ CRBit::EQ, false }).linkTo(reload, this);

        // The storing path falls through to here; the mismatching path
        // branches here. CR0.EQ distinguishes them and survives both of the
        // instructions below.
        mismatch.link(this);
        loadFence();
        move(temp.data(), expectedAndResult);
    }

    template<unsigned bitSize, typename AddressType>
    JumpList branchAtomicStrongCASImpl(StatusCondition cond, RegisterID expectedAndResult, RegisterID newValue, AddressType address)
    {
        emitAtomicStrongCAS<bitSize>(expectedAndResult, newValue, address);
        return JumpList(makeBranch({ CRBit::EQ, cond == Success }));
    }

    template<unsigned bitSize, typename AddressType>
    void atomicStrongCASImpl(StatusCondition cond, RegisterID expectedAndResult, RegisterID newValue, AddressType address, RegisterID result)
    {
        emitAtomicStrongCAS<bitSize>(expectedAndResult, newValue, address);
        emitSetFromCR0({ CRBit::EQ, cond == Success }, result);
    }

    template<typename AddressType>
    JumpList branchAtomicStrongCAS8(StatusCondition cond, RegisterID expectedAndResult, RegisterID newValue, AddressType address)
    {
        return branchAtomicStrongCASImpl<8>(cond, expectedAndResult, newValue, address);
    }

    template<typename AddressType>
    JumpList branchAtomicStrongCAS16(StatusCondition cond, RegisterID expectedAndResult, RegisterID newValue, AddressType address)
    {
        return branchAtomicStrongCASImpl<16>(cond, expectedAndResult, newValue, address);
    }

    template<typename AddressType>
    JumpList branchAtomicStrongCAS32(StatusCondition cond, RegisterID expectedAndResult, RegisterID newValue, AddressType address)
    {
        return branchAtomicStrongCASImpl<32>(cond, expectedAndResult, newValue, address);
    }

    template<typename AddressType>
    JumpList branchAtomicStrongCAS64(StatusCondition cond, RegisterID expectedAndResult, RegisterID newValue, AddressType address)
    {
        return branchAtomicStrongCASImpl<64>(cond, expectedAndResult, newValue, address);
    }

    // The ARM64 family's shape, which Air's atomic opcodes and testmasm use:
    // the status as a 0/1 in a GPR rather than as a branch. On this target
    // that costs the mfocrf/rlwinm pair above, which is why the branch forms
    // exist beside it; which of the two an Air backend should consume is
    // jsc-ppc64le-b3-air.md's decision, not this file's.
    template<typename AddressType>
    void atomicStrongCAS8(StatusCondition cond, RegisterID expectedAndResult, RegisterID newValue, AddressType address, RegisterID result)
    {
        atomicStrongCASImpl<8>(cond, expectedAndResult, newValue, address, result);
    }

    template<typename AddressType>
    void atomicStrongCAS16(StatusCondition cond, RegisterID expectedAndResult, RegisterID newValue, AddressType address, RegisterID result)
    {
        atomicStrongCASImpl<16>(cond, expectedAndResult, newValue, address, result);
    }

    template<typename AddressType>
    void atomicStrongCAS32(StatusCondition cond, RegisterID expectedAndResult, RegisterID newValue, AddressType address, RegisterID result)
    {
        atomicStrongCASImpl<32>(cond, expectedAndResult, newValue, address, result);
    }

    template<typename AddressType>
    void atomicStrongCAS64(StatusCondition cond, RegisterID expectedAndResult, RegisterID newValue, AddressType address, RegisterID result)
    {
        atomicStrongCASImpl<64>(cond, expectedAndResult, newValue, address, result);
    }

    // The status-free form: CAS, and hand back the value that was there.
    // x86_64 has it as one `lock cmpxchg` and ARM64 as one `casal` behind
    // LSE; here it is the same loop with no finisher at all, so the CR0 the
    // loop leaves behind is simply not read.
    template<typename AddressType>
    void atomicStrongCAS8(RegisterID expectedAndResult, RegisterID newValue, AddressType address)
    {
        emitAtomicStrongCAS<8>(expectedAndResult, newValue, address);
    }

    template<typename AddressType>
    void atomicStrongCAS16(RegisterID expectedAndResult, RegisterID newValue, AddressType address)
    {
        emitAtomicStrongCAS<16>(expectedAndResult, newValue, address);
    }

    template<typename AddressType>
    void atomicStrongCAS32(RegisterID expectedAndResult, RegisterID newValue, AddressType address)
    {
        emitAtomicStrongCAS<32>(expectedAndResult, newValue, address);
    }

    template<typename AddressType>
    void atomicStrongCAS64(RegisterID expectedAndResult, RegisterID newValue, AddressType address)
    {
        emitAtomicStrongCAS<64>(expectedAndResult, newValue, address);
    }
    // A sequentially consistent load, the same strength RISCV64 gives it and
    // at least the acquire ARM64 gives it with ldar. PowerPC has no
    // ordered-load instruction, so the ordering is spelled out: sync ahead of
    // the load to keep it behind everything before it, lwsync after to keep
    // subsequent loads and stores behind it. lwsync is enough for the
    // trailing half because the operation it has to order against is a load.
    //
    // Not reachable only from Atomics.*: AssemblyHelpers::loadTypedArray-
    // ByteLengthImpl reads a GrowableSharedArrayBuffer's size this way, so a
    // plain `array.length` on a SharedArrayBuffer view comes through here and
    // an UNREACHABLE_FOR_PLATFORM stub aborted the InlineCacheCompiler.
    void atomicLoad32(Address address, RegisterID dest)
    {
        memoryFence();
        load32(address, dest);
        loadFence();
    }

    void atomicLoad32(BaseIndex address, RegisterID dest)
    {
        memoryFence();
        load32(address, dest);
        loadFence();
    }

    void atomicLoad64(Address address, RegisterID dest)
    {
        memoryFence();
        load64(address, dest);
        loadFence();
    }

    void atomicLoad64(BaseIndex address, RegisterID dest)
    {
        memoryFence();
        load64(address, dest);
        loadFence();
    }

    // The acquire loads and release stores B3 selects for a fenced MemoryValue.
    // B3LowerToAir picks LoadAcq*/StoreRel* for every target that is not x86 --
    // its Load case reads `if (isX86()) kind.effects = true; else kind =
    // LoadAcq32` -- with no isValidForm gate, so this target has no fallback to a
    // plain load plus a fence. These must exist or Air::Inst::generate reaches
    // its unreachable default and aborts codegen partway through the procedure.
    // testb3's testLoadAcq42 is the test that finds it.
    //
    // POWER has no ordered load or store instruction, so the ordering is spelled
    // out. These carry the strength of the ARM64 ldar/stlr pair they stand in
    // for, which is RCsc -- so the pair is sequentially consistent, not merely
    // acquire/release -- and the leading `sync` is what buys that: sync is the
    // only one of these barriers carrying a StoreLoad edge, and lwsync in its
    // place would drop exactly that edge. Same reasoning as emitAtomicStrongCAS
    // above; the load sequence is atomicLoad32's, unchanged.
    //
    // This is the "leading sync" convention, and joining it is mandatory rather
    // than stylistic: jsc-ppc64le-atomics-cas.md 3.2 shows leading-sync and
    // trailing-sync are each self-consistent but must not be mixed in one
    // program, because an SC store compiled one way and an SC load compiled the
    // other leave a store-load pair with no full barrier between them. Every
    // producer in a bun process is leading-sync -- gcc, clang, WTF::Atomic
    // through them, and atomicLoad32/64 above.
    //
    // The two compilers disagree on the trailing half and the port follows
    // clang: gcc 16 ends a seq_cst RMW with `isync`, clang 22 with `lwsync`
    // [MEASURED, same doc 3.1]. clang also has a cheaper *pure acquire* load,
    // `lwz; cmpd 7,rD,rD; bf- 30,+4; isync` -- a control dependency rather than
    // a barrier -- and `lwsync; stw` for a pure release store [MEASURED
    // 2026-09-27, clang 22.1.8, read back with llvm-objdump]. Neither is taken
    // here, and not only because they are weaker than the ldar/stlr pair: an
    // `isync` acquire is an acquire *only* because of the conditional branch
    // placed in front of it, and 3.2 declines to export that fragility to Air,
    // where the shape of the surrounding code is not this file's to guarantee.
    void loadAcq8(Address address, RegisterID dest)
    {
        memoryFence();
        load8(address, dest);
        loadFence();
    }

    void loadAcq8SignedExtendTo32(Address address, RegisterID dest)
    {
        memoryFence();
        load8SignedExtendTo32(address, dest);
        loadFence();
    }

    void loadAcq16(Address address, RegisterID dest)
    {
        memoryFence();
        load16(address, dest);
        loadFence();
    }

    void loadAcq16SignedExtendTo32(Address address, RegisterID dest)
    {
        memoryFence();
        load16SignedExtendTo32(address, dest);
        loadFence();
    }

    void loadAcq32(Address address, RegisterID dest)
    {
        memoryFence();
        load32(address, dest);
        loadFence();
    }

    void loadAcq64(Address address, RegisterID dest)
    {
        memoryFence();
        load64(address, dest);
        loadFence();
    }

    void storeRel8(RegisterID src, Address address)
    {
        memoryFence();
        store8(src, address);
    }

    void storeRel16(RegisterID src, Address address)
    {
        memoryFence();
        store16(src, address);
    }

    void storeRel32(RegisterID src, Address address)
    {
        memoryFence();
        store32(src, address);
    }

    void storeRel64(RegisterID src, Address address)
    {
        memoryFence();
        store64(src, address);
    }
    // ==================================================================
    // Conditional moves.
    //
    // Integer selects use isel (ISA 2.06), which is branchless: it picks
    // between two GPRs on one CR bit. The one trap is that isel's RA field,
    // like every other RA field, reads as the literal zero when it names r0
    // -- so an operand that happened to be r0 would silently become 0. JSC
    // never allocates r0 (GPRInfo::toIndex maps it to InvalidIndex), and the
    // assertion below keeps that assumption honest rather than implicit.
    //
    // Floating-point selects use a branch instead of fsel. fsel tests
    // "greater than or equal to zero" on a single operand and returns the
    // WRONG argument for NaN -- the LuaJIT ppc64le port's correction ledger
    // records exactly that -- so expressing JSC's twelve NaN-aware
    // DoubleConditions through it would be a NaN bug generator.
    // ==================================================================

    void emitSelect(CRTest test, RegisterID thenCase, RegisterID elseCase, RegisterID dest)
    {
        RELEASE_ASSERT(thenCase != PPC64Registers::r0 && elseCase != PPC64Registers::r0);
        unsigned bit = crBitIndex(test.field, test.bit);
        if (test.branchIfSet)
            m_assembler.isel(dest, thenCase, elseCase, bit);
        else
            m_assembler.isel(dest, elseCase, thenCase, bit);
    }

    void moveConditionally32(RelationalCondition cond, RegisterID left, RegisterID right, RegisterID src, RegisterID dest)
    {
        emitSelect(emitCompare32(cond, left, right), src, dest, dest);
    }

    void moveConditionally32(RelationalCondition cond, RegisterID left, RegisterID right, RegisterID thenCase, RegisterID elseCase, RegisterID dest)
    {
        emitSelect(emitCompare32(cond, left, right), thenCase, elseCase, dest);
    }

    void moveConditionally32(RelationalCondition cond, RegisterID left, TrustedImm32 right, RegisterID thenCase, RegisterID elseCase, RegisterID dest)
    {
        emitSelect(emitCompare32(cond, left, right), thenCase, elseCase, dest);
    }

    void moveConditionally32(RelationalCondition cond, RegisterID left, TrustedImm32 right, TrustedImm32 thenCase, RegisterID elseCase, RegisterID dest)
    {
        // The "then" value is a constant, so it has to be materialised before
        // the compare -- loading it afterwards would clobber CR0.
        auto temp = temps<Memory>();
        loadImmediate(thenCase, temp.memory());
        emitSelect(emitCompare32(cond, left, right), temp.memory(), elseCase, dest);
    }

    void moveConditionally64(RelationalCondition cond, RegisterID left, RegisterID right, RegisterID src, RegisterID dest)
    {
        emitSelect(emitCompare64(cond, left, right), src, dest, dest);
    }

    void moveConditionally64(RelationalCondition cond, RegisterID left, RegisterID right, RegisterID thenCase, RegisterID elseCase, RegisterID dest)
    {
        emitSelect(emitCompare64(cond, left, right), thenCase, elseCase, dest);
    }

    void moveConditionally64(RelationalCondition cond, RegisterID left, TrustedImm32 right, RegisterID thenCase, RegisterID elseCase, RegisterID dest)
    {
        emitSelect(emitCompare64(cond, left, right), thenCase, elseCase, dest);
    }

    void moveConditionallyTest32(ResultCondition cond, RegisterID reg, RegisterID mask, RegisterID src, RegisterID dest)
    {
        emitSelect(emitTest32(cond, reg, mask), src, dest, dest);
    }

    void moveConditionallyTest32(ResultCondition cond, RegisterID reg, RegisterID mask, RegisterID thenCase, RegisterID elseCase, RegisterID dest)
    {
        emitSelect(emitTest32(cond, reg, mask), thenCase, elseCase, dest);
    }

    void moveConditionallyTest32(ResultCondition cond, RegisterID reg, TrustedImm32 mask, RegisterID thenCase, RegisterID elseCase, RegisterID dest)
    {
        emitSelect(emitTest32(cond, reg, mask), thenCase, elseCase, dest);
    }

    void moveConditionallyTest64(ResultCondition cond, RegisterID reg, RegisterID mask, RegisterID src, RegisterID dest)
    {
        emitSelect(emitTest64(cond, reg, mask), src, dest, dest);
    }

    void moveConditionallyTest64(ResultCondition cond, RegisterID reg, RegisterID mask, RegisterID thenCase, RegisterID elseCase, RegisterID dest)
    {
        emitSelect(emitTest64(cond, reg, mask), thenCase, elseCase, dest);
    }

    void moveConditionallyTest64(ResultCondition cond, RegisterID reg, TrustedImm32 mask, RegisterID thenCase, RegisterID elseCase, RegisterID dest)
    {
        emitSelect(emitTest64(cond, reg, mask), thenCase, elseCase, dest);
    }

    void moveConditionallyDouble(DoubleCondition cond, FPRegisterID a, FPRegisterID b, RegisterID src, RegisterID dest)
    {
        emitSelect(emitDoubleCompare(cond, a, b), src, dest, dest);
    }

    void moveConditionallyDouble(DoubleCondition cond, FPRegisterID a, FPRegisterID b, RegisterID thenCase, RegisterID elseCase, RegisterID dest)
    {
        emitSelect(emitDoubleCompare(cond, a, b), thenCase, elseCase, dest);
    }

    void moveConditionallyFloat(DoubleCondition cond, FPRegisterID a, FPRegisterID b, RegisterID src, RegisterID dest)
    {
        emitSelect(emitFloatCompare(cond, a, b), src, dest, dest);
    }

    void moveConditionallyFloat(DoubleCondition cond, FPRegisterID a, FPRegisterID b, RegisterID thenCase, RegisterID elseCase, RegisterID dest)
    {
        emitSelect(emitFloatCompare(cond, a, b), thenCase, elseCase, dest);
    }

    void moveConditionallyDoubleWithZero(DoubleCondition cond, FPRegisterID reg, RegisterID src, RegisterID dest)
    {
        emitSelect(emitDoubleCompareWithZero(cond, reg), src, dest, dest);
    }

    void moveConditionallyDoubleWithZero(DoubleCondition cond, FPRegisterID reg, RegisterID thenCase, RegisterID elseCase, RegisterID dest)
    {
        emitSelect(emitDoubleCompareWithZero(cond, reg), thenCase, elseCase, dest);
    }

    void moveConditionallyFloatWithZero(DoubleCondition cond, FPRegisterID reg, RegisterID src, RegisterID dest)
    {
        emitSelect(emitFloatCompareWithZero(cond, reg), src, dest, dest);
    }

    void moveConditionallyFloatWithZero(DoubleCondition cond, FPRegisterID reg, RegisterID thenCase, RegisterID elseCase, RegisterID dest)
    {
        emitSelect(emitFloatCompareWithZero(cond, reg), thenCase, elseCase, dest);
    }

    // Selecting an FPR has no isel equivalent, so it is a branch over a move.
    // The condition is already in a CR field by the time we get here, so this
    // is the one place a Jump is built from a CRTest without going through
    // one of the branchXxx entry points.
    void emitSelectDouble(CRTest test, FPRegisterID thenCase, FPRegisterID elseCase, FPRegisterID dest)
    {
        // Seeding dest with the else value and branching over the then-move
        // is only valid while dest is not itself the then value -- otherwise
        // the seed destroys the operand the branch was going to keep. JSC
        // calls this with dest == thenCase (testmasm has a case named for
        // exactly that), so the direction of the branch has to follow the
        // aliasing rather than being fixed.
        if (dest == thenCase) {
            // Already holding the then value: only the else case needs work.
            Jump keepThen = makeBranch(test);
            moveDouble(elseCase, dest);
            keepThen.link(this);
            return;
        }
        moveDouble(elseCase, dest);
        Jump skip = makeBranch({ test.bit, !test.branchIfSet, test.field });
        moveDouble(thenCase, dest);
        skip.link(this);
    }

    void moveDoubleConditionally32(RelationalCondition cond, RegisterID left, RegisterID right, FPRegisterID thenCase, FPRegisterID elseCase, FPRegisterID dest)
    {
        emitSelectDouble(emitCompare32(cond, left, right), thenCase, elseCase, dest);
    }

    void moveDoubleConditionally32(RelationalCondition cond, RegisterID left, TrustedImm32 right, FPRegisterID thenCase, FPRegisterID elseCase, FPRegisterID dest)
    {
        emitSelectDouble(emitCompare32(cond, left, right), thenCase, elseCase, dest);
    }

    void moveDoubleConditionally64(RelationalCondition cond, RegisterID left, RegisterID right, FPRegisterID thenCase, FPRegisterID elseCase, FPRegisterID dest)
    {
        emitSelectDouble(emitCompare64(cond, left, right), thenCase, elseCase, dest);
    }

    void moveDoubleConditionally64(RelationalCondition cond, RegisterID left, TrustedImm32 right, FPRegisterID thenCase, FPRegisterID elseCase, FPRegisterID dest)
    {
        emitSelectDouble(emitCompare64(cond, left, right), thenCase, elseCase, dest);
    }

    void moveDoubleConditionallyDouble(DoubleCondition cond, FPRegisterID a, FPRegisterID b, FPRegisterID thenCase, FPRegisterID elseCase, FPRegisterID dest)
    {
        emitSelectDouble(emitDoubleCompare(cond, a, b), thenCase, elseCase, dest);
    }

    void moveDoubleConditionallyFloat(DoubleCondition cond, FPRegisterID a, FPRegisterID b, FPRegisterID thenCase, FPRegisterID elseCase, FPRegisterID dest)
    {
        emitSelectDouble(emitFloatCompare(cond, a, b), thenCase, elseCase, dest);
    }

    void moveDoubleConditionallyDoubleWithZero(DoubleCondition cond, FPRegisterID reg, FPRegisterID thenCase, FPRegisterID elseCase, FPRegisterID dest)
    {
        emitSelectDouble(emitDoubleCompareWithZero(cond, reg), thenCase, elseCase, dest);
    }

    void moveDoubleConditionallyFloatWithZero(DoubleCondition cond, FPRegisterID reg, FPRegisterID thenCase, FPRegisterID elseCase, FPRegisterID dest)
    {
        emitSelectDouble(emitFloatCompareWithZero(cond, reg), thenCase, elseCase, dest);
    }

    void moveDoubleConditionallyTest32(ResultCondition cond, RegisterID reg, RegisterID mask, FPRegisterID thenCase, FPRegisterID elseCase, FPRegisterID dest)
    {
        emitSelectDouble(emitTest32(cond, reg, mask), thenCase, elseCase, dest);
    }

    void moveDoubleConditionallyTest32(ResultCondition cond, RegisterID reg, TrustedImm32 mask, FPRegisterID thenCase, FPRegisterID elseCase, FPRegisterID dest)
    {
        emitSelectDouble(emitTest32(cond, reg, mask), thenCase, elseCase, dest);
    }

    void moveDoubleConditionallyTest64(ResultCondition cond, RegisterID reg, RegisterID mask, FPRegisterID thenCase, FPRegisterID elseCase, FPRegisterID dest)
    {
        emitSelectDouble(emitTest64(cond, reg, mask), thenCase, elseCase, dest);
    }

    void moveDoubleConditionallyTest64(ResultCondition cond, RegisterID reg, TrustedImm32 mask, FPRegisterID thenCase, FPRegisterID elseCase, FPRegisterID dest)
    {
        emitSelectDouble(emitTest64(cond, reg, mask), thenCase, elseCase, dest);
    }
    // ---- half precision ----
    //
    // A float16 in an FPR is its raw 16-bit IEEE pattern in halfword 3 of
    // doubleword 0 (bits 48:63); the other 112 bits are don't-care. That is
    // the port's raw-bits float model narrowed one width: the float lives in
    // word 1, the half in the low half of that word.
    //
    // Every one of these asserts supportsFloat16() rather than trusting the
    // caller. Upstream consults the predicate at parse time, in the fixup
    // phase and in the ICs, but ArithF16Round has a single parse-time guard
    // while the fixup phase, FTLCapabilities and the FTL lowering accept the
    // node unconditionally, so anything that synthesises it outside the
    // parser reaches these primitives. On a POWER8 machine that would be a
    // SIGILL on an instruction the CPU does not have; the assert fails with
    // a line that says why instead.
    void loadFloat16(Address address, FPRegisterID dest)
    {
        RELEASE_ASSERT(supportsFloat16());
        auto temp = lazyTemp<Memory>();
        auto resolution = resolveAddress(address, temp, false);
        m_assembler.lxsihzx(dest, PPC64Registers::r0, foldOffsetIntoAddressRegister(resolution, temp));
    }

    void loadFloat16(BaseIndex address, FPRegisterID dest)
    {
        RELEASE_ASSERT(supportsFloat16());
        auto temp = temps<Memory>();
        auto resolution = resolveAddress(address, temp.memory(), false);
        m_assembler.lxsihzx(dest, PPC64Registers::r0, foldOffsetIntoAddressRegister(resolution, temp.memory()));
    }

    void loadFloat16(TrustedImmPtr address, FPRegisterID dest)
    {
        RELEASE_ASSERT(supportsFloat16());
        auto temp = temps<Memory>();
        loadImmediate(address, temp.memory());
        m_assembler.lxsihzx(dest, PPC64Registers::r0, temp.memory());
    }

    void storeFloat16(FPRegisterID src, Address address)
    {
        RELEASE_ASSERT(supportsFloat16());
        auto temp = lazyTemp<Memory>();
        auto resolution = resolveAddress(address, temp, false);
        m_assembler.stxsihx(src, PPC64Registers::r0, foldOffsetIntoAddressRegister(resolution, temp));
    }

    void storeFloat16(FPRegisterID src, BaseIndex address)
    {
        RELEASE_ASSERT(supportsFloat16());
        auto temp = temps<Memory>();
        auto resolution = resolveAddress(address, temp.memory(), false);
        m_assembler.stxsihx(src, PPC64Registers::r0, foldOffsetIntoAddressRegister(resolution, temp.memory()));
    }

    // Reads halfword 3. Exact by construction: every half is representable
    // as a double.
    void convertFloat16ToDouble(FPRegisterID src, FPRegisterID dest)
    {
        RELEASE_ASSERT(supportsFloat16());
        m_assembler.xscvhpdp(dest, src);
    }

    // Writes halfword 3, rounding under the FPSCR, which by default is
    // round-to-nearest-even -- exactly what Math.f16round and
    // DataView.setFloat16 require. Measured against a software RNE
    // reference: ties round to even (2049 -> 6800, 2051 -> 6802), 65520
    // overflows to inf, and the smallest denormal survives. The instruction
    // also zeroes bits 0:47 of the doubleword, which this model does not
    // rely on.
    void convertDoubleToFloat16(FPRegisterID src, FPRegisterID dest)
    {
        RELEASE_ASSERT(supportsFloat16());
        m_assembler.xscvdphp(dest, src);
    }

    void moveZeroToFloat16(FPRegisterID dest)
    {
        RELEASE_ASSERT(supportsFloat16());
        m_assembler.xxlxor(dest, dest, dest);
    }

    // mtvsrwz zero-extends the word into word 1, so halfword 3 is the GPR's
    // low sixteen bits.
    void move16ToFloat16(RegisterID src, FPRegisterID dest)
    {
        RELEASE_ASSERT(supportsFloat16());
        m_assembler.mtvsrwz(dest, src);
    }

    void move16ToFloat16(TrustedImm32 imm, FPRegisterID dest)
    {
        RELEASE_ASSERT(supportsFloat16());
        auto temp = temps<Data>();
        loadImmediate(imm, temp.data());
        m_assembler.mtvsrwz(dest, temp.data());
    }

    // The mask is what makes bits 16:31 don't-care: without it a later
    // mtvsrwz from this GPR would carry whatever the upper halfword held
    // back into the register.
    void moveFloat16To16(FPRegisterID src, RegisterID dest)
    {
        RELEASE_ASSERT(supportsFloat16());
        m_assembler.mfvsrwz(dest, src);
        m_assembler.clrldi(dest, dest, 48);
    }
};

} // namespace JSC

#endif // ENABLE(ASSEMBLER) && CPU(PPC64LE)
